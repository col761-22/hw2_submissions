#!/usr/bin/bash
if [[ "$1" == "-apriori" ]]
then
    ./apriori.out $2 $3 $4
elif [[ "$1" == "-fptree" ]]
then
    ./fptree.out $2 $3 $4
elif [[ "$1" == "-plot" ]]
then
    python3 plot.py $2 $3
else
    echo "Expected one of -apriori, -fptree, -plot"
fi
