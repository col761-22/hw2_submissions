import matplotlib.pyplot as plt
import sys
import subprocess
from subprocess import Popen, PIPE
import time

cuts = [5, 10, 25, 50, 90]
fp = []
ap = []
for cut in cuts:
    st = time.time()
    subprocess.Popen(['./fptree.out', sys.argv[1], str(cut),"./dev/null/1.dat"], stdout=subprocess.PIPE)
    en = time.time()
    fp.append(en-st)
    st = time.time()
    
    subprocess.Popen(['./apriori.out', sys.argv[1],str(cut),"./dev/null/1.dat"], stdout=subprocess.PIPE)
    en = time.time()
    ap.append(en-st)
    
    
plt.plot(cuts, ap, '-o', markersize = 5, label = 'Apriori')
plt.plot(cuts, fp, '-o', markersize = 5, label = 'FP Tree')
plt.ylabel('Running Time(sec)')
plt.xlabel('Support Threshold(%)')
plt.legend()
plt.savefig(sys.argv[2] +".png")
