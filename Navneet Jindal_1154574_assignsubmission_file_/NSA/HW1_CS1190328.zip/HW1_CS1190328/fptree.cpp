#include<bits/stdc++.h>
#include <chrono>
#include <fcntl.h>
#include <iostream>
#include <sys/stat.h>
#include <stdio.h>
#include <unistd.h>
#include <utility>
using namespace std;


void print2d(vector<vector<int>>&frequent_itemset)
{
    for(auto x: frequent_itemset)
    {
        for(auto y: x)
        {
            cout<<y<<" ";
        }
        cout<<endl;
    }
}

class Node
{
public:
    int item_num;
    int cnt;
    Node* prnt;
    Node* next;
    unordered_map<int,Node*> child;
    // Constructor
    Node()
    {
        this->item_num=-1;
        this->prnt=prnt;
        this->cnt=0;
        this->next=NULL;
        this->child.clear();
    }
    Node(int item_num,Node* prnt)
    {
        this->item_num=item_num;
        this->prnt=prnt;
        this->cnt=0;
        this->next=NULL;
        this->child.clear();
    }
};


unordered_map<int,int> items_frequency;
unordered_map<int,Node*> head;
int num_T;
string infile,outfile;
vector<vector<int>> ans;    
double supp_threshold;
vector<int> all_heads;
unordered_map<int,int> item_to_idx;


bool comp(int a, int b)
{
    if(items_frequency[a]==items_frequency[b])
        return a<b;
    return items_frequency[a]>items_frequency[b];
}
bool comp1(pair<int,int> a, pair<int,int> b)
{
    int a1 = a.first;
    int b1 = b.first;
    if(items_frequency[a1]==items_frequency[b1])
        return a1<b1;
    return items_frequency[a1]>items_frequency[b1];
}

class Tree{
public:
  Node* root;
  unordered_map<int,Node*> head;
  
  Tree(vector<int>& frequent_items){
    root = new Node();
    assert(root!=NULL);
    for(int i : frequent_items) head[i] = NULL;
  }


  void insert_transaction(vector<pair<int,int>> &items){
    Node* node = root;
    assert(root!=NULL);
    for(auto [a,b]: items){
        if(items_frequency[a]*100 < supp_threshold)
        {
            continue;
        }
        if(node->child.find(a) == node->child.end()){
            Node* new_node = new Node(a,node);
            
            
            new_node->next=head[a];
            head[a]=new_node;
            node->child[a]=new_node;
            new_node->prnt=node;
        }

      node = node->child[a];
      node->cnt += b;
    }
  }


  vector<int> only_one_path(){
    Node* node = root;
    assert(root!=NULL);
    vector<int> items;
    for(;(*node).child.size()>0;node = node->child.begin()->second){
        int item_num = (*node).child.begin()->first;
        if(node->child.size()==1)
            items.push_back(item_num);
        else
            return vector<int>();
    }
    return items;
  }
};


void fpGrowth(vector<vector<pair<int,int>>> &conditionals, vector<int>& tree_path){

    if(conditionals.size()==0)
    {
        assert(conditionals.size()==0);
        vector<int> path;
        copy(tree_path.begin(), tree_path.end(), back_inserter(path));
        reverse(path.begin(),path.end());
        if(path.size())
            ans.push_back(path);
        return;
    }
    vector<int> min_support_items;
    vector<pair<int,int>> min_support_items_copy;
    unordered_map<int,int> storing_conditional_freq;

    int conditional_sz = conditionals.size();
    for(auto x: conditionals)
    {
        for(auto [a,b] : x)
        {
            storing_conditional_freq[a]+=b;
        }
    }
    for(auto item: storing_conditional_freq){
        if(item.second*100>= supp_threshold){
            min_support_items_copy.push_back(make_pair(storing_conditional_freq[item.first],item.first));
        }
    }
    sort(min_support_items.rbegin(),min_support_items.rend());
    for(auto [a,b] : min_support_items_copy)
    {
        min_support_items.push_back(b);
    } 
  if(min_support_items.size()==0)
  {
    assert(min_support_items.size()==0);
    vector<int> path;
    copy(tree_path.begin(), tree_path.end(), back_inserter(path));
    reverse(path.begin(),path.end());
    if(path.size())
        ans.push_back(path);
    return;
  }

  Tree tree(min_support_items);
  long long k = 0;
  while(k<conditional_sz)
  {
    vector<pair<int,int>> items;
    for(auto item: conditionals[k]){
      if(storing_conditional_freq[item.first]*100 >= supp_threshold){
        items.push_back(item);
      }
    }
    tree.insert_transaction(items);
    k++;
  }

  auto temp_items = tree.only_one_path();

  if(temp_items.size()){
    vector<int> path;
    copy(tree_path.begin(), tree_path.end(), back_inserter(path));
    reverse(path.begin(),path.end());
    long long m = temp_items.size();
    long long i = 0,j=0;
    int mx = (1ll<<m);
    while(i<mx)
    {
        vector<int> frequent_itemset_path;
        while(j<m)
        {
            if(i & (1ll<<j))
            {
                frequent_itemset_path.push_back(temp_items[j]);
            }
            j++;
        }
        j=0;
        while(j<path.size()){
            frequent_itemset_path.push_back(path[j]);
            j++;
        }
        j=0;
        ans.push_back(frequent_itemset_path);
        i++;
    }
    return;
  }

  int m = (int)min_support_items.size();
  if(min_support_items.size()){
    vector<int> path;
    copy(tree_path.begin(), tree_path.end(), back_inserter(path));
    reverse(path.begin(),path.end());
    if(path.size())
        ans.push_back(path);
    
  }
  vector<vector<pair<int,int>>> new_conditionals;
  reverse(min_support_items.begin(),min_support_items.end());
  
  for(auto x: min_support_items){
    tree_path.push_back(x);
    new_conditionals.clear();
    Node *node = tree.head[x];
    for(;node!=NULL;node = node->next)
    {
        vector<pair<int,int>> items;

        Node *temp = node->prnt;
        for(;temp->item_num!=-1;temp=temp->prnt)
        {
            items.push_back({temp->item_num, node->cnt});
        }

        new_conditionals.push_back(items);
    }

    assert(tree_path.size()>0);
    fpGrowth(new_conditionals, tree_path);
    assert(tree_path.size()>0);
    tree_path.pop_back();
  }
}

int main(int argc, char* argv[]){
  // read arguments
  infile=argv[1];
    outfile=argv[3];
    supp_threshold =atof(argv[2]);
    vector<vector<pair<int,int>>> conditionals;
    
    string line;
    {
        ifstream input(infile,ifstream::in);
        while(getline(input,line))
        {
            istringstream transac(line);
            while(transac)
            {
                int x;
                transac>>x;
                if(transac)
                {
                    items_frequency[x]++;
                }
            }
            num_T++;
        }
        input.close();
    }
    ifstream input1(infile,ifstream::in);
    supp_threshold*=num_T;
    while(getline(input1,line))
    {
        istringstream transac(line);
        vector<pair<int,int>> transaction;
        while(transac)
        {
            int x;
            transac>>x;
            if(transac)
            {
                if(items_frequency[x]*100 >= supp_threshold)
                {
                    transaction.push_back(make_pair(x,1));
                }
            }
        }
        if(!transaction.size())
            continue;
        sort(transaction.begin(),transaction.end(),comp1);
        conditionals.push_back(transaction);
        
    }


    input1.close();


    vector<int> tree_path;

    fpGrowth(conditionals,tree_path);
    // print2d(ans);
    vector<string> final_output;
    ofstream MyFile(argv[3]);
    // const int file = open(argv[2], O_WRONLY | O_CREAT); 
    
    for(int i = 0 ;i < ans.size() ; i++)
    {
            assert(ans.size()>0);
            vector<string> out;
            for(int k : ans[i])
            {
                out.push_back(to_string(k));
            }
            sort(out.begin(),out.end());
            string temp="";
            for(auto x : out)
            {
                temp+=x;
                temp+=" ";
            }
            temp.pop_back();
            temp+="\n";
            final_output.push_back(temp);
            
    }

    sort(final_output.begin(),final_output.end());
    for(auto out : final_output)
    {
        MyFile<<out;
    }

}

