g++ -O3 -Wall -o apriori.out apriori.cpp
g++ -O3 -Wall -o fptree.out fptree.cpp