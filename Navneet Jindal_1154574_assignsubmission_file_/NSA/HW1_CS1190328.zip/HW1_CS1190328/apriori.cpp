#include<bits/stdc++.h>
#include <chrono>
#include <fcntl.h>
#include <iostream>
#include <sys/stat.h>
#include <stdio.h>
#include <unistd.h>
#include <utility>
using namespace std;
unordered_map<int,int> items_frequency;
int num_T;
string infile,outfile;
vector<vector<int>> C_k, F_k;
vector<vector<vector<int>>> ans;	
double supp_threshold;
void initialization()
{
	items_frequency.clear();
	num_T=0;
	infile="";
	outfile="";
	ans.clear();
	C_k.clear();
	F_k.clear();
	supp_threshold=0.00;
}
inline bool check_contains(vector<int> &v1, vector<int> &v2)
{
	return includes(v2.begin(),v2.end(),v1.begin(),v1.end());
}

void generate_candidates()
{
	int sz = F_k.size();
	for(int i = 0; i < sz; i++)
	{
		for(int j = i+1 ; j < sz; j++)
		{
			vector<int> joined;	
			vector<int> v1 = F_k[i],v2 = F_k[j];
			int item_set_size = v1.size(); 
			bool check = true;
			for(int k = 0 ; k < item_set_size - 1; k++)
			{
				if(v1[k]!=v2[k])
					check=false;
			}
			if(check)
			{
				joined = v1;
				joined.pop_back();
				int num1 = min(v1.back(),v2.back());
				int num2 = max(v1.back(),v2.back());
				joined.push_back(num1);joined.push_back(num2);
			
				assert(joined.size()==v1.size()+1);
				
				bool to_push = true;
				// print_vector(joined);
				for(int k = 0 ; k < joined.size(); k++)
				{
					auto it = joined.begin()+k;
					int num = *it;
					joined.erase(it);
					it=joined.begin()+k;
					if(find(F_k.begin(),F_k.end(),joined)==F_k.end())
					{
						to_push=false;
						break;
					}
					joined.insert(it,num);
				}
				if(to_push)
				{
					assert(joined.size()==v1.size()+1);
					C_k.push_back(joined);
				}
			}
			else
			{
				break;
			}
		}
	}
}
int main(int argc,char* argv[])
{
	clock_t start, end;
	start = clock();
	initialization();
	infile=argv[1];
	outfile=argv[3];
	supp_threshold =atof(argv[2]);
	
	string line;
	ifstream input(infile,ifstream::in);
	while(getline(input,line))
	{
		istringstream transac(line);
		while(transac)
		{
			int x;
			transac>>x;
			if(transac)
			{
				if(items_frequency.find(x)==items_frequency.end())
				{
					vector<int> temp(1);
					temp[0]=x;
					C_k.push_back(temp);
				}
				items_frequency[x]++;
			}
		}
		num_T++;
	}
	input.close();
	supp_threshold*=num_T;
	
	for(auto v1:C_k)
	{
		if(items_frequency[v1[0]] * 100 >= supp_threshold)
		{
			F_k.push_back(v1);
		}
	}
	ans.push_back(F_k);
	while(1)
	{
		if(!F_k.size())
			break;
		C_k.clear();
		generate_candidates();
		F_k.clear();
		vector<int> support_frequency(C_k.size(),0);
		ifstream input(infile,ifstream::in);
		while(getline(input,line))
		{
			istringstream transac(line);
		
			vector<int> temp;
			while(transac)
			{
				int x;
				transac>>x;
				if(transac)
				{
					temp.push_back(x);		
				}
			}
			int idx = 0;
			for(auto v1 : C_k)
			{
				if(check_contains(v1,temp))
				{
					support_frequency[idx]++;
				}
				idx++;
			}

		}
	
		int idx=0;
		for(auto cnt : support_frequency)
		{
			if(cnt*100 >= supp_threshold)
			{
				F_k.push_back(C_k[idx]);
			}
			idx++;
		}
		ans.push_back(F_k);
		C_k.clear();
	}

	ofstream MyFile(outfile);
	vector<string> final_output;
	for(int i = 0 ;i < ans.size() ; i++)
	{
		for(int j = 0 ; j < ans[i].size(); j++)
		{
			vector<string> out;
			for(int k = 0 ; k < ans[i][j].size(); k++)
			{
				out.push_back(to_string(ans[i][j][k]));
				// out+=to_string(ans[i][j][k]);
				// out+=" ";
			}
			// out+="\n";
			sort(out.begin(),out.end());
			string temp="";
			for(auto x : out)
			{
				temp+=x;
				temp+=" ";
			}
			temp.pop_back();
			temp+="\n";
			final_output.push_back(temp);
			
		}
	}

	sort(final_output.begin(),final_output.end());
	for(auto out : final_output)
	{
		MyFile<<out;

	}
	MyFile.close();
	end = clock();
	cout << (float) (end - start) / CLOCKS_PER_SEC << endl;

	
}