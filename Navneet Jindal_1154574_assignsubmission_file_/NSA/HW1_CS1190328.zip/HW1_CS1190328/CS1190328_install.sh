#!usr/bin/bash
git clone https://github.com/Navneet341/NSA.git
cd NSA
unzip HW1_CS1190328.zip
cd HW1_CS1190328
module load compiler/gcc/7.1.0/compilervars
