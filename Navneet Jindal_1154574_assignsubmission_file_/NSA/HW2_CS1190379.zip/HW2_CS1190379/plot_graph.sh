module load apps/anaconda/3
module load compiler/gcc/9.1.0
python3 plot.py $1 graph