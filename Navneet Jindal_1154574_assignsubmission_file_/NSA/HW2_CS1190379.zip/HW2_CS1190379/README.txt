HW2 Submission
Team: NSA

Github Repo Link: 

Team Members:
Anirudh Gupta 2019CS10328
Navneet Jindal 2019CS10379
Sajal Mittal 2019CS10396

Contributions:
Anirudh Gupta 2019CS10328 33%
Navneet Jindal 2019CS10379 34%
Sajal Mittal 2019CS10396 33%



To run part 1:
    $sh plot_graph.sh <graph_dataset_path>
To run part 2:
    $sh index.sh <graph_dataset_path>       \\ stores graphs and patterns in Mined_graphs/ and stores feature vector in fv.txt
    $sh query.sh      \\ asks query file path in interactive mode and outputs in output_CS1190379.txt, also prints total time taken at the end
To run part 3:
As described in the statement pdf