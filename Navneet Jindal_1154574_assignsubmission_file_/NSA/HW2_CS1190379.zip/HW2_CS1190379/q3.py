import sys
from sklearn.cluster import KMeans
import numpy as np
import matplotlib.pyplot as plt
def read_input(infile,dim):
	f= open(infile,"r")
	input_Data=[]
	for x in f:
		nums = x.split(" ")
		points=[]
		for i in range((int)(dim)):
			nums[i]=nums[i].strip()
			points.append(nums[i])
		input_Data.append(points)
	f.close()
	return input_Data


if __name__ == "__main__":
	filename = sys.argv[1]
	dim = sys.argv[2]
	out_file = sys.argv[3]

	X = read_input(filename,dim)
	# print(X)
	X=np.array(X)
	k_values = list(range(1,16))
	out=[]
	for k in k_values:
		kmeans = KMeans(n_clusters=k,init = "k-means++",random_state=0).fit(X)
		predictions = kmeans.inertia_
		out.append(predictions)
		# print(predictions)
	plt.plot(out)
	# plt.show()
	plt.title("Elbow Plot")
	plt.ylabel("WCSS")
	plt.xlabel("Number of Clusters")
	plt.savefig(out_file)

