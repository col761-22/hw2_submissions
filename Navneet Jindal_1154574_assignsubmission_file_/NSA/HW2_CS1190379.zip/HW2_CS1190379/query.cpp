#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <sstream>
#include <iterator>
#include <bits/stdc++.h>

#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/labeled_graph.hpp>
#include <boost/graph/vf2_sub_graph_iso.hpp>
#include <boost/property_map/property_map.hpp>

using namespace std;
using namespace boost;

typedef property<edge_name_t, string> edge_prop;
typedef property<vertex_name_t, string, property<vertex_index_t, int> > vertex_prop;

typedef adjacency_list<vecS, vecS, bidirectionalS, vertex_prop, edge_prop> Graph;

typedef property_map<Graph, vertex_name_t>::type vertex_name_map_t;
typedef property_map_equivalent<vertex_name_map_t, vertex_name_map_t> vertex_comp_t;

typedef property_map<Graph, edge_name_t>::type edge_name_map_t;
typedef property_map_equivalent<edge_name_map_t, edge_name_map_t> edge_comp_t;

const auto callback = [](auto&&, auto&&) {
	return false;
};

bool is_subgraph_isomorphic(Graph* smallGraph, Graph* bigGraph)
{
    vertex_comp_t vertex_comp =
        make_property_map_equivalent(get(vertex_name, *smallGraph), get(vertex_name, *bigGraph));
    edge_comp_t edge_comp =
        make_property_map_equivalent(get(edge_name, *smallGraph), get(edge_name, *bigGraph));
    // vf2_print_callback<Graph, Graph> callback(*smallGraph, *bigGraph);
    bool res = vf2_subgraph_iso(*smallGraph, *bigGraph, callback, vertex_order_by_mult(*smallGraph),
        edges_equivalent(edge_comp).vertices_equivalent(vertex_comp));
    return res;
}

int store_graphs(vector<Graph*>& graphs,vector<int>& graph_id, string infile){
    
    cout<<"Storing graphs at "<<infile<<endl;
    ifstream file;
    file.open(infile,ios::in);
    int num_graphs = 0;
    string word;
    while(file>>word){

        // cout<<num_graphs<<endl;
        if (word[0]!='#') continue;
        graph_id.push_back(stoi(word.substr(1)));

        Graph* g = new Graph();

        file>>word;
        int n = stoi(word);
        for(int i = 0;i<n;i++){
            file>>word;
            add_vertex(vertex_prop(word),*g);
        }
        file>>word;
        int m = stoi(word);
        for(int i = 0;i<m;i++){
            file>>word;
            int a = stoi(word);
            file>>word;
            int b = stoi(word);
            file>>word;
            add_edge(a,b,edge_prop(word),*g);
        }
        graphs.push_back(g);
        num_graphs++;

    }
    file.close();
    cout<<"stored graphs"<<endl;
    return num_graphs;
}

bool subset(vector<int>& a, vector<int>&b){

    for(int i = 0;i<a.size();i++){
        if (a[i]>b[i]) return false;
    }
    return true;

}

int main(int argc,char** argv){

    vector<Graph*> graphs;
    vector<int> graph_id;
    vector<Graph*> patterns;
    vector<int> pattern_id;

    string infile1 = argv[1];
    string infile2 = argv[2];

    int n = store_graphs(graphs,graph_id,infile1);
    int m = store_graphs(patterns,pattern_id,infile2);

    vector<vector<int>> arr(n,vector<int> (m));

    ifstream file;
    file.open("fv.txt",ios::in);
    file>>n>>m;
    for(int i = 0;i<n;i++){
        for(int j = 0;j<m;j++){
            file>>arr[i][j];
        }
    }
    file.close();

    cout<<"data pre-processing done"<<endl;

    string query_path;
    cout<<"Enter query file path: ";
    cin>>query_path;

    std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();

    vector<Graph*> queries;
    vector<int> query_id;
    int q = store_graphs(queries,query_id,query_path);

    cout<<n<<" "<<m<<" "<<q<<endl;

    vector<vector<int>> ans(q);   

    for(int t = 0;t<q;t++){
        cout<<t<<endl;
        vector<int> fv(m);
        for(int j = 0;j<m;j++){
            if (is_subgraph_isomorphic(patterns[j],queries[t])) fv[j] = 1;
            else fv[j] = 0;
        }

        for (int i = 0;i<n;i++)            
            if (subset(fv,arr[i])){
                // cout<<"subset "<<t<<" "<<i<<endl;
                if (is_subgraph_isomorphic(queries[t],graphs[i])){
                    // cout<<"isom "<<t<<" "<<i<<endl;
                    ans[t].push_back(graph_id[i]);
                }
            }
        
    }

    ofstream out;
    out.open("output_CS1190379.txt",ios::out);

    for(int i = 0;i<q;i++){
        for(int j = 0;j<ans[i].size();j++){
            out<<ans[i][j]<<"\t";
        }
        out<<"\n";
    }
    out.close();

    std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
    std::cout << "Total query time taken: " << std::chrono::duration_cast<std::chrono::milliseconds>(end - begin).count() << " ms" << std::endl;


}
