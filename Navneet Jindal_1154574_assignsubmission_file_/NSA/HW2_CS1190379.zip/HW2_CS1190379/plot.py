import matplotlib.pyplot as plt
import sys
import subprocess
from subprocess import Popen, PIPE
import time

cuts = [5,10,25,50,95]
gspan = []
gaston = []
fsg = []
for cut in cuts:
    st = time.time()
    print(['python3','mine.py', sys.argv[1], str(cut),'1'])
    subprocess.run(['python3','mine.py', sys.argv[1], str(cut),'1'], stdout=subprocess.PIPE)
    en = time.time()
    gspan.append(en-st)
    st = time.time()
    
    print(['python3','mine.py', sys.argv[1], str(cut),'2'])
    subprocess.run(['python3','mine.py', sys.argv[1],str(cut),'2'], stdout=subprocess.PIPE)
    en = time.time()
    gaston.append(en-st)

    st = time.time()
    
    print(['python3','mine.py', sys.argv[1], str(cut),'3'])
    subprocess.run(['python3','mine.py', sys.argv[1],str(cut),'3'], stdout=subprocess.PIPE)
    en = time.time()
    fsg.append(en-st)
    

plt.plot(cuts, gaston, '-o', markersize = 5, label = 'gaston')
plt.plot(cuts, gspan, '-o', markersize = 5, label = 'gspan')
plt.plot(cuts, fsg, '-o', markersize = 5, label = 'FSG')
plt.ylabel('Running Time(sec)')
plt.xlabel('Support Threshold(%)')
plt.legend()
plt.savefig(sys.argv[2] +".png")
