import os
import sys

def getCode(x):
    mul = 1
    val = 0
    for c in x:
        val = val + (ord(c)-ord('a')+1)*mul
        print(ord(c))
        mul = mul*26
    return val

def getSymb(x):
    mul = 26
    z = x%mul
    symb = ""
    while(z>0):
        symb = symb + chr(int(z+ord('a')-1))
        x = x/mul
        z = x%mul
    return symb

def filtergSpan(name, dic, sup):
    inname = "Mined_graphs/" + name
    with open(inname) as f:
        outlines = [line.rstrip('\n') for line in f]
    outlines = [ele for ele in outlines if ele != ""]
    newoutlines = []
    graphCount = 0
    curr = 0
    vertices = []
    edges = []
    numvertices = 0
    numedges = 0
    for line in outlines:
        if(curr==0):
            tstr = line[0:line.find('*')]
            tstr = tstr[1:]
            tstr = tstr.replace(" ", "")
            newoutlines.append(tstr)
            graphCount = graphCount + 1
            curr = 1
            numvertices = 0
            numedges = 0
            vertices = []
            edges = []
            continue
        elif(curr==1):
            if(line[0]=='v'):
                tmp = line.split()
                vertices.append(dic[int(tmp[2])])
                numvertices = numvertices + 1
            elif(line[0]=='e'):
                tmp = line[2:]
                edges.append(tmp)
                numedges = numedges + 1
            elif(line[0]=='x'):
                newoutlines.append(str(numvertices))
                newoutlines = newoutlines + vertices
                newoutlines.append(str(numedges))
                newoutlines = newoutlines + edges
                curr = 0
            continue
    
    fname = "Mined_graphs/minedgSpan.txt"
    with open(fname, 'w') as f:
        for line in newoutlines:
            f.write(f"{line}\n")

def filtergaston(name, dic, sup):
    inname = "Mined_graphs/" + name
    with open(inname) as f:
        outlines = [line.rstrip('\n') for line in f]
    outlines = [ele for ele in outlines if ele != ""]
    newoutlines = []
    graphCount = 0
    curr = 0
    vertices = []
    edges = []
    numvertices = 0
    numedges = 0
    outlines.pop(0)
    for line in outlines:
        if(curr==0):
            tstr = "#" + line[2:]
            newoutlines.append(tstr)
            graphCount = graphCount + 1
            curr = 1
            numvertices = 0
            numedges = 0
            vertices = []
            edges = []
            continue
        elif(curr==1):
            if(line[0]=='v'):
                tmp = line.split()
                vertices.append(dic[int(tmp[2])])
                numvertices = numvertices + 1
            elif(line[0]=='e'):
                tmp = line[2:]
                edges.append(tmp)
                numedges = numedges + 1
            elif(line[0]=='#'):
                newoutlines.append(str(numvertices))
                newoutlines = newoutlines + vertices
                newoutlines.append(str(numedges))
                newoutlines = newoutlines + edges
                curr = 0
            continue
    newoutlines.append(str(numvertices))
    newoutlines = newoutlines + vertices
    newoutlines.append(str(numedges))
    newoutlines = newoutlines + edges
    fname = "Mined_graphs/minedgaston.txt"
    with open(fname, 'w') as f:
        for line in newoutlines:
            f.write(f"{line}\n")

def filterfsg(name, dic, sup):
    inname = "Mined_graphs/" + name
    with open(inname) as f:
        outlines = [line.rstrip('\n') for line in f]
    outlines = [ele for ele in outlines if ele != ""]
    newoutlines = []
    vertices = []
    edges = []
    numvertices = 0
    numedges = 0
    for line in outlines:
        if(line[0]=='#'):
            continue
        elif(line[0]=='t'):
            if(numvertices!=0):
                newoutlines.append(str(numvertices))
                newoutlines = newoutlines + vertices
                newoutlines.append(str(numedges))
                newoutlines = newoutlines + edges
                numvertices = 0
                numedges = 0
                vertices = []
                edges = []
            tstr = line[4:line.find(',')]
            newoutlines.append(tstr)
            continue
        else:
            if(line[0]=='v'):
                tmp = line.split()
                vertices.append(dic[int(tmp[2])])
                numvertices = numvertices + 1
            elif(line[0]=='u'):
                tmp = line[2:]
                edges.append(tmp)
                numedges = numedges + 1
            continue

    newoutlines.append(str(numvertices))
    newoutlines = newoutlines + vertices
    newoutlines.append(str(numedges))
    newoutlines = newoutlines + edges

    fname = "Mined_graphs/minedfsg.txt"
    with open(fname, 'w') as f:
        for line in newoutlines:
            f.write(f"{line}\n")


with open(sys.argv[1]) as f:
    lines = [line.rstrip('\n') for line in f]
cnt = 0
for line in lines:
    if(len(line)==0):
        cnt = cnt + 1
lines = [ele for ele in lines if ele != ""]
nlines = []
vertices = -1
edges = -1
curr = 0
graphCount = 0
dic1={}
dic2 = {}

nums = 0
for line in lines:
    
    if(curr==0):
        tstr = "t # " + line[1:len(line)]
        nlines.append(tstr)
        graphCount = graphCount + 1
        curr = 1
    elif(curr==1):
        curr=2
        vertices = int(line)
        vcount = 0
        lcount = 0
        continue
    elif(curr==2):
        if(line not in dict.keys(dic1)):
            dic1[line] = lcount
            dic2[lcount] = line
            lcount = lcount + 1
        tstr = "v " + str(vcount) + " " +  str(dic1[line])
        nlines.append(tstr)
        vcount = vcount + 1
        if(vcount==vertices):
            curr=3
    elif(curr==3):
        curr=4
        edges = int(line)
        ecount = 0
    elif(curr==4):
        tstr = "e " + line
        nlines.append(tstr)
        ecount = ecount + 1
        if(ecount==edges):
            curr=0

if (os.path.exists("Mined_graphs")==False):
    os.mkdir("Mined_graphs")
os.system("rm -r Mined_graphs")
os.mkdir("Mined_graphs")

print(graphCount," Graphs")
with open('Mined_graphs/out.txt', 'w') as f:
    for line in nlines:
        f.write(f"{line}\n")



support = int(sys.argv[2])/100
mode = int(sys.argv[3])

if (mode==1):
    #gspan
    gspanCommand = "./gSpan-64 -f Mined_graphs/out.txt -s " + str(support) + " -o -i"
    os.system(gspanCommand)
    #output format: gspan
    filtergSpan("out.txt.fp", dic2, str(support))
    renameCommand = "mv Mined_graphs/out.txt.fp Mined_graphs/gspantids.txt"
    os.system(renameCommand)

elif (mode==2):
    # #gaston
    gastonSupport = support*graphCount
    gastonCommand = "./gaston " + str(gastonSupport) + " Mined_graphs/out.txt Mined_graphs/out.out"
    os.system(gastonCommand)
    #output format: gaston
    filtergaston("out.out", dic2, str(support))
    removeCommand = "rm Mined_graphs/out.out"
    os.system(removeCommand)
    
else:
    fsgSupport = support*100
    fsgCommand = "./fsg -t -s " + str(fsgSupport) + " -pt Mined_graphs/out.txt"
    os.system(fsgCommand)
    filterfsg("out.fp", dic2, str(support))
    removeCommand = "rm Mined_graphs/out.pc Mined_graphs/out.fp"
    os.system(removeCommand)
    renameCommand = "mv Mined_graphs/out.tid Mined_graphs/fsgtids.txt"
    os.system(renameCommand)

os.system("rm Mined_graphs/out.txt")
os.system("cp "+sys.argv[1]+" Mined_graphs/graphs.txt")