module load apps/anaconda/3
module load compiler/gcc/9.1.0
python3 mine.py $1 40 1
g++ index.cpp
./a.out $1 Mined_graphs/minedgSpan.txt