g++ query.cpp
./a.out Mined_graphs/graphs.txt Mined_graphs/minedgSpan.txt