#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <sstream>
#include <iterator>
#include <bits/stdc++.h>

#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/labeled_graph.hpp>
#include <boost/graph/vf2_sub_graph_iso.hpp>
#include <boost/property_map/property_map.hpp>

using namespace std;
using namespace boost;

typedef property<edge_name_t, string> edge_prop;
typedef property<vertex_name_t, string, property<vertex_index_t, int> > vertex_prop;

typedef adjacency_list<vecS, vecS, undirectedS, vertex_prop, edge_prop> Graph;

typedef property_map<Graph, vertex_name_t>::type vertex_name_map_t;
typedef property_map_equivalent<vertex_name_map_t, vertex_name_map_t> vertex_comp_t;

typedef property_map<Graph, edge_name_t>::type edge_name_map_t;
typedef property_map_equivalent<edge_name_map_t, edge_name_map_t> edge_comp_t;

const auto callback = [](auto&&, auto&&) {
	return false;
};

bool is_subgraph_isomorphic(Graph* smallGraph, Graph* bigGraph)
{
    vertex_comp_t vertex_comp =
        make_property_map_equivalent(get(vertex_name, *smallGraph), get(vertex_name, *bigGraph));
    edge_comp_t edge_comp =
        make_property_map_equivalent(get(edge_name, *smallGraph), get(edge_name, *bigGraph));
    // vf2_print_callback<Graph, Graph> callback(*smallGraph, *bigGraph);
    bool res = vf2_subgraph_iso(*smallGraph, *bigGraph, callback, vertex_order_by_mult(*smallGraph),
        edges_equivalent(edge_comp).vertices_equivalent(vertex_comp));
    return res;
}

int store_graphs(vector<Graph*>& graphs,vector<int>& graph_id, string infile){
    
    cout<<"Storing graphs at "<<infile<<endl;
    ifstream file;
    file.open(infile,ios::in);
    int num_graphs = 0;
    string word;
    while(file>>word){

        // cout<<num_graphs<<endl;
        if (word[0]!='#') continue;
        graph_id.push_back(stoi(word.substr(1)));

        Graph* g = new Graph();

        file>>word;
        int n = stoi(word);
        for(int i = 0;i<n;i++){
            file>>word;
            add_vertex(vertex_prop(word),*g);
        }
        file>>word;
        int m = stoi(word);
        for(int i = 0;i<m;i++){
            file>>word;
            int a = stoi(word);
            file>>word;
            int b = stoi(word);
            file>>word;
            add_edge(a,b,edge_prop(word),*g);
        }
        graphs.push_back(g);
        num_graphs++;

    }
    file.close();
    cout<<"stored graphs"<<endl;
    return num_graphs;
}

int main(int argc,char** argv){

    vector<Graph*> graphs;
    vector<int> graph_id;
    vector<Graph*> patterns;
    vector<int> pattern_id;

    string infile1 = argv[1];
    string infile2 = argv[2];

    int n = store_graphs(graphs,graph_id,infile1);
    int m = store_graphs(patterns,pattern_id,infile2);

    cout<<n<<" "<<m<<endl;
    cout<<graphs.size()<<" "<<patterns.size()<<endl;

    vector<vector<int>> arr(n,vector<int> (m,0));

    // for(int i = 0;i<n;i++){
    //     for(int j = 0;j<m;j++){
    //         cout<<i<<" "<<j<<endl;
    //         if (is_subgraph_isomorphic(patterns[j],graphs[i])) arr[i][j] = 1;
    //         else arr[i][j] = 0;
    //     }
    // }

    ifstream input;
    input.open("Mined_graphs/gspantids.txt",ios::in);
    string line;
    int pat_no = 0;
    while(getline(input,line)){
        std::istringstream ss(line);
        if (line.size()<=1) continue;
        char mode;
        ss >> mode;
        if (mode!='x') continue;
        int id;
        while(ss>>id){
            arr[id][pat_no] = 1;
        }
        pat_no++;

    }
    input.close();

    cout<<"writing feature vector"<<endl;
    ofstream file;
    file.open("fv.txt",ios::out);
    file<<n<<" "<<m<<"\n";
    for(int i = 0;i<n;i++){
        for(int j = 0;j<m;j++){
            file<<arr[i][j]<<" ";
        }
        file<<"\n";
    }
    file.close();
    cout<<"done indexing"<<endl;

}
