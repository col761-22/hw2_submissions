#!usr/bin/bash
git clone https://github.com/Navneet341/NSA.git
cd NSA
module load apps/anaconda/3
module load compiler/gcc/9.1.0
