[GITHUB-REPO]
https://github.com/pratikgujral/IITD-COL761-DataMining

[TEAM-MEMBERS]
Suyash Singh	2018CS50646
Yash Narendra	2021ANZ8639
Pratik Gujral	2021CSY7585

[CONTRIBUTIONS]
Each member contributed equally towards all portions of the assignment. We were all present in MS Teams calls doing the whole assignment through the 2 weeks so we helped each other in completing
Following are the major contributions:
Suyash Singh	:	33.33%	:	FP-Tree algorithm understanding and implementation, fixing bugs in Apriori
Yash Narendra	:	33.33%	:	Understanding working with HPC, implementation of Apriori algorithm, compilation and submitting jobs on HPC
Pratik Gujral	:	33.33%	:	Understanding working with HPC, explaining Apriori to team, Plotting code, evaluation of output, fixing Apriori bugs

[FILES-DESCRIPTION]
Assignment is done in C++

Apriori:-

1. 'main.cpp' - this function calls the 'apriori' function which requires input file name, directory of output file and the
                support threshold.

2. 'apriori.cpp' - This file implements the apriori algorithm to find the frequent itemsets for boolean association rule.
                   It has the following functions -

   1. differ(a,b)- finds the set difference between sets a and b.

   2. uSet(a,b,d) - finds union of set a and b and fills it in d.

   3. genCandy(fset) - generated candidate set at kth iteration with the help of frequent item set of k-1 th iteration.
      using a nested loop over the frequent item set at k-1 th iteration, we select union of 2 frequent sets if their
      set difference is 1 element and check whether all (size-1) subsets of their union has a match in the frequent subset list.
      If there is a match we include their union as a candidate.

   4. apriori (inputfile, outputfile, supportThreshold): Iterate over all the transactions to count for all the candidates via map.
      Based on this candidate map C1, we create F1, select those candidates whose frequency crosses the desired threshold. Now that
      we have initialised the candidate sets and frequent sets, we iteratively create the more candidate sets and frequent sets as
      follows - We generate the candidate sets using genCandy function. For all the candidates there we find their frequency by
      iterating through the transaction list. If frequency of none of the frequent sets crosses the threshold, we exit the loop and
      return the item sets, else we continue the loop to find more.

FPTree :-

Our two main data structures are headertable and FPtree but headertable is indirectly maintained inside the FPtree.
The graphnode in the FPtree has nodes which contains parent, children, count(frequency), id(unique item id) and lastly
the main pointer for maintaining the linked list for the header table which is "next" holds the next pointer to the
next graphnode in the linked list. The header table is maintained as a map from string to the linked list graph node
where the string is the unique item id and is the key for the map.

We have two main functions which are constree() and growtree().

constree() -> constructs the tree in such a manner that if a node is found then simply increments the count of the
node and goes to search among its children. If a node is not found then a new node is created with requisite values
and at the same time it is added to the corresponding linked list of the headertable node with corresponding unique
item id

growtree() -> takes as arguments the linked list of a particular item from the header table (this is where we shall
be constructing the conditional FPtree bottom-up) and also an array which represents the candidate set already obtained
from the nodes explored below.

The process of constree() and growtree() repeats itself until we reach the root node and we keep on storing
candidate sets which have been constructed from the leaf nodes already explored and with condition that they
have corresponding count >= minimumSupport threshold

The other support functions are for sorting and file output.

[Explanation of output plot]
SUPPORT = Support refers to how often a given rule appears in a transaction database.
Sup(A) = |A| / |T| where |A| is the number of transactions containing itemset A, and |T| refers to the total number of transactions
The key concept of Apriori algorithm is its anti-monotonicity of support measure [Source: GeeksForGeeks].

The plot is an exponentially decaying curve- running time reduces expoentially with increase in support threshold.
This is because when the support threshold is high, larger number of itemsets are pruned at every stage, 
reducing the number of permuations of itemsets exponentially. Another intuitive way to look at it is, that when the 
support threshold is 0%, the total number of permuations of itemsets is 2^N where N is the number of unique items 
in the transaction dataset.
------------------------------------------------------------------------------