#include <bits/stdc++.h>

using namespace std;

//mycandy is a candidate class which consists of an itemset and count of the itemset

class mycandy {
public:
    set<string> trans_set;
    unsigned int cnt;
};

//declarator for genCandy function which generates candidate set Ck from Fk-1

vector<mycandy> genCandy(vector<mycandy> fset);

//finds out the difference of two sets

set<string> differ(set<string> a, set<string> b)
{
  set<string> ret;
  for(auto x: a)
  {
    if(b.find(x)==b.end())
      ret.insert(x);
  }

  return ret;
}

//finds out the union of two sets a and b and stores it in d

void uSet(set<string> a, set<string> b, set<string> &d)
{
  for(auto x: a)
    d.insert(x);

  for(auto x: b)
    d.insert(x);
}

//apriori function, main function

void apriori(const string ifile, const string ofile, double minisupport){
    map<string, double> c1; // map for candidate set 1
    ifstream inF(ifile);
    if (!inF) {
        cout << "File does not exist!";
        exit(1);
    }

    long long totCt = 0; // total transaction count
    string str;
    while(getline(inF, str)) { // read input from the file line by line
      totCt++;
      istringstream ist(str); // parse the line to obtain different items
      for(string id ;ist >> id;)
          c1[id]++;  // increment that items count
    }

  // fset_collection is the collection for frequency sets from F1 to Fk-1
  vector<vector<mycandy>> fset_collection;

  vector<mycandy> f1; // first frequency set
	auto it = c1.begin();

  while(it != c1.end()) {
      double freq = it->second * 1.0 / totCt; // cacluate frequency

      if (freq >= minisupport) { // if greater than support then push in f1
          mycandy candy;
          candy.trans_set.insert(it->first);
          candy.cnt = it->second;
          f1.push_back(candy);
      }
      it++;
    }

    fset_collection.push_back(f1); //f1 added to the collection

    //Algorithm running and generating ck's and fk's and stops when fk is empty

    while(true){
        vector<mycandy> ck = genCandy(fset_collection[fset_collection.size()-1]);

        inF.clear();                    // resets flags
        inF.seekg(0, inF.beg);

        while(getline(inF, str)) {
            istringstream ist(str);
            set<string> currTrans;
            for(string x; ist >> x;) {
                currTrans.emplace(x);
            }

            auto it2 = ck.begin();
            while(it2 != ck.end()) {
                bool check = true;

                for(auto x: it2->trans_set)
                {
                  if(currTrans.find(x)==currTrans.end())
                  {
                    check = false;
                    break;
                  }
                }

                if(check) {
                    it2->cnt++;
                }
                ++it2;
            }
        }
        vector<mycandy> fset;

        for(auto &currcand: ck) {
            if (((currcand.cnt * 1.0)/ totCt) >= minisupport) {
                fset.emplace_back(currcand);
            }
        }

        if(fset.size() == 0){
            break;
        }
        else{
            fset_collection.emplace_back(fset);
        }

    }

  // output in the requisite order as asked in the assignment
	vector<string> outrs;
	for(auto &fset : fset_collection) {

		 for(auto &currcand : fset) {
			string output_line="";

			vector<string> vec_items;

			for(auto &id : currcand.trans_set)
				vec_items.push_back(id);

			sort(vec_items.begin(), vec_items.end());

      for(auto id : vec_items) {
				output_line = output_line + id + " ";
      }
			output_line = output_line.substr(0, output_line.length()-1);
			outrs.push_back(output_line);
		}
	}
	sort(outrs.begin(), outrs.end());

	ofstream outFile(ofile);
  for (auto id : outrs)
  {
      outFile << id << "\n";
  }
	outFile.close();
  inF.close();
}

vector<mycandy> genCandy(vector<mycandy> fset){
vector<mycandy> ck;

/*
These loops iterate over the current frequency set and finds two sets such that
they differ by only a single element using the function differ() and then find
their union. After that the while loop does subset checking which makes sure
all subsets are "frequent" and then goes on to further add to next candidate set
and returns it
*/

auto f1 = fset.begin();
while(f1 != fset.end()){
    auto f2 = f1+1;
    while(f2 != fset.end()) {
        set<string> diff;

        diff = differ(f2->trans_set, f1->trans_set);

        if (diff.size() == 1) {
            mycandy candy;
            candy.cnt = 0;

            uSet(f1->trans_set, diff, candy.trans_set);

            bool result = false;
            auto its = candy.trans_set.begin();
            while(its != candy.trans_set.end()) {
                auto excluded = (*its);
                auto temp = candy.trans_set;
                temp.erase(excluded);

                int i=0;
                while(i < fset.size())
                {
                  if(fset[i].trans_set==temp)
                  {
                    result = true;
                    break;
                  }
                  i++;
                }

                if (result == false) {
                    break;
                }
                ++its;
            }
            if(result == true) {
                bool flag = true;

                for(auto &elem : ck) {
                    if (elem.trans_set == candy.trans_set){
                        flag = false;
                        break;
                    }
                }

                if (flag)
                    ck.push_back(candy);
            }
        }
        f2++;
    }
    f1++;
}
return ck;
}
