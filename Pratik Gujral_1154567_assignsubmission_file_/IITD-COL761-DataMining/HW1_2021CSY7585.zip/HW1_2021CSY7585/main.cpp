#include <bits/stdc++.h>

using namespace std;

void apriori(const string ifile, const string ofile, double minimumSupport);

int main(int argc, char* argv[]) {

    double minimumSupport = atoi(argv[1]) * 1.0 / 100;
    string ifile = argv[2];
    string ofile = argv[3];
    apriori(ifile, ofile + ".txt", minimumSupport);

    return 0;
}
