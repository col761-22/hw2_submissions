#!/bin/bash

if [ "$1" == "-plot" ]; then
	python3 plot.py $2 $3
elif [ "$1" == "-apriori" ]; then
	./apriori $3 $2 $4
elif [ "$1" == "-fptree" ]; then
	./fptree $3 $2 $4
else
	echo "Arguments are invalid"
fi 
