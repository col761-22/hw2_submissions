#include <bits/stdc++.h>

using namespace std;

long long num_transactions;
float minsup;
map<string, long long> global_order; //for ties
ofstream ofile;
//map<long long, long long>* global_count_map;
vector<vector<string>> sortedList;

class Node
{
public:
	string item;
	long long count;
	vector<Node*> children;
	Node* parent; //add if needed

	Node()
	{
		item = "-1";
	}
	Node(string id, Node* par, long long c)
	{
		item = id;
		count = c;
		parent = par;
	}

};


bool sortFunction(const pair<string,long long> first, const pair<string,long long> second);
bool filterFunction(const pair<string, long long> elem);
void createFPTree(vector<pair<string,long long>> transactions, Node* tree, map<string, vector<Node*>>* headerTable);
void FPGrowth(vector<Node*> node_list, vector<string> candidate_set);
void printTree(Node node, long long level);
static bool compares(vector<string> a, vector<string> b);

static bool compares(vector<string> a, vector<string> b)
{
  string as = "";
  for(string x: a)
  {
    as += x;
    as += " ";
  }

  string bs = "";
  for(string x: b)
  {
    bs += x;
    bs += " ";
  }

  return as < bs;
}

bool sortFunction(const pair<string,long long> first, const pair<string,long long> second)
{
	return (first.second > second.second);
	//random comment to increase 1 line
}

bool newSortFunction(const pair<string,long long> first, const pair<string,long long> second)
{
	/*if((*global_count_map)[first.first] > (*global_count_map)[second.first])
		return true;
	else if((*global_count_map)[first.first] == (*global_count_map)[second.first]) //breaking ties
	{
		if(global_order[first.first] < global_order[second.first])
			return true;
	}*/
	return global_order[first.first] < global_order[second.first];
}

bool filterFunction(const pair<string, long long> elem) //change this acc to num_transactions??????????
{
	return ( ((elem.second * 1.0)/ num_transactions)  < minsup);
	// return ((float)((elem.second * 1.0) / num_transactions)  < minsup);
}

/*bool filterByMap(const pair<long long, long long> elem)
{
	return ( ((*global_count_map)[elem.first]*1.0)/num_transactions < minsup);
}*/


void printTree(Node node, long long level)
{
	vector<Node*>::iterator it;
	for(it = node.children.begin(); it != node.children.end(); it++)
	{
		cout << "ON LEVEL " << level << endl;
		cout << (**it).item << ":" << (**it).count << endl;
		printTree(**it, level+1);
	}
	cout << endl;
}

void printItem(vector<string> items)
{
	for(long long i = 0; i < items.size(); i++)
		ofile << items[i] << " ";
	ofile << endl;
}


int main(int argc, char* argv[])
{
	if(argc !=4)
	{
		cout << "Please enter 3 arguments" << endl;
		exit(1);
	}

	string input_file, output_file;
	ifstream inFile;
	map<string,long long> count_map;

	input_file = argv[2];
	minsup = (atoi(argv[1])*1.0) / 100;
	output_file = string(argv[3]);

	inFile.open(input_file);
	if(!inFile)
	{
		cout << "File doesn't exist" << endl;
		exit(1);
	}

	//first DB scan for getting 'flist' order
	// cout << "first db scan\n";
	num_transactions = 0;
	string line;
	while(getline(inFile, line))
	{
		num_transactions++;
		istringstream iss(line);
		for(string s; iss >> s; )
			count_map[s]++;
	}
	inFile.close();

	vector<pair<string,long long> > flist(count_map.begin(), count_map.end()); //copying map elements to vector
	flist.erase(remove_if(flist.begin(), flist.end(), &filterFunction ) , flist.end()); //removing those less than minsup
	sort(flist.begin(),flist.end(),&sortFunction); //sort by support

	//print flist
	// vector<pair<long long,long long> >::iterator it2;
	// for(it2 = flist.begin(); it2 != flist.end(); it2++)
	// {
	// 	cout << it2->first << ": " << it2->second << endl;
	// }

	//can this be improved??
	// cout << "GLOBAL ORDER\n";
	for(long long i = 0; i < flist.size(); i++)
		global_order[flist[i].first] = i;

	//global_count_map = &count_map;

	map<string,vector<Node*>> headerTable; //header table
	Node tree; //FP Tree

	//parse input and call fp tree
	// cout << "second db scan\n";
	inFile.open(input_file);
	//long long check = 1;
	while(getline(inFile, line))
	{
		// cout << "adding transaction " << check << endl;
		vector<pair<string,long long>> transaction_items;
		istringstream iss(line);
		for(string s; iss >> s; )
		{
			//long long item = stoi(s);
			if( (count_map[s]*1.0 / num_transactions) >= minsup) //only add if sup > minsup
				transaction_items.push_back(make_pair(s, 1));
		}

		//sort by frequency in count_map
		// sort(transaction_items.begin(), transaction_items.end(), Local(count_map)); //
		sort(transaction_items.begin(), transaction_items.end(), &newSortFunction); //
		createFPTree(transaction_items, &tree, &headerTable);
		//check++;
	}

	// cout << "TREE CREATED!!!" << endl;
	// printTree(tree, 1);
	for(long long i = flist.size()-1; i >= 0; i--)
		FPGrowth(headerTable[flist[i].first], vector<string>());

	ofile.open(output_file);

	sort(sortedList.begin(), sortedList.end(), compares);

	for(auto x: sortedList)
		printItem(x);

	ofile.close();

}

void createFPTree(vector<pair<string, long long>> transactions, Node* tree, map<string, vector<Node*>>* headerTable)
{
	Node* curNode = tree;
	vector<pair<string,long long> >::iterator it;
	for(it = transactions.begin(); it != transactions.end(); it++)
	{
		vector<Node*>::iterator it1;
		bool found = false;
		for(it1 = (*curNode).children.begin(); it1 != (*curNode).children.end(); it1++)
		{
			if((**it1).item == (*it).first)
			{
				found = true;
				break;
			}
		}

		if(found) //increase count, change cur_node to this node -> no change to be made in headertable?
		{
			// cout << "Found\n";
			(**it1).count += (*it).second;
			curNode = *it1;
		}

		if(!found) //create a new child for curnode, change cur_node to the new node
		{
			Node* new_node = new Node( (*it).first, curNode, (*it).second );
			(*curNode).children.push_back(new_node);
			(*headerTable)[(*it).first].push_back(new_node);
			curNode = new_node;
		}
	}
}

void FPGrowth(vector<Node*> node_list, vector<string> candidate_set )
{
	long long count = 0;

	for(long long i = 0; i < node_list.size(); i++)
		count += node_list[i]->count;


	if( (count*1.0/num_transactions) >= minsup) //threshold for now --> change later
	{
		//candidate_set.push_back(node_list[0]->item);
		candidate_set.insert(candidate_set.begin(), node_list[0]->item);

		vector<string> temper = candidate_set;

		/*for(auto x: candidate_set)
			temper.push_back(to_string(x));*/

		sort(temper.begin(), temper.end());

		sortedList.push_back(temper);
		//printItem(candidate_set);
		map<string, long long> item_count;

		// vector<vector<pair<long long, long long> > > all_transactions(node_list.size());
		//create a new flist (first scan) and store transactions
		for(long long i = 0; i < node_list.size(); i++)
		{
			//keep going to parent till -1
			Node* next_item = node_list[i]->parent;
			while(next_item->item != "-1")
			{
				item_count[next_item->item] += node_list[i]->count;
				// all_transactions[i].push_back(make_pair(next_item->item, node_list[i]->count) );
				next_item = next_item->parent;
			}
		}

		//global_count_map = &item_count;

		vector<pair<string,long long> > new_flist(item_count.begin(), item_count.end()); //copying map elements to vector
		new_flist.erase(remove_if(new_flist.begin(), new_flist.end(), &filterFunction ) , new_flist.end()); //removing those less than minsup
		sort(new_flist.begin(),new_flist.end(), &newSortFunction); //sort by support

		//print new flist
		// cout << "new flist " << endl;
		// for(long long i = 0; i < new_flist.size(); i++)
		// {
		// 	cout << new_flist[i].first << ": " << new_flist[i].second << endl;
		// }

		//create new tree (second scan)
		Node new_tree;
		map<string, vector<Node*>> new_headerTable; //header table

		// for(long long i = 0; i < node_list.size(); i++)
		// {
		// 	if(all_transactions[i].size() == 0) //is this nec?
		// 		continue;
		// 	vector<pair<long long, long long> > transactions = all_transactions[i];
		// 	transactions.erase(remove_if(transactions.begin(), transactions.end(), &filterByMap ) , transactions.end()); //removing those less than minsup
		// 	sort(transactions.begin(), transactions.end(), &newSortFunction);
		// 	createFPTree(transactions, &new_tree, &new_headerTable);
		// }

		for(long long i = 0; i < node_list.size(); i++)
		{
			vector<pair<string, long long>> transactions;
			Node* next_item = node_list[i]->parent;
			while(next_item->item != "-1")
			{
				if( (item_count[next_item->item]*1.0/num_transactions) >= minsup)
				{
					transactions.push_back(make_pair(next_item->item, node_list[i]->count));
				}
				next_item = next_item->parent;
			}
			sort(transactions.begin(), transactions.end(), &newSortFunction);

			// cout << "printing next transaction\n";
			// for(long long j = 0; j < transactions.size(); j++)
			// {
			// 	cout << transactions[j].first << ": " << transactions[j].second << ": " << global_order[transactions[j].first] << endl ;
			// }

			createFPTree(transactions, &new_tree, &new_headerTable);
		}



		// printTree(new_tree, 1);
		for(long long i = new_flist.size()-1 ; i >= 0; i--)
		{
			FPGrowth(new_headerTable[new_flist[i].first],candidate_set);
		}

	}
}
