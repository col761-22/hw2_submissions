from matplotlib import pyplot as plt
import timeit
import time
import sys
import subprocess
import os

inputfile = sys.argv[1]
outputfile = sys.argv[2] + ".png"
thresholds = [5, 10, 25, 50, 90]
# assuming fptree takes arguments X inputfile outfilename

execution_times_apriori = []
execution_times_fptree = []

for threshold in thresholds:
    print("Threshold:", threshold)
    # Apriori
    print(".......Apriori")
    start_time = time.time()
    subprocess.call(["apriori", str(threshold) , inputfile , outputfile])
    execution_time_apriori = time.time() - start_time
    execution_times_apriori.append(execution_time_apriori)
    
    # FP-Tree
    print(".......FP-Tree")
    start_time = time.time()
    subprocess.call(["fptree", str(threshold) , inputfile , outputfile])
    execution_time_fptree = time.time() - start_time
    execution_times_fptree.append(execution_time_fptree)
    

plt.figure()
plt.plot(thresholds, execution_times_apriori, label='apriori')
plt.plot(thresholds, execution_times_fptree, label='fptree')
plt.title('Comparison of execution time')
plt.xlabel('Support threshold')
plt.ylabel('Execution Time (s)')
plt.legend()
plt.savefig(outputfile)
