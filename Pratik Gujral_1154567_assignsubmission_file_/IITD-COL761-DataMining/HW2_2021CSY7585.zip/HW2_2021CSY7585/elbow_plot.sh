#!/bin/bash
python3 col761_a2_q3.py $1 $2 $3