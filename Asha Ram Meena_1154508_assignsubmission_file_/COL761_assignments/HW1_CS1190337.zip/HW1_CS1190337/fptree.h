#include <bits/stdc++.h>


using namespace std;


class node {
public:
    int key, value, temp_value = 0;
    unordered_map<int, node*> child;
    node *link = NULL, *parent, *temp_link = NULL;
    

    node(int key = -1, int value = 0, node *parent = NULL) {
        this->key = key;
        this->value = value;
        this->parent = parent;
    }

    void inc_val(int val = 1) {
        value += val;
    }

    // return true if create a new child
    bool insert_child(int k, int val = 1) {
        if (child.count(k)) {
            child[k]->inc_val(val);
            return false;
        }
        else {
            child.insert({k, new node(k, val, this)});
            return true;
        }
    }

};


class fptree {
public:
    static int num_transac;
    static vector<vector<int> > freq_itemsets;
    static double support;
    static double num_support;
    // ordered according to their importance
    static unordered_map<int, int> item_importance;
    static vector<int> f_items;
    vector<int> items;
    int least_important = -1;
    unordered_map<int, node*> headers;
    node *root;

    fptree() {
        root = new node();
    }

    void run(string filename, double support) {
        this->support = support;
        std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();
        first_scan(filename);
        std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
        num_support = support*num_transac;
        cout << "First scan finished in " << std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count()/1000 << "[ms]" << endl;
        
        begin = std::chrono::steady_clock::now();
        second_scan(filename);
        end = std::chrono::steady_clock::now();
        cout << "Created fp tree in " << std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count()/1000 << "[ms]" << endl;
        
        
        vector<int> v= {};
        
        begin = std::chrono::steady_clock::now();
        generate_itemsets(v);
        fix_items();
        cout << "Generated itemsets in " << std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count()/1000 << "[ms]" << endl;
    }

    void fix_items() {
        for (auto &itemset: freq_itemsets) {
            for (auto &item: itemset) {
                item = f_items[item];
            }
        }
    }

    void first_scan(string filename) {
        unordered_map<int, int> freq;
        ifstream file(filename);

        if (file.is_open()) {
            string line;
            while (getline(file, line))
            {
                istringstream ss(line);
                int input;
                num_transac++;
                while (ss >> input)
                    freq[input]++;
            }
        }
        vector<pair<int, int> > temp;
        for (auto p: freq)
            temp.push_back({p.second, p.first});
        sort(temp.begin(), temp.end());
        for (int i=0; i<temp.size(); i++) {
            item_importance.insert({temp[i].second, i});
            if (least_important == -1) {
                if (check_for_support(temp[i].first)) {
                    least_important = i;
                    items.push_back(i);
                }   
            }
            else 
                items.push_back(i);
            f_items.push_back(temp[i].second);
            
        }
    }

    // (freq, key)
    void initialize_tree(vector<pair<int, int> > &initial_freq) {
        for (auto p: initial_freq)
            root->insert_child(p.second, p.first);
    }

    static bool comp_transac(int &item1, int &item2) {
        return item_importance[item1] > item_importance[item2];
    }

    void second_scan(string filename) {
        ifstream file(filename);
        if (file.is_open()) {
            string line;
            while (getline(file, line))
            {
                // cout << line << endl;
                
                istringstream ss(line);
                int input;
                vector<int> v;

                while (ss >> input)
                    if (item_importance[input] >= least_important)
                        v.push_back(item_importance[input]);
                
                sort(v.begin(), v.end(), greater<int>());
                insert_transaction(v);
            }   
        }
    }

    void link_headers(int &key, node *n) {
        if (headers.count(key)) {
            // assert(n->link != headers[key]);
            n->link = headers[key];
        }
        headers[key] = n;
    }

    void insert_transaction(vector<int> &transaction, int val = 1) {
        node *cur = root;
        for (auto item: transaction) {
            bool created = cur->insert_child(item, val);
            cur = cur->child[item];
            if (created)
                link_headers(item, cur); 
        }
    }

    void generate_itemsets(vector<int> &v) {
        for (auto item: items)
            condition_on(v, headers[item]);
    }

    bool check_for_support(int count) {
        return 100.0*count - num_support >= -0.000001; 
    }

    void reset_temp_links(node *n) {
        node *cur = n;
        while (cur) {
            node *temp = cur->temp_link;
            cur->temp_link = NULL;
            cur = temp;
        }
    }

    void condition_on(vector<int> &v, node *start) {
        if (start == NULL || start->key == -1)
            return;
        // cout << start->key << endl;
        node *cur = start;
        int counter = 0, paths = 0;
        while (cur) {
            counter += cur->value;
            paths++;
            cur = cur->link;
        }
        // cout << "Cool " << counter << " " << num_support << " " << paths << endl;
        if (!check_for_support(counter)) {
            return;
        }

        cur = start;
        v.push_back(cur->key);

        freq_itemsets.push_back(v);
        if (paths > 1) {
            fptree *f = new fptree();
            unordered_set<int> new_items;
            while (cur) {
                node *n = cur->parent;
                vector<int> transac;
                // cout << cur->key << " " << n->key << endl;
                while (n->key != -1) {
                    transac.push_back(n->key);
                    new_items.insert(n->key);
                    n = n->parent;
                }
                reverse(transac.begin(), transac.end());
                f->insert_transaction(transac, cur->value);
                cur = cur->link;
            }
            
            for (auto item: new_items)
                f->items.push_back(item);

            f->generate_itemsets(v);
            delete f;
        }
        else {
            // generate all subsets
            // cout << "Here " << cur->key << " " << cur->parent->key << endl;
            cur = cur->parent;
            vector<int> transac;
            
            while (cur->key != -1) {
                transac.push_back(cur->key);
                cur = cur->parent;
            }
            
            // cout << "transac size: " <<  transac.size() << endl;

            int n = transac.size();
            for (int i=1; i<(1<<n); i++) {
                vector<int> tmp = v;
                // cout << i << endl;
                for (int j=0; j<n; j++) {
                    if (i & (1<<j))
                        tmp.push_back(transac[j]);
                }
                freq_itemsets.push_back(tmp);
            }
            // cout << "done" << endl;
        }
        

        v.pop_back();
        

    }

};



int fptree::num_transac = 0;
vector<vector<int> > fptree::freq_itemsets = {};
double fptree::support = 0;
double fptree::num_support = 0;
// ordered according to their importance
unordered_map<int, int> fptree::item_importance = {};
vector<int> fptree::f_items = {};
// vector<int> fptree::items = {};

