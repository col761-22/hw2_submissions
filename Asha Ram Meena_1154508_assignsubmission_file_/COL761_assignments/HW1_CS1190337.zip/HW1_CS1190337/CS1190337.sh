
if [ "$1" = "-plot" ]
then
	support=(5 10 25 50 90)
	time_fp=()
	time_ap=()
	for i in ${!support[@]}; do
	  start_time=`date +%s%3N`
	  ./a.out 1 $2 ${support[$i]} output.dat
	  endtime=`date +%s%3N`
	  time_fp+=($(( $endtime - $start_time )))
	  start_time=`date +%s%3N`
	  ./ap.out $2 ${support[$i]} output.dat
	  endtime=`date +%s%3N`
	  time_ap+=($(( $endtime - $start_time )))
	  # echo "${time_ap[$i]} ${time_fp[$i]}"
	done
	for i in ${!support[@]}; do
		echo "${support[$i]}" "${time_fp[$i]}"
	done > fptree
	for i in ${!support[@]}; do
		echo "${support[$i]}" "${time_ap[$i]}"
	done > apriori
	gnuplot <<- EOF
		set xlabel "support"
		set ylabel "time"
		set title "support vs time"
		set terminal png
		set output "$3.png"
		plot 'fptree'  with lines, 'apriori' with lines
		set output
	EOF
else
	if [ "$1" = "-fptree" ]
	then
		echo $2
		./a.out 1 $2 $3 $4
	else
		./ap.out $2 $3 $4
	fi
fi