#!usr/bin/bash
git clone git@github.com:uchiha-asha/COL761_assignments.git
cd COL761_assignments
unzip HW1_CS1190337.zip
cd HW1_CS1190337
module load compiler/gcc/7.1.0/compilervars