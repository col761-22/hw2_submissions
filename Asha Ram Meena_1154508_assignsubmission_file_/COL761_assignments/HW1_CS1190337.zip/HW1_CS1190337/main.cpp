#include "fptree.h"

bool lexo_comp(vector<string> &v1, vector<string> &v2) {
    for (int i=0; i<min(v1.size(), v2.size()); i++) {
        if (v1[i] < v2[i])
            return true;
        if (v1[i] > v2[i])
            return false;
    }
    return v1.size() < v2.size();
}

vector<vector<string> > lexo_sort(vector<vector<int> > &itemsets) {
    vector<vector<string> > lexo_v;
    for (auto itemset: itemsets) {
        vector<string> v;
        for (auto item: itemset) {
            v.push_back(to_string(item));
        }
        sort(v.begin(), v.end());
        lexo_v.push_back(v);
    }
    sort(lexo_v.begin(), lexo_v.end(), lexo_comp);
    return lexo_v;
}

int main(int argc, char *argv[]) {
    printf("%s %s %s\n", argv[1], argv[2], argv[3]);
    std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();
    if (stoi(argv[1]) == 1) {

        fptree *f = new fptree();
        f->run(argv[2], stoi(argv[3]));

        vector<vector<string> > res = lexo_sort(f->freq_itemsets);
        
        ofstream out(argv[4]);
        for (auto v: res) {
            for (int i=0; i<v.size(); i++) {
                out << v[i];
                if (i!=int(v.size())-1)
                    out << " ";
            }
            out << "\n";
        }
        out.flush();
    }
    
    std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
    std::cout << "Time difference = " << std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count()/1000 << "[ms]" << std::endl;
    
}