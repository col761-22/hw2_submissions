module load compiler/gcc/9.1.0

g++ -std=c++11 -O3 main.cpp
g++ -std=c++11 -O3 apriori.cpp -o ap.out