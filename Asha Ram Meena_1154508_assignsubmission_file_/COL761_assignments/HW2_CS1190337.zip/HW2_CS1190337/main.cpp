#include "utils.h"


// module load compiler/gcc/11.2.0
// module load lib/boost/1.72.0/gnu

int main(int argc, char *argv[]) {
	int mode = atoi(argv[1]);

	if (mode == 1) {
		convert(argv[2]);
	}

	else if (mode == 2) {
		std::vector<graph_type> feature_graphs_tmp, feature_graphs;
		std::ifstream file_converted("convert.txt");
		std::ifstream file_feature_graph("feature.txt");
		std::ofstream file_vector("vector.txt");

		load_feature_graphs(file_feature_graph, feature_graphs_tmp);
		prune_feature_graphs(feature_graphs_tmp, feature_graphs);
		generate_vectors(file_converted, file_vector, feature_graphs);	
	}

	else if (mode == 3) {
		std::vector<graph_type> feature_graphs_tmp, feature_graphs;
		std::vector<std::pair<std::string, std::bitset<M> > > feature_vectors;
		std::unordered_map<std::string, graph_type> database;

		std::ifstream file_converted("convert.txt");
		std::ifstream file_feature_graph("feature.txt");
		std::ifstream file_feature_vector("vector.txt");
		
		std::ofstream file_output("output_CS1190337.txt");

		load_database(file_converted, database);
		load_feature_graphs(file_feature_graph, feature_graphs);
		prune_feature_graphs(feature_graphs_tmp, feature_graphs);
		load_feature_vectors(file_feature_vector, feature_vectors);
		std::cout << "Index loaded successfully. Please enter query file" << std::endl;

		std::string query;
		std::cin >> query;
		
		std::ifstream file_query(query);

		std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();

		answer_queries(file_query, file_output, feature_graphs, feature_vectors, database);

		std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
    	std::cout << "Time taken is " << std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count()/1000 << "ms" << std::endl;
	}

}
