import numpy as np
import matplotlib.pyplot as plt
import pandas as pd 
import sys
import sklearn
from sklearn.cluster import KMeans

k_poss_vals = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]

def main():
	datafile = sys.argv[1]
	dataread = open(datafile,'r')
	data_array_temp = dataread.read()
	data_array = data_array_temp.split("\n")
	dim = sys.argv[2]
	X=[]
	Y=[]
	for i in data_array:
		if(len(i)==0):
			continue
		l=[]
		temp = i.strip().split(" ")
		for j in temp:
			l.append(j)
		X.append(l)
	X=np.array(X)
	for k in k_poss_vals:
		model = KMeans(n_clusters=k,random_state=0)
		model=model.fit(X)
		Y.append(model.inertia_)
	dataread.close()
	plt.title("Elbow Plot")
	plt.ylabel("Within-Cluster-Sum-of-Squares (WCSS)")
	plt.xlabel("No. of Clusters",)
	plt.plot(Y)
	plt.savefig(sys.argv[3])

if __name__ == "__main__":
	main()