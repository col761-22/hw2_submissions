#!usr/bin/bash
git clone https://github.com/uchiha-asha/COL761_assignments.git
cd COL761_assignments
module load compiler/gcc/11.2.0
module load lib/boost/1.72.0/gnu
module load compiler/intel/2019u5/intelpython3