#include <bits/stdc++.h>
#include <boost/graph/adjacency_list.hpp>
// #include <boost/graph/vf2_sub_graph_iso.hpp>
#include "a.hpp"
#include <boost/graph/graphviz.hpp>

using namespace boost;

// vertex
struct vertex_type {
    int label;
    vertex_type(int l = 0) : label(l) {}

    bool operator==(vertex_type const& other) const {
        return label == other.label;
    }
};

// edge
struct edge_type {
    int label;
    edge_type(int l = 0) :label(l) {}

    bool operator==(edge_type const& other) const {
        return label == other.label;
    }
};


typedef adjacency_list< vecS, vecS, undirectedS, vertex_type, edge_type > graph_type;


#define M 256


void convert(std::string input)
{
	std::ifstream file(input);
	std::ofstream out("convert.txt");
	if (file.is_open()) {
		std::string line;
		int STATE = 0, num_nodes = 0, num_edges = 0, i=0, count = 0;
		while (getline(file, line)) {
			if (STATE == 4) {
				out << "e " << line << "\n";
				num_edges--;
				if (num_edges == 0)
					STATE = 5;
			}
			else if (STATE == 2) {
				int x = 0;
				for (auto c: line) {
					x = x*256 + c;
				}
				out << "v " << i << " " << x << "\n";
				i++;
				if (i==num_nodes)
					STATE = 3, i = 0;
			}
			else if (STATE == 0) {
				count++;
				out << "t # " << line.substr(1) << "\n";
				STATE = 1;
			}
			else if (STATE == 1) {
				std::istringstream ss(line);
				ss >> num_nodes;
				STATE = 2;
			}
			else if (STATE == 3) {
				std::istringstream ss(line);
				ss >> num_edges;
				STATE = 4;
			}
			else if (STATE == 5) {
				STATE = 0;
			}
		}
		std::cout << count << std::endl;
	}
}

bool create_graph_from_file1(std::ifstream &file, graph_type &graph)
{
	std::string line;
	int STATE = 0, num_nodes = 0, num_edges = 0, i=0, a, b, c;
	bool not_empty = false;

	while (getline(file, line)) {
		std::istringstream ss(line);
		if (STATE == 4) {
			ss >> a >> b >> c;
			num_edges--;
			add_edge(a, b, edge_type(c), graph);
			if (num_edges == 0)
				STATE = 5;
		}
		else if (STATE == 2) {
			int x = 0;
			for (auto c: line) {
				x = x*256 + c;
			}
			not_empty = true;
			add_vertex(vertex_type(x), graph);
			i++;
			if (i==num_nodes)
				STATE = 3, i = 0;
		}
		else if (STATE == 0) {
			STATE = 1;
		}
		else if (STATE == 1) {
			ss >> num_nodes;
			STATE = 2;
		}
		else if (STATE == 3) {
			ss >> num_edges;
			STATE = 4;
		}
		else if (STATE == 5) {
			STATE = 0;
			break;
		}
	}
	return not_empty;
}


bool create_graph_from_file2(std::ifstream &file, graph_type &graph, std::string &id)
{
	std::string line;
	int a, b, c;
	char d;
	bool not_empty = false;

	while (getline(file, line)) {
		std::istringstream ss(line);
		ss >> d;
		if (d == 'v') {
			ss >> a >> b;
			add_vertex(vertex_type(b), graph);
			not_empty = true;
		}
		else if (d == 'e') {
			ss >> a >> b >> c;
			add_edge(a, b, edge_type(c), graph);
		}
		else if (d == 't') {
			ss >> d >> id;
			break;
		}
		else {
			break;
		}
	}

	return not_empty;
}


void load_database(std::ifstream &file, std::unordered_map<std::string, graph_type> &database)
{
	std::string s, id;
	getline(file, s);
	id = s.substr(4);
	while (true) {
		graph_type graph;
		s = id;
		if (create_graph_from_file2(file, graph, id)) {
			database.insert({s, graph});
		}
		else {
			break;
		}
	}
}


void load_feature_graphs(std::ifstream &file, std::vector<graph_type> &feature_graphs)
{
	std::string s;
	getline(file, s); // remove first line
	while (true) {
		graph_type graph;
		if (create_graph_from_file2(file, graph, s)) {
			// boost::write_graphviz(std::cout, graph);
			feature_graphs.push_back(graph);
		}
		else {
			break;
		}
	}
}


const auto cb = [](auto&&, auto&&) {
	return false;
};


inline bool isomorphism(graph_type &graph1, graph_type &graph2)
{
	return vf2_subgraph_mono(graph1, graph2, cb,
					vertex_order_by_mult(graph1),
             		edges_equivalent(make_property_map_equivalent(get(edge_bundle, graph1), get(edge_bundle, graph2))).
             		vertices_equivalent(make_property_map_equivalent(get(vertex_bundle, graph1), get(vertex_bundle, graph2))));
}


void create_features(graph_type &graph, std::vector<graph_type> &feature_graphs, std::bitset<M> &features)
{	
	for (int i=0; i<std::min(M, int(feature_graphs.size())); i++) {
		features[i] = isomorphism(feature_graphs[i], graph);
	}
}


void generate_vectors(std::ifstream &file, std::ofstream &out_file, std::vector<graph_type> &feature_graphs)
{
	std::string s, id;
	getline(file, s);
	id = s.substr(4);
	while (true) {
		graph_type graph;
		s = id;
		if (create_graph_from_file2(file, graph, id)) {
			std::bitset<M> features;
			create_features(graph, feature_graphs, features);
			out_file << s << " " << features.to_string() << "\n";
		}
		else {
			break;
		}
	}
}


void load_feature_vectors(std::ifstream &file_feature_vector, 
						std::vector<std::pair<std::string, std::bitset<M> > > &feature_vectors) {
	std::string id, feature;
	while ((file_feature_vector >> id >> feature)) {
		feature_vectors.push_back({id, std::bitset<M>(feature)});
	}
}


void answer_queries(std::ifstream &file_query, std::ofstream &file_output, 
				std::vector<graph_type> &feature_graphs, 
				std::vector<std::pair<std::string, std::bitset<M> > > &feature_vectors,
				std::unordered_map<std::string, graph_type> &database
				) {
	while (true) {
		graph_type graph;
		if (create_graph_from_file1(file_query, graph)) {
			std::bitset<M> features;
			create_features(graph, feature_graphs, features);
			for (auto &vec: feature_vectors) {
				if (((features & vec.second) ^ features).none() && 
					isomorphism(graph, database[vec.first])) {
					file_output << vec.first << " ";
				}
			}
			file_output << "\n";
		}
		else {
			break;
		}
	}
}


void prune_feature_graphs(std::vector<graph_type> &feature_graphs_tmp, std::vector<graph_type> &feature_graphs)
{
	for (auto graph: feature_graphs_tmp) {
		if (feature_graphs.size() < M) {
			feature_graphs.push_back(graph);
		}
		else
			break;
	}
}