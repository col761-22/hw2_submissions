HW2 Submission
Team: randomMiners

Github Repo Link:https://github.com/uchiha-asha/COL761_assignments

Team Members:
1) Asharam Meena: 2019CS10337
2) Mrunmayi Bhalerao: 2019CS50425
3) Lalit Meena: 2019CS50439

Contributions per member
1) Asharam Meena: 33.33%
2) Mrunmayi Bhalerao: 33.33%
3) Lalit Meena: 33.33%


Files attached:
-   q1.py is the code to first convert database according to algorithms and then generate plot of q1 for running time vs suppport ,for gaston,fsg,gSpan algorithms
-	CS1190337_install.sh contains the code for downloading the github repository and loading the gcc module on hpc
-   q3.py is the code file for part-3
-   part-2 related files-
        -a.hpp
        -gaston
        -main.cpp
        -Makefile
        -query.sh
        -index.sh
        -utils.h
Running instructions for Q1-
q1_plot.sh
python3 q1.py <file_path> <method>
method to run can be - 'all' or ['fsg','gspan','gaston']
run above command after switching to main folder where q1.py and required dependencies present(algorithms library)
here zipped folder , q1_extract_out_dependencies.zip
algorithms library should be present like wrt current folder-
fsg- './pafi-1.0.1/Linux/fsg'
gspan- './gSpan6/gSpan-64'
gaston-'./gaston-1.1-re/gaston'
for example-
python3 q1.py sub_eg.txt gspan
python3 q1.py ./Yeast/167.txt_graph all (plot plotted with it)

Running instructions for Q1-
run with makefile-
other things same as part-2 description
./index.sh 
./query.sh

Running instructions for Q3-
Q3 same as wrote in hw2 discription
elbow_plot.sh
python3 q3.py $1 $2 $3
