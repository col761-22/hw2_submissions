from time import time
import pandas as pnd
import numpy as nmp
from matplotlib import pyplot as pt
import sys
import os


file_path =sys.argv[1]
method =sys.argv[2]
supports=[5.0,10.0,25.0,50.0,95.0]
if(method=="all"):
    methods=['gaston','gspan','fsg']
else:
    methods=[method]

#preprocessing of data for right input format acc to the methods
preprocess =True
if (preprocess):
    file_in = open(file_path,"r")
    lines =file_in.readlines()
    file_in.close()
    dict={}
    n =len(lines)
    for algo in methods:
        file_name = file_path.replace('.txt','_')+algo
        file_name= file_name.replace('./Yeast/','')
        dict[algo]=open(file_name,'w')
        l=0
        if (algo=='gspan' or algo=='gaston'):
            num_graphs =0
            id_map={}
            vcount =0
            while(l<n):
                # line =lines[l]
                if(lines[l][0]=='#'):
                    dict[algo].write('t # ' + str(num_graphs) + '\n')
                    num_graphs+=1
                    #vertices
                    l+=1
                    nv =int(lines[l][:-1])
                    count =0
                    while(nv!=0):
                        l+=1
                        id =lines[l].replace('\n','')
                        if (id not in id_map):
                            id_map[id]=vcount
                            vcount+=1
                        
                        vline = 'v '+str(count)+' '+str(id_map[id])+'\n'
                        dict[algo].write(vline)
                        count+=1
                        nv-=1
                    #edges
                    l+=1
                    ne =int(lines[l][:-1])
                    while(ne!=0):
                        l+=1
                        eline = 'e '+lines[l]
                        dict[algo].write(eline)
                        ne-=1
                    dict[algo].write("\n")
                l+=1
        elif(algo =='fsg'):
            while(l<n):
                # line =lines[l]
                if(lines[l][0]=='#'):
                    dict[algo].write('t\n')
                    #vertices
                    l+=1
                    nv =int(lines[l][:-1])
                    count =0
                    while(nv!=0):
                        l+=1
                        vline = 'v '+str(count)+' '+lines[l]
                        dict[algo].write(vline)
                        count+=1
                        nv-=1
                    #edges
                    l+=1
                    ne =int(lines[l][:-1])
                    while(ne!=0):
                        l+=1
                        eline = 'u '+lines[l]
                        dict[algo].write(eline)
                        ne-=1
                l+=1

        else:
            print("algo option not available ")
        dict[algo].close()

#
data={}
plot_name =''
for algo in methods:
    time_data =[]
    plot_name+=','+algo
    file_name = file_path.replace('.txt','_')+algo
    file_name= file_name.replace('./Yeast/','')
    print("running method-",algo)
    for support in supports:
        if (algo=='fsg'):
            cmd ='./pafi-1.0.1/Linux/fsg -s ' + str(support) + ' ' + file_name
        elif (algo=='gspan'):
            cmd ='./gSpan6/gSpan-64 -f '+ file_name +' -s '+str(support/100)+' -o'
        elif (algo=='gaston'):
            cmd='./gaston-1.1-re/gaston ' + str((support * num_graphs)/100.0) + ' ' + file_name
        else:
            print("algo option not available ")
            break
        
        start =time()
        os.system(cmd)
        algo_time =time()-start
        time_data.append(algo_time)
        print(support,algo_time)
    #saving data
    data[algo]=time_data
    dataf = pnd.DataFrame.from_dict(data)
    dataf.to_csv(file_name+"_data.csv")#header=False, index=False)

#Plotting the data
pt.figure(figsize=(10,8))
markers ={'gspan':'x','fsg':'D','gaston':'o'}
for algo in methods:
    pt.plot(supports,data[algo], label = algo,marker=markers[algo])
pt.title('Analysis of '+plot_name)
pt.xlabel('Frequency (%)')
pt.ylabel('Running Time (sec)')

pt.legend()
pt.savefig('plot-'+plot_name+'.png')
pt.show(block=False)
