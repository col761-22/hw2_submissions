make
./run 1 $1
n=`grep -o t convert.txt | wc -l`
l=2
sup=$(( n/l ))

./gaston $sup convert.txt feature.txt

./run 2