from FPTree import FPTree, Tree
from WriteItems import WriteItems
from Apriori import Apriori
from sys import argv
from timeit import timeit
from matplotlib import pyplot as plt
import signal
#trxn_file = '/Users/suyash/IITD Sem3 Assignments/COL761 - Data Mining/HW1/testcases/5/test5.dat'
#trxn_file = argv[2]
#threshold = 98
#threshold = int(argv[3])
#out_file = '/Users/suyash/IITD Sem3 Assignments/COL761 - Data Mining/HW1/testcases/5/code_output_98.dat_sorted'
#out_file = argv[4]
def handler(signum, frame):
  raise Exception("Timeout")
def apriorit(i):
    ap_obj = Apriori(argv[2], i)
    k = 0
    while ap_obj.combine(k) == 1:
        k += 1
def fpt(i):
    tree = FPTree(argv[2], i)
    tree.create_tree()
    tree.gen_itemsets()

def demofun(fun,i):
    def funa():
        return fun(i)
    return funa

signal.signal(signal.SIGALRM, handler)
if argv[1]== "-apriori":
    signal.alarm(3600)
    #print("Apriori")
    ap_obj = None
    try:
      ap_obj = Apriori(argv[2], int(argv[3]))
      k = 0
      while ap_obj.combine(k) == 1:
          k += 1
    except Exception as exc:
      print(exc)
    signal.alarm(0)
    writer = WriteItems(argv[4])
    if ap_obj:
        writer.writeitems(ap_obj.ans)
    else:
        writer.writeitems([])
elif argv[1]== "-fptree":
    #print("FP")
    signal.alarm(3600)
    tree = None
    try:
      tree = FPTree(argv[2], int(argv[3]))
      tree.create_tree()
      tree.gen_itemsets()
    except Exception as exc:
      print(exc)
    signal.alarm(0)
    writer = WriteItems(argv[4])
    if tree:
        writer.writeitems(tree.itemsets)
    else:
        writer.writeitems([])
elif argv[1] =="-plot":
    li = [90,50,25,10,5]
    timefp = [0]*5
    timeapriori = [0]*5
    for ind,i in enumerate(li):
        signal.alarm(3600)
        try:
          funa = demofun(fpt, i)
          timefp[ind] = timeit(funa, number =1)
        except Exception as exc:
          break
          print(exc)
        signal.alarm(0)
        signal.alarm(3600)
        try:
          funa = demofun(apriorit, i)
          timeapriori[ind] = timeit(funa, number=1)
        except Exception as exc:
          break
          print(exc)
        signal.alarm(0)
    li.reverse()
    timefp.reverse()
    timeapriori.reverse()
    plt.plot(li,timefp,label="FPTree")
    plt.plot(li, timeapriori, label="Apriori")
    plt.ylabel("Time in seconds")
    plt.title("Comparison of Running time Apriori and FPTree")
    plt.xlabel("Threshold in percentage")
    plt.legend()
    #plt.show()
    plt.xticks(range(0,100,10))
    #plt.yticks(range(0, max(max(timeapriori),max(timefp)),))
    plt.savefig(argv[3]+".png")
else:
    print("Arguments Do Not Match")
#tree = FPTree(trxn_file,threshold)
#tree.create_tree()
#tree.gen_itemsets()

#writer = WriteItems(out_file)
#writer.writeitems(tree.itemsets)
