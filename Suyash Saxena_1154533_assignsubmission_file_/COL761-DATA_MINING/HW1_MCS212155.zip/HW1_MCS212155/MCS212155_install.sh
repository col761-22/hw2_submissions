#!/bin/bash
git clone https://github.com/ssuyash28/COL761-DATA_MINING.git
cd COL761-DATA_MINING
unzip HW1_MCS212155.zip
cd HW1_MCS212155
module purge
module load compiler/python/3.6.0/ucs4/gnu/447
module load pythonpackages/3.6.0/matplotlib/3.0.2/gnu
chmod +x MCS212155.sh