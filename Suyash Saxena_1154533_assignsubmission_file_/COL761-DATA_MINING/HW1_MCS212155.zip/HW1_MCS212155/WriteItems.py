class WriteItems:
    def __init__(self,filename):
        self.fo = open(filename,'w')
    def __del__(self):
        self.fo.close()
    def writeitems(self,itemsets):
        new_set = [' '.join(sorted(itemset)) if type(itemset)!=str else itemset for itemset in itemsets]
        new_set.sort()
        for itemset in new_set:
            self.fo.write(itemset+'\n')

# Test
if __name__ == "__main__":
    itr = WriteItems('/Users/suyash/IITD Sem3 Assignments/COL761 - Data Mining/HW1/testcases/5/out_test10.dat_sorted')
    ans = ["abc","def",("a","d","b")]
    itr.writeitems(ans)