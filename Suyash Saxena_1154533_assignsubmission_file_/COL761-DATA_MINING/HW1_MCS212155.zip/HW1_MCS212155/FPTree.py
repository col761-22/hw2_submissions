from ReadTrxn import ReadTrxn
from collections import defaultdict, deque
class Tree:
    def __init__(self,id):
        self.id = id
        self.freq = 0
        self.children = {}
        self.next = None
        self.parent = None

class FPTree:
    def __init__(self,filename,threshold):
        trxn_count = 0
        self.l1 = {}
        self.itemsets = set()
        self.filename = filename
        reader = ReadTrxn(filename)
        self.tree = {}
        # for i in range(10):
        while reader:
            trxn = reader.readtrxn()
            if not trxn:
                break
            trxn_count += 1
            for item in trxn:
                if item in self.l1:
                    self.l1[item][0][0] += 1
                else:
                    self.l1[item] = [[1,item],None,None]
        self.threshold = threshold*trxn_count/100
        self.discard = set()
        for item in self.l1:
            if self.l1[item][0][0]<self.threshold:
                self.discard.add(item)
    
    def create_tree(self):
        def iterate(items,mp,parent):
            for item in items:
                if item in self.discard:
                    continue
                if item not in mp:
                    node = Tree(item)
                    node.freq += 1
                    node.parent = parent
                    if not self.l1[item][1]:
                        self.l1[item][1] = node
                    if self.l1[item][2]:
                        self.l1[item][2].next = node
                    self.l1[item][2] = node
                    mp[item] = node
                    mp = node.children
                    parent = node
                else:
                    node = mp[item]
                    node.freq += 1
                    mp = node.children
                    parent = node

        reader = ReadTrxn(self.filename)
        # for i in range(10):
        while reader:
            trxn = reader.readtrxn()
            if not trxn:
                break
            trxn.sort(key = lambda x: (-self.l1[x][0][0],self.l1[x][0][1]))
            parent = None
            iterate(trxn,self.tree,parent)
    
    def go_to_root(self,item,node,discard,value,potential):
        p = node
        v = value
        parent = p.parent
        while parent:
            if parent not in discard:
                if parent.id in potential:
                    potential[parent.id][0] += v
                    potential[parent.id].append((parent,v))
                else:
                    potential[parent.id] = [v,(parent,v)]
            parent = parent.parent

    def find_sets(self,pointers,item,threshold,discard):
        potential = {}
        for p,val in pointers:
            self.go_to_root(item,p,discard,val,potential)
        seq = []
        discard_temp = discard.copy()
        for iset in potential:
            if potential[iset][0]<threshold:
                discard_temp.add(iset)
            else:
                seq.append((potential[iset][0],iset))
        seq.sort(key = lambda x: (-self.l1[x[1]][0][0],self.l1[x[1]][0][1]),reverse=True)
        results = set()
        for i,v in seq:
            results.add((v,item))
        for i,v in seq:
            arr = self.find_sets(potential[v][1:],v,threshold,discard_temp)
            for t in arr:
                results.add((*t,item))
                #print (results)
        return results

    def gen_itemset_for_item(self,item,threshold,discard):
        pointers = []
        p = self.l1[item][1]
        while p:
            pointers.append((p,p.freq))
            p = p.next
        rem = discard.copy()
        itemset = self.find_sets(pointers,item,threshold,rem)
        #print(item,itemset)
        return itemset

    def gen_itemsets(self,threshold = None):
        threshold  = threshold if threshold else self.threshold
        for item in self.l1:
            if item not in self.discard:
                self.itemsets.add(item)
                itemset = self.gen_itemset_for_item(item,threshold,self.discard)
                self.itemsets = self.itemsets.union(itemset)
        #print(self.itemsets)


# Test
if __name__ == "__main__":
    tree = FPTree('/Users/suyash/IITD Sem3 Assignments/COL761 - Data Mining/HW1/testcases/3/test3.dat',1)
    tree.create_tree()
    # temp = tree.l1['a'][1]
    # while temp:
    #     x = temp
    #     while x:
    #         x = x.parent
    #     temp = temp.next
    # q = deque()
    # for i in tree.tree:
    #     q.append((i,tree.tree[i]))
    # print(tree.l1)
    # while q:
    #     n = deque()
    #     while q:
    #         x,node = q.popleft()
    #         print((x,node.parent.id if node.parent else ''),end = ' ')
    #         for c in node.children:
    #             n.append((c,node.children[c]))
    #     q = n
    #     print()
    tree.gen_itemsets()
