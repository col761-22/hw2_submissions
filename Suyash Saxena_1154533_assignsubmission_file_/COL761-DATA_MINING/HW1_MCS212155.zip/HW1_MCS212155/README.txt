File Details :-
Apriori.py - Contains Code for Apriori class and associated functions.
compile.sh - Empty file, as python code need no compilation.
install.sh - its clone the Github repo; unzip the files; install the modules; also changed the directory.
main.py - Contains code to get command line argument and match which algorithm to class by creating object of respective algorithm and calling associated function. Also create WriteItem object to write result back in file.
FPTree.py - Contains Code for FPTree class and associated functions.
ReadTrxn.py - Contains code to read transaction from file with the help of ReadTrxn Class.
WriteItems.py - Contains code to write result (in format asked) to the file name given with the help of WriteItems Class.
MCS212155.sh - It accepts algorithm name, input file name, support threshold, output filename as input and runs main.py

Q4 Explaination :-
FPtree is running better as there are few file read involved as comparison to apriori.
In apriori we go through entire transaction file every time we created new potential item-set.
Due to this, apriori takes much more time than FP tree.
As threshold increases, less number of candidate get created which led to fewer transaction read, thus time improves for apriori algorithm as well.
In FP tree for higher threshold major portion of time goes for creating FP tree (as it involves transaction read) than itemsets creation.
***********************
Due to dependence on the language used, in our case Python, our code might not run within the same time range as of standard libraries.
We noticed that one complete scan of webdocs.dat file takes around 4 minutes.
***********************


Team Details :-
Suyash Saxena - 2021MCS2155
Varun Singh Negi -2021MCS2156
Vatsal Agrawal - 2021MCS2157

Contribution :-
Suyash Saxena - Written FP Tree Code
Varun Singh Negi - Written Apriori Code
Vatsal Agrawal - Written IO and Documentation and structure of Algorithm

Percentage Contribution :-
Suyash Saxena - 33.34%
Varun Singh Negi - 33.33%
Vatsal Agrawal - 33.33%

Github Repo :-
https://github.com/ssuyash28/COL761-DATA_MINING


