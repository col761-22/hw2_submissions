from ReadTrxn import ReadTrxn
from itertools import combinations
class Apriori:
    def __init__(self,filename,threshold):
        self.map_old={}
        self.map_new={}
        self.ans = []
        self.filename = filename
        reader = ReadTrxn(self.filename)
        count=0
        while reader:
            trxn = reader.readtrxn()
            if not trxn:
                break
            count+=1
            for i in trxn:
                l = (i,)
                if l not in self.map_old:
                    self.map_old[l]=0
                self.map_old[l]+=1 
        self.threshold = (threshold*count)/100
        li = list(self.map_old.keys())
        #print(li)
        for i in li:
            if self.map_old[i]<self.threshold:
                del self.map_old[i]
            else:
                self.ans.append(i)
        #print(self.ans)
        #print(self.ans,self.map_old)

    def combine(self,k):
        l = list(self.map_old.keys())
        l.sort()
        #print(l)
        for i in range(len(l)):
            for j in range(i+1,len(l)):
                if l[i][:k]==l[j][:k]:
                    #print(i,j)
                    temp = list(tuple(l[i])+tuple(l[j][k:]))
                    #print(temp)
                    temp.sort()
                    flag=0
                    for q in range(len(temp)):
                        if tuple(temp[:q]+temp[q+1:]) not in self.map_old:
                            flag=1
                            break
                    if flag==0:
                        self.map_new[tuple(temp)]=0
                        # count = self.read_t(temp)
                        # if self.read_t(temp)>=self.threshold:
                        #     self.map_new[tuple(temp)]=count
                        #     self.ans.append(tuple(temp))
        if(self.map_new=={}):
            return 0
        self.read_t(self.map_new,k+2)
        keys = list(self.map_new.keys())
        for key in keys:
            if self.map_new[key]<self.threshold:
                del self.map_new[key]
            else:
                self.ans.append(tuple(key))
        if(self.map_new=={}):
            return 0
        #print(self.map_new, self.map_old)
        self.map_old=self.map_new
        self.map_new={}
        return 1

    def read_t(self,mp,k):
        reader = ReadTrxn(self.filename)
        while reader:
            trxn = reader.readtrxn()
            if not trxn:
                break
            keys = list(self.map_new.keys())
            for key in keys:
                if all(item in trxn for item in key):
                    mp[key] += 1
            # new_list = all(item in trxn for item in temp)
            # if new_list is True:
            #     count=count+1
            



# Test
if __name__ == "__main__":
    #itr = ReadTrxn('/home/baadalvm/PycharmProjects/pythonProject3/testcases/5/test5.dat')
    ap_obj=Apriori('/home/baadalvm/PycharmProjects/pythonProject3/testcases/5/test5.dat',98)
    k=0
    while ap_obj.combine(k)==1:
        k+=1
    ap_obj.ans.sort()
    print(ap_obj.ans)

