class ReadTrxn:
    def __init__(self,filename):
        self.fo = open(filename)
    def __del__(self):
        self.fo.close()
    def readtrxn(self):
        try:
            line =  next(self.fo)
            return list(set([i for i in line.replace('\n','').split(' ') if i!='\r' and i!='']))
        except:
            return None

# Test
if __name__ == "__main__":
    itr = ReadTrxn('/Users/suyash/IITD Sem3 Assignments/COL761 - Data Mining/HW1/testcases/5/test5.dat')
    for i in range(10):
        print(itr.readtrxn())