#!/bin/bash
python3 main.py $1 $2 $3 $4
#/home/baadalvm/COL761/venv/bin/python3.8 main.py $1 $2 $3 $4