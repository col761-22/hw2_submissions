g++ -o io ./src/io.cpp
chmod +x ./io
if [ $# -eq 0 ]; then
  ./io
else
  ./io $1
fi
g++ -o time ./src/time.cpp
chmod +x ./time
./time
cp -f ./Data/plot_time ./plot_time
gnuplot ./src/plot.p
gnuplot ./src/plot2.p
cp -f ./plot.png ./Data/plot.png
cp -f ./plot2.png ./Data/plot2.png