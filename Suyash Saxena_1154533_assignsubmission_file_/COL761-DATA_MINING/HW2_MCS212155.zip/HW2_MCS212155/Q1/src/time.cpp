#include <bits/stdc++.h>
#include <unistd.h>

using namespace std;

int main(){
    char loc[512];
    getcwd(loc,512);
    char loc2[512];
    strcpy(loc2,loc);
    strcat(loc2,"/Data/plot_time");
    ofstream file1;
    file1.open(loc2);
    file1<<"95.0";
    system("chmod +x ./pafi-1.0.1-1/fsg");
    chrono::time_point<std::chrono::system_clock> start, stop;
    start = chrono::system_clock::now();
    system("./pafi-1.0.1-1/fsg -s 95.0 ./Data/fsgtxt");
    stop = chrono::system_clock::now();
    chrono::duration<double> esecs = stop - start;
    file1<<" "<<esecs.count();
    system("chmod +x ./gSpan6/gSpan-64");
    start = chrono::system_clock::now();
    system("./gSpan6/gSpan-64 -f ./Data/gSpantxt -s 0.95");
    stop = chrono::system_clock::now();
    esecs = stop - start;
    file1<<" "<<esecs.count();
    system("make -C ./gaston-1.1");
    system("chmod +x ./gaston-1.1/gaston");
    start = chrono::system_clock::now();
    system("./gaston-1.1/gaston 95.0 ./Data/gaston1txt -p");
    stop = chrono::system_clock::now();
    esecs = stop - start;
    file1<<" "<<esecs.count()<<"\n";

    file1<<"50.0";
    start = chrono::system_clock::now();
    system("./pafi-1.0.1-1/fsg -s 50.0 ./Data/fsgtxt");
    stop = chrono::system_clock::now();
    esecs = stop - start;
    file1<<" "<<esecs.count();
    start = chrono::system_clock::now();
    system("./gSpan6/gSpan-64 -f ./Data/gSpantxt -s 0.50");
    stop = chrono::system_clock::now();
    esecs = stop - start;
    file1<<" "<<esecs.count();
    start = chrono::system_clock::now();
    system("./gaston-1.1/gaston 50.0 ./Data/gaston1txt -p");
    stop = chrono::system_clock::now();
    esecs = stop - start;
    file1<<" "<<esecs.count()<<"\n";

    file1<<"25.0";
    start = chrono::system_clock::now();
    system("./pafi-1.0.1-1/fsg -s 25.0 ./Data/fsgtxt");
    stop = chrono::system_clock::now();
    esecs = stop - start;
    file1<<" "<<esecs.count();
    start = chrono::system_clock::now();
    system("./gSpan6/gSpan-64 -f ./Data/gSpantxt -s 0.25");
    stop = chrono::system_clock::now();
    esecs = stop - start;
    file1<<" "<<esecs.count();
    start = chrono::system_clock::now();
    system("./gaston-1.1/gaston 25.0 ./Data/gaston1txt -p");
    stop = chrono::system_clock::now();
    esecs = stop - start;
    file1<<" "<<esecs.count()<<"\n";

    file1<<"10.0";
    start = chrono::system_clock::now();
    system("./pafi-1.0.1-1/fsg -s 10.0 ./Data/fsgtxt");
    stop = chrono::system_clock::now();
    esecs = stop - start;
    file1<<" "<<esecs.count();
    start = chrono::system_clock::now();
    system("./gSpan6/gSpan-64 -f ./Data/gSpantxt -s 0.10");
    stop = chrono::system_clock::now();
    esecs = stop - start;
    file1<<" "<<esecs.count();
    start = chrono::system_clock::now();
    system("./gaston-1.1/gaston 10.0 ./Data/gaston1txt -p");
    stop = chrono::system_clock::now();
    esecs = stop - start;
    file1<<" "<<esecs.count()<<"\n";

    file1<<"5.0";
    start = chrono::system_clock::now();
    system("./pafi-1.0.1-1/fsg -s 5.0 ./Data/fsgtxt");
    stop = chrono::system_clock::now();
    esecs = stop - start;
    file1<<" "<<esecs.count();
    start = chrono::system_clock::now();
    system("./gSpan6/gSpan-64 -f ./Data/gSpantxt -s 0.05");
    stop = chrono::system_clock::now();
    esecs = stop - start;
    file1<<" "<<esecs.count();
    start = chrono::system_clock::now();
    system("./gaston-1.1/gaston 5.0 ./Data/gaston1txt -p");
    stop = chrono::system_clock::now();
    esecs = stop - start;
    file1<<" "<<esecs.count()<<"\n";
    return 0;
}
