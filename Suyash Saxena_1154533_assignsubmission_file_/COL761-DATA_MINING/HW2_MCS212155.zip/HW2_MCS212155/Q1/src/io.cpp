#include <bits/stdc++.h>
#include <unistd.h>

using namespace std;

int main(int argc, char **argv){
    //cout<<"a"<<flush;
    char loc[512];
    getcwd(loc,512);
    ifstream file1;
    ofstream file2,file3,file4,file5;
    char loc2[512];
    if (argc > 1){
        strcpy(loc2,argv[1]);
    }
    else{
        strcpy(loc2,loc);
        strcat(loc2,"/Data/167.txt_graph");
    }
    file1.open(loc2);
    strcpy(loc2,loc);
    strcat(loc2,"/Data/fsgtxt");
    file2.open(loc2);
    strcpy(loc2,loc);
    strcat(loc2,"/Data/gSpantxt");
    file3.open(loc2);
    strcpy(loc2,loc);
    strcat(loc2,"/Data/gaston1txt");
    file4.open(loc2);
    strcpy(loc2,loc);
    strcat(loc2,"/Data/gaston2txt");
    file5.open(loc2);
    int count = 0;
    map<string,int> dic;
    while(!file1.eof()){
        string id,temp,numberVertex,numberEdges;
        int flag = 0;
        getline(file1,id);
        while (id == ""){
            getline(file1,id);
            if (file1.eof()){
                flag =1;
                break;
            }
        }
        if (flag==1){
            break;
        }
        //cout<<id<<"\n"<<flush;
        id = id.substr(1);
        file2<<"t # "<<id<<"\n";
        file3<<"t # "<<id<<"\n";
        file4<<"t # "<<id<<"\n";
        file5<<"t # "<<id<<"\n";
        getline(file1,numberVertex);
        int numberV = stoi(numberVertex);
        //cout<<numberV<<"\n";

        for(int i=0;i<numberV;i++){
            string labelV;
            getline(file1,labelV);
            //cout<<labelV<<"\n"<<flush;
            /*
            string labelVi = "";
            for (int j = 0;j<labelV.length(); j++ ){
                char ch = labelV.at(0);
                int ch2 = ch;
                labelVi += to_string(ch2);
            }
             */
            if (dic.find(labelV) == dic.end()){
                dic[labelV]=count;
                count ++;
            }
            file2<< "v " << i <<" "<<dic[labelV]<<"\n";
            file3<< "v " << i <<" "<<dic[labelV]<<"\n";
            file4<< "v " << i <<" "<<dic[labelV]<<"\n";
            file5<< "v " << i <<" "<<dic[labelV]<<"\n";
        }
        getline(file1,numberEdges);
        int numberE = stoi(numberEdges);
        vector <tuple<int,int,int>> vect;
        //cout<<10;
        for(int i=0;i<numberE;i++) {
            string labelE;
            getline(file1, labelE);
            int l = 0;
            int num = 0;
            vector<int> v;
            while (l<labelE.length()) {
                if (labelE[l] == ' ')
                {
                    l++;
                    v.push_back(num);
                    num = 0;
                    continue;
                }
                num = num * 10;
                num = num + (int)labelE[l]-48;
                l++;
            }
            //cout<<"b"<<labelE<<endl<<flush;
            v.push_back(num);
            vect.push_back(make_tuple(v[0], v[1], v[2]));
        }
        sort(vect.begin(),vect.end());
        for (auto mn: vect){

            //cout<<labelE<<"\n";
            file2<< "u " <<get<0>(mn)<< " " <<get<1>(mn)<< " " <<get<2>(mn)<<"\n";
            file3<< "e " <<get<0>(mn)<< " " <<get<1>(mn)<< " " <<get<2>(mn)<<"\n";
            file4<< "e " <<get<0>(mn)<< " " <<get<1>(mn)<< " " <<get<2>(mn)<<"\n";
            file5<< "e " <<get<0>(mn)<< " " <<get<1>(mn)<< " " <<get<2>(mn)<<"\n";
        }
    }
    return 0;

}