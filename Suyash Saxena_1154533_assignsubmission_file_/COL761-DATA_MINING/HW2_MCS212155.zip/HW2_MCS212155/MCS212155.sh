if [ $1 -eq 1 ]; then
  cd ./Q1
  chmod +x ./MCS212155_q1.sh
  if [ $# -eq 2 ]; then
    ./MCS212155_q1.sh $2
  else
    ./MCS212155_q1.sh
  fi
  cd ..
elif [ $1 -eq 2 ]; then
  cd ./Q2
  chmod +x ./MCS212155_q2.sh
  if [ $# -eq 2 ]; then
      ./MCS212155_q2.sh $2
  else
    ./MCS212155_q2.sh
  fi
  cd ..
elif [ $1 -eq 3 ]; then
  cd ./Q3
  chmod +x ./MCS212155_q3.sh
  if [ $# -eq 2 ]; then
    ./MCS212155_q3.sh $2
  else
    ./MCS212155_q3.sh
  fi
  cd ..
else
  echo "Please Give Correct Argument"
fi