if [ $# -lt 3 ]
then
    echo FUCK YOU BITCH
    exit 1
fi

if [ $1 == "-apriori" ]
then
    if [ ! -f $2 ]
    then
        echo ERROR::File \'$2\' does not exist.
        exit 1
    fi
    ./bin/apriori $2 $4 $3
elif [ $1 == "-fptree" ]
then
    if [ ! -f $2 ]
    then
        echo ERROR::File \'$2\' does not exist.
        exit 1
    fi
    ./bin/fptree $2 $4 $3
elif [ $1 == "-plot" ]
then
    if [ ! -f $2 ]
    then
        echo ERROR::File \'$2\' does not exist.
        exit 1
    fi
    python3 test/algoComparision.py $2 $3
else
    echo ERROR::Invalid first arguement.
fi

