import os
import argparse
import subprocess
import matplotlib.pyplot as plt
from timeit import default_timer as time

def set_default(figsize=(10, 10), dpi=100):
    plt.style.use(['dark_background', 'bmh'])
    plt.rc('axes', facecolor='k')
    plt.rc('figure', facecolor='k')
    plt.rc('figure', figsize=figsize, dpi=dpi)


parser = argparse.ArgumentParser()
parser.add_argument("data_path", type=str,
                    help="path to the dataset.")
parser.add_argument("image_path", type=str,
                    help="path to save the image without the png.")
args = parser.parse_args()

"""
print("NOTE:: Please press control-C after the timeout time for the algorithm to run with \
next support threhold value.")
print("NOTE:: For some reason the timeout argument is not working in subprocess module with \
python 3.6.0 which is the only option available on HPC.\n")
"""


timeout = 3600
supportThresholds = [5, 10, 25, 50, 90]

os.makedirs('data/', exist_ok=True)

"""
Apriori runtime.
"""
print("APRIORI")
print("----------------------\n")
aprioriTime = []
for supportVal in supportThresholds:
    print(f"- Running APRIOR for support threshold {supportVal}.")
    try:
        command = f'./AIZ218323.sh -apriori {args.data_path} {supportVal} data/webdocsOutputApriori_{supportVal:02d}.txt'
        print(command+'\n')
        start = time()
        o = subprocess.run( command, shell=True, timeout=timeout)
        end = time()
        aprioriTime.append(end-start)
    except:
        aprioriTime.append(timeout)
print()

#aprioriTime = [3600, 3600, 2357.3, 684.497, 93.1981]

"""
FP-Tree runtime.
"""
print("FP-Tree")
print("----------------------\n")
fptreeTime = []
for supportVal in supportThresholds:
    print(f"- Running FP-Tree for support threshold {supportVal}.")
    try:
        command = f'./AIZ218323.sh -fptree {args.data_path} {supportVal} data/webdocsOutputFptree_{supportVal:02d}.txt'
        print(command+'\n')
        start = time()
        o = subprocess.run( command, shell=True, timeout=timeout)
        end = time()
        fptreeTime.append(end - start)
    except:
        fptreeTime.append(timeout)

print()

#fptreeTime = [3600, 2675.89, 171.998, 126.357, 87.1834]

num_points = 0
for i in range(len(supportThresholds)):
    if fptreeTime[i] == timeout or aprioriTime[i] == timeout:
        num_points+=1
    else:
        break


set_default(figsize=(15, 10))
plt.plot(supportThresholds[num_points:], aprioriTime[num_points:], '-o')
plt.plot(supportThresholds[num_points:], fptreeTime[num_points:], '-o')
plt.xlim(0, 100)
plt.ylim(0)
plt.xticks(range(0, 101, 5))
plt.xlabel(r'Support Threshold $(\%)$')
plt.ylabel(r'Time $(sec)$')
plt.legend(['Apriori', 'FP-Tree'])
plt.savefig(f'{args.image_path}.png')


