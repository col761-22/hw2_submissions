#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <fstream>
#include <map>
#include <algorithm>

#include "Apriori.h"

using namespace std;

void printFileContent(string filename)
{
    ifstream fin;
    fin.open(filename);
    if( !fin.is_open() )
        cerr << "ERROR::Unable to open the file '" << filename << "'\n";

    string line, item;
    while(getline(fin, line))
    {
        istringstream ss(line);
        while(ss >> item)
            cout << item << " ";
        cout << endl;
    }
}

int main(int argc, char *argv[])
{
    if( argc < 2 )
    {
        cerr << "ERROR::Provide transaction filename.\n";
        return 1;
    }
    string filename = argv[1];

    if( argc < 3 )
    {
        cerr << "ERROR::Provide transaction filename.\n";
        return 1;
    }
    string outfile = argv[2];

    if( argc < 4 )
    {
        cerr << "ERROR::Provide support value\n";
        return 1;
    }
    int supportPerc = stoi(argv[3]);


    //high_resolution_clock::time_point start = high_resolution_clock::now();
    Apriori apriori(filename, outfile, supportPerc);
    //cout << getDurationInSeconds(start);

    return 0;
}

