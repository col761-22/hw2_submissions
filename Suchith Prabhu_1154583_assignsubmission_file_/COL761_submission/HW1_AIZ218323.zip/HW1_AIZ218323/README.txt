COL 761 - Assignment - 1

GitHub : https://github.com/suchith720/COL761_submission

Team name : Flash

Team consists of :
Suchith Chidananda Prabhu - 2021AIZ8323
Kausik Hira               - 2021AIY7586
Ishan Anchit              - 2019CS50434

Contributions :
Suchith Chidananda Prabhu - 42 %
Kausik Hira               - 30 %
Ishan Anchit              - 28 %

NOTE:: Please run all the scripts from the repository directory COL761_submission

AIZ2183823_install.sh - This script will clone the submission repository and load the necessary modules in the hpc before generating the apriori and fptree binaries.

compile.sh - This will create all the C++ binaries and object files to be used by AIZ2183823.sh bash scripts.

AIZ218323.sh - Its a script to run fptree and Apriori binaries and for comparing their running time.

    * ./AIZ2183823.sh -apriori <dataset_path> X <outfile_path> :
    will run apriori algorithm and generate frequent itemsets from input file with minimum support X and save these to the output file.
    ex: ./AIZ218323.sh -apriori data/webdocs.dat 75 data/webdocsOutputApriori.dat


    * ./AIZ2183823.sh -fptree <dataset_path> X <outfile_path> :
    will run fptree algorithm and generate frequent itemsets from input file with minimum support X and save these to filename.
    ex: ./AIZ218323.sh -fptree data/webdocs.dat 75 data/webdocsOutputFptree.dat

    * ./AIZ2183823.sh -plot <dataset_path> <image_path> :
    will run apriori and fptree on given dataset with support on [5,10,25,50,90] and generate a plot displaying the time of execution vs support.
    ex: ./AIZ218323.sh -plot data/webdocs.dat data/algoComparision

src/ - This folder contains all the class and function definition for the two algorithms
    * Apriori.cpp - it implements the apriori algorithm
    * FPGrowth.cpp - it implements FP Growth part of the FP-Tree based pattern mining.
    * FPTree.cpp - it implements the construction and finding conditional pattern base of the FP-Tree data structure.
    * HeaderTable.cpp - it implements the header table data-structure of the FP-Tree.
    * Node.cpp - it implements the node of the FP-Tree.
    * HelperFunctions.cpp - contains helper functions used in both fp-tree and apriori algorithm.


include/ - This folder contains the class and function declarations, more info about it can be found above
    * Apriori.h
    * FPGrowth.h
    * FPTree.h
    * HeaderTable.h
    * HelperFunctions.h
    * Node.h

test/ -
    * algoComparision.py - it runs both the fp-tree and apriori algorithm on [5, 10, 15, 25, 50, 90] support thresholds and generate a plot of the time of execution vs support threshold.
    * apriori.cpp - runs the apriori algorithm using the class mentioned above.
    * fptree.cpp - runs the fp-tree algorithm using the class mentioned above.

data/algoComparision.png - image of the plot of the running time vs support thresholds for both the aprioir and fptree algorithm.

----------------------------------------------------------------------
OBSERVATION -
***********

    At very low support of 5% both the algorithms have time out.
    At 10% apriori algorithms has time out.
    At support threshold greater than 5%, it can be seen that fp-tree is very fast than apriori.

    The following are the reasons for it why apriori is slow which is a restricted generation-and-test method :
    1. The candidate generation step in the very expensive, when there are prolific frequent patterns, long patterns or quite low minimum support threshold. There could large number of candidates that could be generated.
    2. The algorithms has to make multiple passes over the dataset to eliminate infrequent itemsets for each step of candidate generation of size k.

    Now fp-tree eliminates few of these issues:
    1. By using a compact data-structure called FP-Tree to store crucial and quantitative information about frequent patterns.
    2. There is no candidate generation step here, the algorithm generates conditional pattern base and constructs FP-tree on it recursively. So unlike Apriori method its just restricted test only.


    At very low support, candidate itemsets in apriori increases exponentially compared to high support.
    So, running time also increases exponentially in apriori with decrease in threshold.
    Also it seems that memory requirement in fptree sometime is high compared to apriori.

---------------------------------------------------------------------
