#include <iostream>
#include <unordered_map>
#include <vector>
#include <algorithm>

using namespace std;

#ifndef __NODE_H__
#define __NODE_H__

class Node
{
    int m_count;
    int m_name;
    unordered_map<int, Node*> m_children;
    Node *m_nodeLink, *m_parent;

    friend class FPTree;
    friend class HeaderTable;
    friend class HeaderTableNode;

    public:

    Node();
    Node(int name, int count, Node *parent=nullptr,
            Node *nodeLink=nullptr);

    void incrementCount(int numOccur=1);

    int getNumChildren();
    Node* getBeginChild();
    Node* getChildNode(int itemName);

    void addChild(Node *child);
    bool isChild(int itemName);
    bool hasNoChild();

    void display(int indent=1);
};

#endif
