#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <fstream>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
#include <map>
#include <cstdio>
#include <cstdlib>

#include "HelperFunctions.h"

using namespace std;

#ifndef _APRIORI_
#define _APRIORI_

class Apriori
{
    string m_filename;
    string m_outfile;
    double m_supportVal;
    int m_supportPerc;
    int m_numTransactions;

    unordered_map<string, int> m_frequentItemsets;

    public:

    Apriori(string filename, string outfile, int supportVal);

    string convertToString(vector<int> &itemset);

    int computeItemCount(unordered_map<int, int> &itemCount);
    vector<vector<int>> computeFrequentItems();

    void mineFrequentItemset();

    bool itemsetInTransaction(vector<int> &itemset, 
            unordered_set<int> &transaction);
    void updateItemsetCountInTransaction(vector<vector<int>> &itemsets,
            unordered_set<int> &transaction, 
            unordered_map<string, int> &itemsetCount);
    vector<vector<int>> getPrunedItemsets(vector<vector<int>> &itemsets);

    vector<int> mergeCandidates(vector<int> &a, vector<int> &b);
    bool isK_1SubsetsFrequent(vector<int> itemset);
    vector<vector<int>> generateF_K(vector<vector<int>> F_K_1);


    void saveFrequentItemsets();
};

#endif
