#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <fstream>
#include <map>
#include <set>
#include <unordered_map>
#include <algorithm>

#include "HeaderTable.h"
#include "HelperFunctions.h"

using namespace std;

#define DISPLAY

class FPTree
{
    Node *m_root;
    HeaderTable m_headerTable;

    friend class FPGrowth;

    public:

    FPTree();
    void initTree(vector<pair<int, int>> &frequentItems);

    void insertItemset(vector<pair<int, int>> &itemset);

    bool itemPresent(int name);
    int itemHeaderPosition(int name);
    int getHeaderTableSize();


    void computeFrequentItems(unordered_map<int, int> &itemCount, 
            double supportVal, vector<pair<int, int>> &frequentItems);
    void computeItemCount(vector<vector<pair<int, int>>> &patternBase, 
            unordered_map<int, int> &itemCount);
    void findConditionalPatternBase(int headPosition, double supportVal, 
            vector<vector<pair<int, int>>> &filteredPatternBase, 
            vector<pair<int, int>> &condFrequentItems,
            int &headerNodeName, int &headerNodeCount);

    bool containsSinglePath();
    bool isEmpty();

    vector<pair<vector<int>,int>> getSinglePathCombinations();
    void getSinglePathCombinationsHelper(Node* &node,
            vector<pair<vector<int>,int>> &res, 
            vector<int> &subset, int itemCount);

    void display();

#if 0
    void findConditionalPatternBase(HeaderTableNode* &headerNode,
            vector<vector<pair<string, int>>> &condPatternBase);
    map<string, int> computeItemCount(
            vector<vector<pair<string, int>>> &patternBase);
    map<string, pair<int, int>> computeFrequentItems(
            vector<vector<pair<string, int>>> &patternBase);
    vector<vector<pair<string, int>>> filterConditionalPatternBase(
            vector<vector<pair<string, int>>> &condPatternBase,
            map<string, pair<int, int>> &frequentItems);
    void insertItemset(Node *&root, HeaderTable &headerTable,
            vector<pair<string, int>> &itemset);
    bool containsSinglePath(Node *&root);

    void getSinglePathCombinationsHelper(Node* &node,
            vector<pair<vector<string>,int>> &res,
            vector<string> &subset,int itemCount);
    vector<pair<vector<string>, int>> getSinglePathCombinations(
            Node *&root);

    vector<pair<vector<string>,int>> fpGrowth(Node *tree,
            HeaderTable &headerTable);
    vector<pair<vector<string>,int>> fpGrowthHelper(
            Node *tree, HeaderTable &headerTable, int headerTablePos);
    void saveFrequentItemsets(
            vector<pair<vector<string>, int>> &frequentItemsets);

    void printFrequentItems();
#endif
};

