#include <iostream>
#include <vector>
#include <map>

#include "Node.h"
using namespace std;

#ifndef __HEADER_TABLE__
#define __HEADER_TABLE__

class HeaderTableNode
{
    int m_name;
    int m_count;
    Node *m_nodeLinkHead, *m_curNodeLink;

    friend class FPTree;

    public:
    HeaderTableNode(int name, int count);
    int addNode(Node *node);

    void display();
};

class HeaderTable
{
    vector<HeaderTableNode*> m_headerTable;
    unordered_map<int, int> m_nameToHeaderPos;

    friend class FPTree;

    public:

    HeaderTable();

    void createHeaderTable(vector<pair<int, int>> &frequentItems);
    void updateHeaderTable(Node* node);

    bool namePresent(int name);
    int namePosition(int name);

    int getHeaderTableSize();
    HeaderTableNode* getHeaderTableNode(int pos);

    void display();
};

#endif
