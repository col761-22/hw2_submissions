#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <fstream>
#include <map>
#include <set>
#include <unordered_map>
#include <algorithm>

#include "FPTree.h"
#include "HelperFunctions.h"

using namespace std;

class FPGrowth
{
    string m_filename;
    string m_outfile;
    double m_supportVal;
    int m_supportPerc;
    int m_numTransactions;

    public:

    FPGrowth(string filename, string outfile, int supportPerc);

    int computeItemCountFromFile(unordered_map<int, int> &itemCount);
    int constructFPTreeFromFile(FPTree &fptree);

    void computeFrequentItems(unordered_map<int, int> &itemCount, 
        vector<pair<int, int>> &frequentItems);

    int mineFrequentItemset();
    void constructFPTree(FPTree &fptree, 
            vector<vector<pair<int, int>>> &patternBase,
            vector<pair<int, int>> &frequentItems);

    /*
    vector<pair<vector<int>, int>> mineFrequentItemsetHelper(
            FPTree &fptree, int headerPosition);
    */
    void mineFrequentItemsetHelper(FPTree &fptree, 
            vector<pair<vector<int>, int>> &frequentItemsets);
    vector<pair<vector<int>, int>> mineConditionalFPTree(
            FPTree &fptree, int headerPosition);

    int saveFrequentItemsets(vector<pair<vector<int>, int>> 
            &frequentItemsets);
};

