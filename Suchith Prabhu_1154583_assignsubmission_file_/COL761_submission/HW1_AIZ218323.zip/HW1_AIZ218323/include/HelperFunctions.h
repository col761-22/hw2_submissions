#include <iostream>
#include <chrono>
#include <unordered_map>
#include <vector>

using namespace std;
using namespace std::chrono;

#ifndef _HELPER_FUNCTIONS_
#define _HELPER_FUNCTIONS_

float getDurationInSeconds(high_resolution_clock::time_point start);

float getDurationInMicroseconds(high_resolution_clock::time_point start);

void printUnorderedMap(unordered_map<int, int> m);

void printUnorderedMap(unordered_map<string, int> m);

void printVector(vector<vector<pair<int, int>>> m);
void printVector(vector<pair<vector<int>, int>> m);
void printVector(vector<pair<int, int>> m);
void printVector(vector<vector<int>> m);
void printVector(vector<int> m);

int readNumber(FILE *fs, int &number);

#endif
