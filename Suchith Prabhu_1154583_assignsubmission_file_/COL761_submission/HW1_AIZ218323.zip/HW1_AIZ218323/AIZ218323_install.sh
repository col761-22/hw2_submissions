#!/bin/bash

repository="https://suchith720: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@github.com/suchith720/COL761_submission.git"
git clone "$repository"

cd COL761_submission/
unzip HW1_AIZ218323.zip
cd HW1_AIZ218323

module load compiler/gcc/9.1.0
module load compiler/python/3.6.0/ucs4/gnu/447
module load pythonpackages/3.6.0/numpy/1.16.1/gnu
module load pythonpackages/3.6.0/matplotlib/3.0.2/gnu

bash compile.sh
