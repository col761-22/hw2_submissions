#include "HelperFunctions.h"

float getDurationInSeconds(high_resolution_clock::time_point start)
{
    auto end = high_resolution_clock::now(); 
    duration<float> timeTaken = end - start;
    return timeTaken.count();
}

float getDurationInMicroseconds(high_resolution_clock::time_point start)
{
    auto end = high_resolution_clock::now(); 
    duration<float, std::micro> timeTaken = end - start;
    return timeTaken.count();
}

void printUnorderedMap(unordered_map<int, int> m)
{
    for(auto itr: m)
    {
        cout << "-> (" << itr.first << "," << itr.second << ")"
            << endl;
    }
}

void printUnorderedMap(unordered_map<string, int> m)
{
    for(auto itr: m)
    {
        cout << "-> (" << itr.first << "," << itr.second << ")"
            << endl;
    }
}

void printVector(vector<vector<pair<int, int>>> m)
{
    for(int i=0; i < m.size(); i++)
    {
        cout << "-> ";
        for(int j=0; j < m[i].size(); j++)
            cout << "(" << m[i][j].first << "," << m[i][j].second 
                << ") ";
        cout << endl;
    }
}

void printVector(vector<pair<vector<int>, int>> m)
{
    for(int i=0; i < m.size(); i++)
    {
        cout << "-> {";
        cout << m[i].first[0] ;
        for(int j=1; j < m[i].first.size(); j++)
            cout << ", " << m[i].first[j];
        cout << "}" << " : " << m[i].second << endl;
    }
}

void printVector(vector<pair<int, int>> m)
{
    cout << "-> ";
    for(int i=0; i < m.size(); i++)
        cout << "{" << m[i].first << ", " << m[i].second << "} ";
    cout << endl;
}

void printVector(vector<int> m)
{
    if( m.size() == 0 )
    {
        cout << "-> {}" << endl;
        return;
    }

    cout << "-> {" << m[0];
    for(int i=1; i < m.size(); i++)
        cout << ", " << m[i];
    cout << "}" << endl;
}

void printVector(vector<vector<int>> m)
{
    for(int i=0; i < m.size(); i++)
    {
        if( ! m[i].size() )
        {
            cout << "-> {}" << endl;
            continue;
        }

        cout << "-> {" << m[i][0];
        for(int j=1; j < m[i].size(); j++)
            cout << ", " << m[i][j];
        cout << "}" << endl;
    }
}

int readNumber(FILE *fs, int &number)
{
    bool negative = false;
    register int c;
  
    number = 0;
  
    c = getc_unlocked(fs);
    if( c == EOF )
        return 0;

    if (c=='-')
    {
        negative = true;
        c = getc_unlocked(fs);
    }
  
    bool foundNumber = false;
    for (; (c>47 && c<58); c=getc_unlocked(fs))
    {
        number = number *10 + c - 48;
        foundNumber = true;
    }

    if (negative)
        number *= -1;

    if( foundNumber )
    {
        if( c == '\n' )
            return 2;
        else
            return 1;
    }

    return 3;
}
