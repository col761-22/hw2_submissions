#include "HeaderTable.h"

/*
 * Functions of class HeaderTableNode
 */

HeaderTableNode::HeaderTableNode(int name, int count)
{
    m_name = name;
    m_count = count;
    m_nodeLinkHead = nullptr;
    m_curNodeLink = nullptr;
}

int HeaderTableNode::addNode(Node *node)
{
    if(node == nullptr)
    {
        cerr << "ERROR::Invalid Node, Node pointing to NULL.\n";
        return 0;
    }

    if(m_nodeLinkHead == nullptr)
        m_curNodeLink = m_nodeLinkHead = node;
    else
    {
        m_curNodeLink->m_nodeLink = node;
        m_curNodeLink = node;
    }

    return 1;
}

void HeaderTableNode::display()
{
    cout << "-> {"<< m_name << ", " << m_count << "}";
    cout << ":";
    for(Node *curNode = m_nodeLinkHead; curNode != NULL;
            curNode = curNode->m_nodeLink)
    {
        cout << "(" << curNode->m_name << ", "
            << curNode->m_count << ", "
            << curNode->getNumChildren() << ")";
    }
    cout << endl;
}

/*
 * Functions of class HeaderTable
 */

HeaderTable::HeaderTable()
{

}

void HeaderTable::createHeaderTable(
        vector<pair<int, int>> &frequentItems)
{
    for(int i=0; i < frequentItems.size(); i++)
    {
        HeaderTableNode* hNode = new HeaderTableNode(
                frequentItems[i].first, frequentItems[i].second);
        m_headerTable.emplace_back(hNode);

        m_nameToHeaderPos[frequentItems[i].first] = i;
    }
}

void HeaderTable::updateHeaderTable(Node* node)
{
    int headerPos = m_nameToHeaderPos[node->m_name];
    m_headerTable[headerPos]->addNode(node);
}

bool HeaderTable::namePresent(int name)
{
    if( m_nameToHeaderPos.find(name) != m_nameToHeaderPos.end() )
        return true;

    return false;
}

int HeaderTable::namePosition(int name)
{
    int pos = -1;

    unordered_map<int, int>::iterator itr;
    if( (itr = m_nameToHeaderPos.find(name)) != m_nameToHeaderPos.end() )
        pos = itr->second;

    return pos;
}

int HeaderTable::getHeaderTableSize()
{
    return m_headerTable.size();
}

HeaderTableNode* HeaderTable::getHeaderTableNode(int pos)
{
    return m_headerTable[pos];
}

void HeaderTable::display()
{
    for(int i=0; i < m_headerTable.size(); i++)
        m_headerTable[i]->display();
}

