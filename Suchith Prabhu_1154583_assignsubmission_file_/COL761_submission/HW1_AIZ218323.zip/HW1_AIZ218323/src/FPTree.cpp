#include "FPTree.h"

FPTree::FPTree()
{
    m_root = nullptr;
}

void FPTree::initTree(vector<pair<int, int>> &frequentItems)
{
    m_root = new Node();
    m_headerTable.createHeaderTable(frequentItems);
}

void FPTree::insertItemset(vector<pair<int, int>> &itemset)
{
    Node *curNode = m_root, *curChildNode;
    for(int i=0; i < itemset.size(); i++)
    {
        if(!curNode->hasNoChild() &&
                (curChildNode =
                 curNode->getChildNode(itemset[i].first)) != nullptr )
        {
            curChildNode->incrementCount(itemset[i].second);
            curNode = curChildNode;
        }
        else
        {
            Node* node = new Node(itemset[i].first, itemset[i].second,
                    curNode);
            curNode->addChild(node);
            m_headerTable.updateHeaderTable(node);
            curNode = node;
        }
    }
}

bool FPTree::itemPresent(int name)
{
    return m_headerTable.namePresent(name);
}

int FPTree::itemHeaderPosition(int name)
{
    return m_headerTable.namePosition(name);
}

int FPTree::getHeaderTableSize()
{
    return m_headerTable.getHeaderTableSize();
}

void FPTree::computeFrequentItems(unordered_map<int, int> &itemCount, 
        double supportVal, vector<pair<int, int>> &frequentItems)
{
    unordered_map<int, int>::iterator itr;
    for(itr = itemCount.begin(); itr != itemCount.end(); itr++)
    {
        if( itr->second >= supportVal )
            frequentItems.emplace_back(*itr);
    }

    auto comp = [&](const pair<int, int> &l, 
            const pair<int, int> &r) -> bool {
        int a = this->itemHeaderPosition(l.first); 
        int b = this->itemHeaderPosition(r.first);
        if(  a != b )
            return a < b;
        return l.first > r.first;
    };

    sort(frequentItems.begin(), frequentItems.end(), comp);
}

void FPTree::computeItemCount(
        vector<vector<pair<int, int>>> &patternBase, 
        unordered_map<int, int> &itemCount)
{
    int item, count;
    for(int i=0; i < patternBase.size(); i++)
    {
        for(int j=0; j < patternBase[i].size(); j++)
        {
            item = patternBase[i][j].first;
            count = patternBase[i][j].second;
            itemCount[item] += count;
        }
    }
}

void FPTree::findConditionalPatternBase(int headPosition,
        double supportVal, 
        vector<vector<pair<int, int>>> &condPatternBase, 
        vector<pair<int, int>> &condFrequentItems,
        int &headerNodeName, int &headerNodeCount)
{
    /*
     * extract pattern base
     */
    int curNodeCount;

    HeaderTableNode *headerNode = 
        m_headerTable.m_headerTable[headPosition];
    headerNodeName = headerNode->m_name;
    headerNodeCount = headerNode->m_count;

    for(Node* curNode = headerNode->m_nodeLinkHead;
            curNode != nullptr; curNode = curNode->m_nodeLink)
    {
        vector<pair<int, int>> itemset;
        curNodeCount = curNode->m_count;

        for(Node *node = curNode->m_parent;
                node->m_parent != nullptr; node=node->m_parent)
        {
            itemset.emplace_back(make_pair(node->m_name,
                        curNodeCount));
        }

        if(itemset.size())
        {
            reverse(itemset.begin(), itemset.end());
            condPatternBase.push_back(itemset);
        }
    }

    /*
     * filtering the pattern base
     */

    unordered_map<int, int> condItemCount; 
    computeItemCount(condPatternBase, condItemCount);

    computeFrequentItems(condItemCount, supportVal, condFrequentItems);
}

bool FPTree::containsSinglePath()
{
    for( Node* curNode = m_root; curNode != nullptr;
            curNode = curNode->getBeginChild() )
    {
        if( curNode->getNumChildren() > 1)
            return false;
    }
    return true;
}

bool FPTree::isEmpty()
{
    return m_root->hasNoChild();

}

vector<pair<vector<int>,int>> FPTree::getSinglePathCombinations()
{
    int itemCount;
    vector<int> subset;
    vector<pair<vector<int>,int>> itemsets;

    Node *node = m_root->getBeginChild();
    getSinglePathCombinationsHelper(node, itemsets,
            subset, node->m_count);

    return itemsets;
}

void FPTree::getSinglePathCombinationsHelper(Node* &node,
        vector<pair<vector<int>,int>> &res, vector<int> &subset,
        int itemCount)
{
    if( !subset.empty() )
        res.push_back(make_pair(subset, itemCount));

    for (Node* curNode = node; curNode != nullptr;
            curNode = curNode->getBeginChild())
    {
        subset.push_back(curNode->m_name);
        itemCount = min(itemCount, curNode->m_count);

        Node *curChildNode = curNode->getBeginChild();
        getSinglePathCombinationsHelper(curChildNode, res,
                subset, itemCount);

        subset.pop_back();
    }
}

void FPTree::display()
{
    cout << "Tree : \n";
    m_root->display();
    cout << endl;

    cout << "Header table \n";
    m_headerTable.display();
    cout << endl;
}

#if 0
void FPTree::mineFrequentItemset()
{
    constructFPTree();
    //debug : Display header table.
    m_headerTable.display();

    cout << "FP-TREE :\n";
    m_root->display();
    //debug

    /*
    vector<pair<vector<string>,int>> frequentItemsets =
        fpGrowth(m_root, m_headerTable);
    saveFrequentItemsets(frequentItemsets);
    */
}

void FPTree::saveFrequentItemsets(
        vector<pair<vector<int>, int>> &frequentItemsets)
{
    ofstream fout(m_outfile);
    if(! fout.is_open() )
    {
        cerr << "ERROR::Unable to open the file '"
            << m_outfile << "'\n";
        return;
    }

    set<string> itemsets;
    for(int i=0; i < frequentItemsets.size(); i++)
    {
        sort( frequentItemsets[i].first.begin(),
                frequentItemsets[i].first.end() );
        string itemset = to_string(frequentItemsets[i].first[0]);
        for(int j=1; j < frequentItemsets[i].first.size(); j++)
            itemset += " " + to_string(frequentItemsets[i].first[j]);
        itemsets.insert(itemset);
    }

    set<string>::iterator itr;
    for(itr = itemsets.begin(); itr != itemsets.end(); itr++)
        fout << (*itr) << endl;
}


map<string, int> FPTree::computeItemCount(
        vector<vector<pair<string, int>>> &patternBase)
{
    map<string, int> itemCount;
    int count;
    string item;

    for(int i=0; i < patternBase.size(); i++)
    {
        for(int j=0; j < patternBase[i].size(); j++)
        {
            item = patternBase[i][j].first;
            count = patternBase[i][j].second;

            if( itemCount.find(item) == itemCount.end() )
                itemCount[item] = count;
            else
                itemCount[item] += count;
        }
    }
    return itemCount;
}

map<string, pair<int, int>> FPTree::computeFrequentItems(
        vector<vector<pair<string, int>>> &patternBase)
{
    map<string, int> itemCount = computeItemCount(patternBase);

    map<string, int>::iterator itr;
    map<string, pair<int, int>> frequentItems;
    for(itr = itemCount.begin(); itr != itemCount.end(); itr++)
    {
        if(itr->second >= m_supportVal)
        {
            frequentItems[itr->first] = make_pair(itr->second,
                    m_frequentItems[itr->first].second);
        }
    }
    return frequentItems;
}

vector<vector<pair<string, int>>> FPTree::filterConditionalPatternBase(
        vector<vector<pair<string, int>>> &condPatternBase,
        map<string, pair<int, int>> &frequentItems)
{
    vector<vector<pair<string, int>>> filteredPatternBase;

    pair<string, int> item;
    for(int i=0; i < condPatternBase.size(); i++)
    {
        vector<pair<string, int>> itemset;
        for(int j=0; j < condPatternBase[i].size(); j++)
        {
            item = condPatternBase[i][j];
            if( frequentItems.find(item.first) !=
                    frequentItems.end() )
            {
                itemset.push_back(item);
            }
        }
        if(itemset.size())
            filteredPatternBase.push_back(itemset);
    }
    return filteredPatternBase;
}

void FPTree::insertItemset(Node *&root, HeaderTable &headerTable,
        vector<pair<string, int>> &itemset)
{
    Node *curNode = root, *curChildNode;
    for(int i=0; i < itemset.size(); i++)
    {
        if(!curNode->isEmpty() &&
                (curChildNode =
                 curNode->getChildNode(itemset[i].first)) != NULL )
        {
            curChildNode->incrementCount();
            curNode = curChildNode;
        }
        else
        {
            Node* node = new Node(itemset[i].first, itemset[i].second,
                    curNode);
            curNode->addChild(node);
            headerTable.updateHeaderTable(node);
            curNode = node;
        }
    }
}

bool FPTree::containsSinglePath(Node *&root)
{
    for( Node* curNode = root; curNode != NULL;
            curNode = curNode->getBeginChild() )
    {
        if( curNode->getNumChildren() > 1)
            return false;
    }
    return true;
}

void FPTree::getSinglePathCombinationsHelper(Node* &node,
        vector<pair<vector<string>,int>> &res, vector<string> &subset,
        int itemCount)
{
    if( !subset.empty() )
        res.push_back(make_pair(subset, itemCount));

    for (Node* curNode = node; curNode != NULL;
            curNode = curNode->getBeginChild())
    {
        subset.push_back(curNode->getName());
        itemCount = min(itemCount, curNode->getCount());

        Node *curChildNode = curNode->getBeginChild();
        getSinglePathCombinationsHelper(curChildNode, res,
                subset, itemCount);

        subset.pop_back();
    }
}

vector<pair<vector<string>,int>> FPTree::getSinglePathCombinations(
        Node *&root)
{
    int itemCount;
    vector<string> subset;
    vector<pair<vector<string>,int>> itemsets;

    Node *node = root->getBeginChild();
    getSinglePathCombinationsHelper(node, itemsets,
            subset, node->getCount());

    return itemsets;
}

#endif

//vector<pair<vector<string>,int>> FPTree::fpGrowthHelper(
//        Node *tree, HeaderTable &headerTable, int headerTablePos)
//{
//    vector<pair<vector<string>,int>> frequentItemsets;
//
//    HeaderTableNode* headerNode = headerTable.getHeaderTableNode(
//            headerTablePos);
//    string headerName = headerNode->getName();
//    frequentItemsets.push_back(make_pair(
//                vector<string>{headerName},
//                headerNode->getCount()));
//
//    /*
//     * Condition Pattern Base
//     */
//    vector<vector<pair<string, int>>> condPatternBase;
//    findConditionalPatternBase(headerNode, condPatternBase);
//
//    /*
//     * Compute Frequent Items
//     */
//    map<string, pair<int, int>> frequentItems =
//        computeFrequentItems(condPatternBase);
//
//#ifdef DISPLAY
//    //debug
//    cout << "Frequent items : " << endl;
//    map<string, pair<int, int>>::iterator itr;
//    for(itr = frequentItems.begin(); itr != frequentItems.end();
//            itr++)
//    {
//        cout << "(" << itr->first << ", " << itr->second.first
//            << ", " << itr->second.second << ") ";
//    }
//    cout << endl;
//    //debug
//#endif
//
//#ifdef DISPLAY
//    //debug
//    cout << "Conditional pattern base : " << endl;
//    cout << "BEFORE : \n";
//    cout << headerName << " : " << endl;
//    cout << condPatternBase.size() << endl;
//    for(int i=0; i < condPatternBase.size(); i++)
//    {
//        vector<pair<string, int>> itemset = condPatternBase[i];
//        for(int j=0; j < itemset.size(); j++)
//        {
//            cout << "(" << itemset[j].first << ", "
//                << itemset[j].second << ") ";
//        }
//        cout << endl;
//    }
//    //debug
//#endif
//
//    /*
//     * Filtering Conditional Pattern Base
//     */
//    condPatternBase = filterConditionalPatternBase(
//            condPatternBase, frequentItems);
//
//#ifdef DISPLAY
//    //debug
//    cout << "AFTER : \n";
//    cout << headerName << " : " << endl;
//    cout << condPatternBase.size() << endl;
//    for(int i=0; i < condPatternBase.size(); i++)
//    {
//        vector<pair<string, int>> itemset = condPatternBase[i];
//        for(int j=0; j < itemset.size(); j++)
//        {
//            cout << "(" << itemset[j].first << ", "
//                << itemset[j].second << ") ";
//        }
//        cout << endl;
//    }
//    //debug
//#endif
//
//    /*
//     * Creating Header Table
//     */
//    HeaderTable condHeaderTable;
//    condHeaderTable.createHeaderTable(frequentItems);
//
//    /*
//     * Create Conditional FP-Tree
//     */
//    Node *root = new Node();
//    vector<pair<string, int>> itemset;
//    for(int i=0; i < condPatternBase.size(); i++)
//    {
//        itemset = condPatternBase[i];
//        insertItemset(root, condHeaderTable, itemset);
//    }
//
//#ifdef DISPLAY
//    //debug
//    cout << "Contains Single Path : " << containsSinglePath(root)
//        << endl;
//    //debug
//#endif
//
//    vector<pair<vector<string>,int>> itemsets;
//    if( root->getNumChildren() == 0 )
//        return frequentItemsets;
//    else if( containsSinglePath(root) )
//        itemsets = getSinglePathCombinations(root);
//    else
//    {
//        itemsets = fpGrowthHelper(root, condHeaderTable,
//                condHeaderTable.getHeaderTableSize()-1);
//    }
//
//#ifdef DISPLAY
//    //debug
//    cout << "ITEMSETS : " << endl;
//    for(int i=0; i < itemsets.size(); i++)
//    {
//        cout << itemsets[i].second << " : ";
//        for(int j=0; j < itemsets[i].first.size(); j++)
//            cout << itemsets[i].first[j] << ",";
//    }
//    cout << endl;
//    //debug
//#endif
//
//    for(int i=0; i < itemsets.size(); i++)
//    {
//        itemsets[i].first.push_back(headerName);
//        itemsets[i].second = min(itemsets[i].second,
//                headerNode->getCount());
//        frequentItemsets.push_back(itemsets[i]);
//    }
//
//
//#ifdef DISPLAY
//    //debug
//    condHeaderTable.display();
//    cout << "Conditional FP-Tree : \n";
//    root->display();
//    //debug
//
//    //debug
//    cout << "FREQUENT ITEMS : \n";
//    for(int i=0; i < frequentItemsets.size(); i++)
//    {
//        for(int j=0; j < frequentItemsets[i].first.size(); j++)
//            cout << frequentItemsets[i].first[j] << ",";
//        cout << "::" << frequentItemsets[i].second << endl;
//    }
//    cout << endl << endl;
//    //debug
//#endif
//
//    return frequentItemsets;
//}

#if 0
vector<pair<vector<string>,int>> FPTree::fpGrowth(
        Node *tree, HeaderTable &headerTable)
{
    vector<pair<vector<string>,int>> frequentItemsets;
    for(int i=headerTable.getHeaderTableSize()-1; i >= 0; i--)
    {
        vector<pair<vector<string>,int>> itemsets =
            fpGrowthHelper(tree, headerTable, i);
        for(int i=0; i < itemsets.size(); i++)
            frequentItemsets.push_back(itemsets[i]);
    }
    return frequentItemsets;
}

void FPTree::printFrequentItems()
{
    cout << "FREQUENT ITEMSET\n";
    map<string, pair<int, int>>::iterator itr;
    for(itr = m_frequentItems.begin(); itr != m_frequentItems.end();
            itr++)
    {
        cout << itr->first << ": ("<< itr->second.first << ","
            << itr->second.second << ")" << endl;
    }
}
#endif
