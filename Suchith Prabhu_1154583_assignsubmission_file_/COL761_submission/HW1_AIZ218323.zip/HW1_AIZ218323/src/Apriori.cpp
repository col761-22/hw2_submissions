#include "Apriori.h"

Apriori::Apriori(string filename, string outfile, int supportPerc)
{
    m_filename = filename;
    m_outfile = outfile;
    m_supportPerc = supportPerc;

    m_numTransactions = 0;

    mineFrequentItemset();
}


int Apriori::computeItemCount(unordered_map<int, int> &itemCount)
{
    FILE *fs = fopen(m_filename.c_str(), "r");
    if( fs == NULL )
    {
        cerr << "ERROR::Unable to open the file " << m_filename
            << endl;
        return 0;
    }

    int number, flag;
    while( 1 )
    {
        flag = readNumber(fs, number);
        if( flag == 0 )
        {
            m_supportVal = double(m_supportPerc)/100*m_numTransactions;
            return 1;
        }
        else if( flag == 1 || flag == 2 )
        {
            if( itemCount.find(number) == itemCount.end() )
                itemCount[number] = 1;
            else
                itemCount[number]++;

            if( flag == 2 )
                m_numTransactions++;
        }
        else if( flag == 3 )
        {
            cerr << "ERROR::Invalid file format : " << m_filename 
                << endl;
            return 0;
        }
    }
    return 1;
}


string Apriori::convertToString(vector<int> &itemset)
{
    if(itemset.size() == 0)
        cerr << "ERROR::Itemset is empty." << endl;

    string itemsetString = to_string(itemset[0]);
    for(int i=1; i < itemset.size(); i++)
        itemsetString += "#" + to_string(itemset[i]);

    return itemsetString;
}

vector<vector<int>> Apriori::computeFrequentItems()
{
    vector<vector<int>> F_1;

    unordered_map<int, int> itemCount;
    if( !computeItemCount(itemCount) )
        return F_1;

    unordered_map<int, int>::iterator itr;
    for(itr = itemCount.begin(); itr != itemCount.end(); itr++)
    {
        if(itr->second >= m_supportVal)
        {
            vector<int> item;
            item.push_back(itr->first);
            F_1.push_back(item);
            m_frequentItemsets[to_string(itr->first)] 
                = itr->second;
        }
    }
    return F_1;
}

bool Apriori::itemsetInTransaction(vector<int> &itemset, 
        unordered_set<int> &transaction)
{
    for(int i=0; i < itemset.size(); i++)
    {
        if( transaction.find(itemset[i]) == transaction.end() )
            return false;
    }
    return true;
}

void Apriori::updateItemsetCountInTransaction(
        vector<vector<int>> &itemsets,
        unordered_set<int> &transaction, 
        unordered_map<string, int> &itemsetCount)
{
    string itemsetString;
    for(int i=0; i < itemsets.size(); i++)
    {
        itemsetString = convertToString(itemsets[i]);
        if( itemsetInTransaction(itemsets[i], transaction) )
            itemsetCount[itemsetString]++;
    }
}

vector<vector<int>> Apriori::getPrunedItemsets(
        vector<vector<int>> &itemsets)
{
    vector<vector<int>> prunedItemsets;

    unordered_map<string, int> itemsetCount;
    for(int i=0; i < itemsets.size(); i++)
        itemsetCount[convertToString(itemsets[i])] = 0;

    FILE *fs = fopen(m_filename.c_str(), "r");
    if( fs == NULL )
    {
        cerr << "ERROR::Unable to open the file " << m_filename
            << endl;
        return prunedItemsets;
    }

    int number, flag;
    unordered_set<int> transaction;
    while( 1 )
    {
        flag = readNumber(fs, number);
        if( flag == 0 )
        {
            string itemsetString;
            for(int i=0; i < itemsets.size(); i++)
            {
                itemsetString = convertToString(itemsets[i]);
                if( itemsetCount[itemsetString] >= m_supportVal )
                {
                    prunedItemsets.push_back(itemsets[i]);
                    m_frequentItemsets[itemsetString] 
                        = itemsetCount[itemsetString];
                }
            }
            return prunedItemsets;
        }
        else if( flag == 1 || flag == 2 )
        {
            transaction.insert(number);
            if( flag == 2 )
            {
                updateItemsetCountInTransaction(itemsets, transaction, 
                        itemsetCount);
                transaction.clear();
            }
        }
        else if( flag == 3 )
        {
            cerr << "ERROR::Invalid file format : " << m_filename 
                << endl;
            return prunedItemsets;
        }
    }
}

void Apriori::mineFrequentItemset()
{
    vector<vector<int>> F_K_1 = computeFrequentItems();

#if 0
    //debug
    sort(F_K_1.begin(), F_K_1.end(), 
            [](const vector<int> &l, const vector<int> &r)
            {
                return l[0] < r[0];
            });
    ofstream fout(m_outfile);
    for(int i=0; i < F_K_1.size(); i++)
        fout << F_K_1[i][0] << endl;
    fout.close();
    return;
    //debug
#endif

    vector<vector<int>> C_K;
    while( F_K_1.size() )
    {
        C_K = generateF_K(F_K_1);
        F_K_1 = getPrunedItemsets(C_K);
    }
    //debug
    //printVector(F_K_1);
    //debug
    saveFrequentItemsets();
}

void Apriori::saveFrequentItemsets()
{
    ofstream fout(m_outfile);
    if(! fout.is_open() )
    {
        cerr << "ERROR::Unable to open the file '"
            << m_outfile << "'\n";
        return;
    }

    unordered_map<string, int>::iterator itr;

    vector<string> stringFrequentItemsets;
    for(itr=m_frequentItemsets.begin(); itr != m_frequentItemsets.end();
            itr++)
    {
        string itemset = itr->first;

        int pos_1=0, pos_2;
        vector<string> stringFrequentItemset;
        while( (pos_2 = itemset.find("#", pos_1)) != string::npos )
        {
            stringFrequentItemset.emplace_back(
                    itemset.substr(pos_1, pos_2-pos_1));
            pos_1 = pos_2 + 1;
        }
        stringFrequentItemset.emplace_back(
                itemset.substr(pos_1));
        sort(stringFrequentItemset.begin(), 
                stringFrequentItemset.end());

        itemset = stringFrequentItemset[0];
        for(int i=1; i < stringFrequentItemset.size(); i++)
            itemset += " " + stringFrequentItemset[i];

        stringFrequentItemsets.emplace_back(itemset);
    }
    sort(stringFrequentItemsets.begin(), stringFrequentItemsets.end());

    for(int i=0; i < stringFrequentItemsets.size(); i++)
        fout << stringFrequentItemsets[i] << endl;

    fout.close();
}


vector<int> Apriori::mergeCandidates(vector<int> &a,
        vector<int> &b)
{
    if( a.size() != b.size() )
    {
        cerr << "ERROR::Merging candidates have different sizes\n"
            << endl;
    }

    int size = a.size();
    if( equal(a.begin(), --a.end(), b.begin()) && 
            a[size-1] != b[size-1] )
    {
        vector<int> c(a.begin(), --a.end());
        if( a[size-1] < b[size-1] )
        {
            c.push_back(a[size-1]);
            c.push_back(b[size-1]);
        }
        else
        {
            c.push_back(b[size-1]);
            c.push_back(a[size-1]);
        }
        return c;
    }
    return vector<int>();
}

bool Apriori::isK_1SubsetsFrequent(vector<int> itemset)
{
    for(int i=0; i < itemset.size(); i++)
    {
        vector<int> subset;
        for(int j=0; j < itemset.size(); j++)
        {
            if(i != j)
                subset.push_back(itemset[j]);
        }

        if( subset.size() )
        {
            string itemsetString = convertToString(subset);
            if( m_frequentItemsets.find(itemsetString) ==
                    m_frequentItemsets.end() )
                return false;
        }
    }
    return true;
}

vector<vector<int>> Apriori::generateF_K(
        vector<vector<int>> F_K_1)
{
    vector<vector<int>> C_K;
    vector<int> c;
    for(int i=0; i < F_K_1.size()-1; i++)
    {
        for(int j=i+1; j < F_K_1.size(); j++)
        {
            c = mergeCandidates(F_K_1[i], F_K_1[j]);
            if( c.size() == F_K_1[i].size()+1 &&
                    isK_1SubsetsFrequent(c) )
            {
                C_K.push_back(c);
            }
        }
    }
    return C_K;
}

