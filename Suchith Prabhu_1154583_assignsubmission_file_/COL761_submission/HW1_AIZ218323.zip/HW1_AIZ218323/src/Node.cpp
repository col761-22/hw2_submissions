#include "Node.h"

Node::Node()
{
    m_name = -1;
    m_count = -1;
    m_parent = nullptr;
    m_nodeLink = nullptr;
}

Node::Node(int name, int count, Node *parent, Node *nodeLink)
{
    m_name = name;
    m_count = count;
    m_parent = parent;
    m_nodeLink = nodeLink;
}

void Node::incrementCount(int numOccur)
{
    m_count += numOccur;
}

void Node::addChild(Node *child)
{
    m_children[child->m_name] = child;
}

bool Node::isChild(int itemName)
{
    return m_children.find(itemName) != m_children.end();
}

bool Node::hasNoChild()
{
    return m_children.empty();
}

Node* Node::getChildNode(int itemName)
{
    unordered_map<int, Node*>::iterator itr = m_children.find(itemName);
    if(itr != m_children.end())
        return itr->second;
    else
        return nullptr;
}

Node* Node::getBeginChild()
{
    unordered_map<int, Node*>::iterator itr = m_children.begin();
    if(itr != m_children.end())
        return itr->second;
    else
        return nullptr;
}

int Node::getNumChildren()
{
    return m_children.size();
}

void Node::display(int indent)
{
    for(int i=0; i < indent; i++)
        cout << "  |" ;
    cout << "-> (" << m_name << ", " << m_count  << ")"<< endl;

    unordered_map<int, Node*>::iterator itr;
    for(itr = m_children.begin(); itr != m_children.end(); itr++)
        itr->second->display(indent+1);
}
