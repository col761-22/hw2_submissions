#include "FPGrowth.h"

FPGrowth::FPGrowth(string filename, string outfile, int supportPerc)
{
    m_filename = filename;
    m_outfile = outfile;
    m_supportPerc = supportPerc;
    m_numTransactions = 0;

    mineFrequentItemset();
}

int FPGrowth::constructFPTreeFromFile(FPTree &fptree)
{
    unordered_map<int, int> itemCount; 
    if( !computeItemCountFromFile(itemCount) )
        return 0;

    vector<pair<int, int>> frequentItems;
    computeFrequentItems(itemCount, frequentItems);

    fptree.initTree(frequentItems);

#if 0
    //debug
    ofstream fout(m_outfile);
    for(int i=0; i < frequentItems.size(); i++)
    {
        fout << frequentItems[i].first << ":" << 
            frequentItems[i].second << endl;
    }
    fout.close();
    return 0;
    //debug
#endif

    FILE *fs = fopen(m_filename.c_str(), "r");
    if( fs == NULL )
    {
        cerr << "ERROR::Unable to open the file " << m_filename
            << endl;
        return 0;
    }

    auto comp = [&](const pair<int, int> &l, 
            const pair<int, int> &r) -> bool {
        int a = fptree.itemHeaderPosition(l.first); 
        int b = fptree.itemHeaderPosition(r.first);
        if(  a != b )
            return a < b;
        return l.first > r.first;
    };

    int number, flag;
    vector<pair<int, int>> itemset;
    while( 1 )
    {
        flag = readNumber(fs, number);
        if( flag == 0 )
            return 1;
        else if( flag == 1 || flag == 2 )
        {
            if( fptree.itemPresent(number) )
                itemset.push_back(make_pair(number, 1));

            if( flag == 2 )
            {
                sort(itemset.begin(), itemset.end(), comp);
                fptree.insertItemset(itemset);
                itemset.clear();
            }
        }
        else if( flag == 3 )
        {
            cerr << "ERROR::Invalid file format : " << m_filename 
                << endl;
            return 0;
        }
    }
    return 1;
}

int FPGrowth::computeItemCountFromFile(unordered_map<int, int> &itemCount)
{
    FILE *fs = fopen(m_filename.c_str(), "r");
    if( fs == NULL )
    {
        cerr << "ERROR::Unable to open the file " << m_filename
            << endl;
        return 0;
    }

    int number, flag;
    while( 1 )
    {
        flag = readNumber(fs, number);
        if( flag == 0 )
        {
            m_supportVal = double(m_supportPerc)/100*m_numTransactions;
            return 1;
        }
        else if( flag == 1 || flag == 2 )
        {
            itemCount[number]++;

            if( flag == 2 )
                m_numTransactions++;
        }
        else if( flag == 3 )
        {
            cerr << "ERROR::Invalid file format : " << m_filename 
                << endl;
            return 0;
        }
    }
    return 1;
}


void FPGrowth::computeFrequentItems(unordered_map<int, int> &itemCount, 
        vector<pair<int, int>> &frequentItems)
{
    unordered_map<int, int>::iterator itr;
    for(itr = itemCount.begin(); itr != itemCount.end(); itr++)
    {
        if( itr->second >= m_supportVal )
            frequentItems.emplace_back(*itr);
    }
    sort(frequentItems.begin(), frequentItems.end(), 
            [](const pair<int, int> &l, const pair<int, int> &r)
            {
                if(l.second != r.second)
                    return l.second > r.second;
                return l.first > r.first;
            });
}

int FPGrowth::mineFrequentItemset()
{
    FPTree fptree;
    if( ! this->constructFPTreeFromFile(fptree) )
        return 0;

#if 0
    //debug
    cout << "Support Value : " << m_supportVal << endl << endl;
    fptree.display();
    cout << endl;
    //debug
#endif

    vector<pair<vector<int>, int>> frequentItemsets;
    mineFrequentItemsetHelper(fptree, frequentItemsets);
    this->saveFrequentItemsets(frequentItemsets);

    return 1;
}

void FPGrowth::mineFrequentItemsetHelper(FPTree &fptree, 
        vector<pair<vector<int>, int>> &frequentItemsets)
{
    vector<pair<vector<int>, int>> itemsets;
    for(int i=fptree.getHeaderTableSize()-1; i >= 0 ; i--)
    {
#if 0
        //debug
        cout << "ITERATION : " << fptree.getHeaderTableSize() << ":" 
            << i << endl;
        cout << endl;
        //debug
#endif
        itemsets = mineConditionalFPTree(fptree, i);
#if 0
        //debug
        cout << "FREQUENT ITEMS : " << endl;
        printVector(itemsets);
        cout << endl;
        //debug
#endif
        if( itemsets.size() )
        {
            copy(itemsets.begin(), itemsets.end(),
                    back_inserter<vector<pair<vector<int>,
                    int>>>(frequentItemsets)); 
        }
    }
}

vector<pair<vector<int>, int>> FPGrowth::mineConditionalFPTree(
        FPTree &fptree, int headerPosition)
{
    vector<pair<vector<int>, int>> frequentItemsets;
    /*
     * Construct Conditional FP-Tree
     */
    vector<vector<pair<int, int>>> condPatternBase;
    vector<pair<int, int>> condFrequentItems;
    int headerName, headerCount;
    fptree.findConditionalPatternBase(headerPosition, m_supportVal, 
            condPatternBase, condFrequentItems, headerName, headerCount);
#if 0
    //debug
    cout << "-- Conditional Pattern Base : " << endl;
    printVector(condPatternBase);
    cout << endl;

    cout << "-- Frequent Itemset : " << endl;
    printVector(condFrequentItems);
    cout << endl;
    //debug
#endif

    /*
     * adding the current item as frequent
     */
    frequentItemsets.emplace_back(make_pair(
                vector<int>{headerName},
                headerCount) );
    //printVector(condPatternBase);

    FPTree condFPTree;
    constructFPTree(condFPTree, condPatternBase, condFrequentItems);
#if 0
    //debug
    cout << "Constructing FP-Tree : " << endl;
    cout << endl;
    //debug
    condFPTree.display();
    cout << endl;
    //debug
#endif

#if 0
    //debug
    if( headerName == 49 )
    {
        cout << headerName << " :: " << endl;
        condFPTree.display();
        printVector(condPatternBase);

    }
    //debug
#endif


    /*
     * Extracting Conditional Frequent Itemset.
     */
    vector<pair<vector<int>,int>> itemsets;
    if( condFPTree.isEmpty() )
        return frequentItemsets;
    else if( condFPTree.containsSinglePath() )
    {
        itemsets = condFPTree.getSinglePathCombinations();
#if 0
        //debug
        printVector(itemsets);
        //debug
#endif
    }
    else
    {
        mineFrequentItemsetHelper(condFPTree, itemsets);
    }


    /*
     * Extracting frequent itemset
     */
    for(int i=0; i < itemsets.size(); i++)
    {
        itemsets[i].first.push_back(headerName);
        itemsets[i].second = min(itemsets[i].second,
                headerCount);
        frequentItemsets.push_back(itemsets[i]);
    }
    return frequentItemsets;
}

#if 0
vector<pair<vector<int>, int>> FPGrowth::mineFrequentItemsetHelper(
        FPTree &fptree, int headerPosition)
{
    vector<pair<vector<int>, int>> frequentItemsets;
    /*
     * Construct Conditional FP-Tree
     */
    vector<vector<pair<int, int>>> condPatternBase;
    vector<pair<int, int>> condFrequentItems;
    int headerName, headerCount;
    fptree.findConditionalPatternBase(headerPosition, m_supportVal, 
            condPatternBase, condFrequentItems, headerName, headerCount);
    //debug
    printVector(condPatternBase);
    //debug

    /*
     * adding the current item as frequent
     */
    frequentItemsets.emplace_back(make_pair(
                vector<int>{headerName},
                headerCount) );
    //printVector(condPatternBase);

    FPTree condFPTree;
    constructFPTree(condFPTree, condPatternBase, condFrequentItems);
    //debug
    condFPTree.display();
    cout << endl;
    //debug

#if 0
    //debug
    if( headerName == 49 )
    {
        cout << headerName << " :: " << endl;
        condFPTree.display();
        printVector(condPatternBase);

    }
    //debug
#endif


    /*
     * Extracting Conditional Frequent Itemset.
     */
    vector<pair<vector<int>,int>> itemsets;
    if( condFPTree.isEmpty() )
        return frequentItemsets;
    else if( condFPTree.containsSinglePath() )
    {
        itemsets = condFPTree.getSinglePathCombinations();
#if 0
        //debug
        printVector(itemsets);
        //debug
#endif
    }
    else
    {
        itemsets = mineFrequentItemsetHelper(condFPTree, 
                condFPTree.getHeaderTableSize()-1); 
    }


    /*
     * Extracting frequent itemset
     */
    for(int i=0; i < itemsets.size(); i++)
    {
        itemsets[i].first.push_back(headerName);
        itemsets[i].second = min(itemsets[i].second,
                headerCount);
        frequentItemsets.push_back(itemsets[i]);
    }
    return frequentItemsets;
}
#endif

void FPGrowth::constructFPTree(FPTree &fptree, 
        vector<vector<pair<int, int>>> &patternBase,
        vector<pair<int, int>> &frequentItems)
{
    fptree.initTree(frequentItems);

    int item, count;
    vector<pair<int, int>> itemset;
    for(int i=0; i < patternBase.size(); i++)
    {
        for(int j=0; j < patternBase[i].size(); j++)
        {
            item = patternBase[i][j].first;
            count = patternBase[i][j].second;

            if( fptree.itemPresent(item) )
                itemset.push_back(make_pair(item, count));
        }

        if( itemset.size() )
        {
            fptree.insertItemset(itemset);
            //debug
            //printVector(itemset);
            //debug
            itemset.clear();
        }
    }
}

int FPGrowth::saveFrequentItemsets(vector<pair<vector<int>, int>> 
        &frequentItemsets)
{
    ofstream fout(m_outfile);
    if( !fout.is_open() )
    {
        cerr << "ERROR::Unable to open the file, '" << m_outfile <<
            m_outfile << endl;
        return 0;
    }

    /*
    for(int i=0; i < frequentItemsets.size(); i++)
    {
        for(int j=0; j < frequentItemsets[i].first.size(); j++)
            fout << frequentItemsets[j].first[j] << " ";
        fout << endl;
    }
    */

    vector<string> stringFrequentItemsets;
    for(int i=0; i < frequentItemsets.size(); i++)
    {
        vector<string> stringFrequentItemset;
        for(int j=0; j < frequentItemsets[i].first.size(); j++)
        {
            stringFrequentItemset.emplace_back(
                    to_string(frequentItemsets[i].first[j]));
        }
        sort(stringFrequentItemset.begin(), stringFrequentItemset.end());

        string itemset = stringFrequentItemset[0];
        for(int j=1; j < stringFrequentItemset.size(); j++)
            itemset += " " + stringFrequentItemset[j];

        stringFrequentItemsets.emplace_back(itemset);
    }
    sort(stringFrequentItemsets.begin(), stringFrequentItemsets.end());

    for(int i=0; i < stringFrequentItemsets.size(); i++)
        fout << stringFrequentItemsets[i] << endl;

    fout.close();

    return 1;
}
