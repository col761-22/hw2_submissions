#include "HelperFunction.h"

void printGraph(vector<GraphType> &graphs)
{
    int graphCtr = 1;
    for(auto &g: graphs)
    {
        cout << "Graph : " << graphCtr << endl;
        printGraph(g);
        cout << endl;
        graphCtr++;
    }
}

void printGraph(GraphType &g)
{
    GraphType::edge_iterator eit, eend;
    GraphType::vertex_iterator vit, vend;

    for(tie(eit, eend) = edges(g); eit != eend; ++eit)
    {
        string label =  to_string(get(edge_name,g)[*eit]);
        string start_node = to_string(get(vertex_name, 
                    g)[source(*eit, g)]);
        string end_node = to_string(get(vertex_name, 
                    g)[target(*eit, g)]);
        cout << "e (" << start_node <<  "," 
            << end_node << ") : " << label << endl;
    }

    for(tie(vit, vend) = vertices(g); vit != vend; ++vit)
    {
        cout << "v " << *vit << " " << 
            to_string(get(vertex_name, g)[*vit]) << endl;
    }
}

void printGraph(vector<GraphType> &graphs, 
        map<int, string> &m_graphIdToTrans,
        map<string, int> &nodeLabelToId, map<string, int> &edgeLabelToId)
{
    int graphCtr = 0;

    map<int, string> nodeIdToLabel, edgeIdToLabel;

    map<string, int>::iterator itr;
    for(itr = nodeLabelToId.begin(); itr != nodeLabelToId.end(); itr++)
        nodeIdToLabel[itr->second] = itr->first;
    for(itr = edgeLabelToId.begin(); itr != edgeLabelToId.end(); itr++)
        edgeIdToLabel[itr->second] = itr->first;

    for(auto &g: graphs)
    {
        cout << "Graph : #" << m_graphIdToTrans[graphCtr] << endl;
        printGraph(g, nodeIdToLabel, edgeIdToLabel);
        cout << endl;
        graphCtr++;
    }
}

void printGraph(GraphType &g, map<int, string> &nodeIdToLabel, 
        map<int, string> &edgeIdToLabel)
{
    GraphType::edge_iterator eit, eend;

    for(tie(eit, eend) = edges(g); eit != eend; ++eit)
    {
        int label = get(edge_name,g)[*eit];
        int startNode = get(vertex_name, g)[source(*eit, g)];
        int endNode = get(vertex_name, g)[target(*eit, g)];

        cout << "e (" << nodeIdToLabel[startNode] <<  "," 
            << nodeIdToLabel[endNode] << ") : " 
            << edgeIdToLabel[label] << endl;
    }

    GraphType::vertex_iterator vit, vend;
    for(tie(vit, vend) = vertices(g); vit != vend; ++vit)
    {
        cout << "v " << *vit << " " << 
            nodeIdToLabel[get(vertex_name, g)[*vit]] << endl;
    }
}

string getEdgeString(string &label, string &startNode, 
        string &endNode)
{
    string edgeString;
    if(startNode < endNode)
        edgeString = startNode+"#"+endNode;
    else
        edgeString = endNode+"#"+startNode;
    edgeString += "#"+label;
    return edgeString;
}

bool isIsoMorphic(GraphType G1, GraphType G2)
{
    vertex_comp_t vertex_comp =
        make_property_map_equivalent(get(vertex_name, G1),
                get(vertex_name, G2));

    edge_comp_t edge_comp =
        make_property_map_equivalent(get(edge_name, G1), 
                get(edge_name, G2));

    vf2_callback<GraphType, GraphType> callback(G1,G2);
    
    return vf2_subgraph_mono(G1, G2, callback, 
            vertex_order_by_mult(G1), 
            edges_equivalent(edge_comp).vertices_equivalent(vertex_comp));
                    
}

void setIntersection(std::unordered_set<int> &s1, 
        std::unordered_set<int> &s2)
{
    std::vector<int> removeSet;
    std::unordered_set<int>::iterator itr;
    for(itr = s1.begin(); itr != s1.end(); itr++)
    {
        if( s2.find(*itr) == s2.end() )
            removeSet.push_back(*itr);
    }
    for(int i=0; i < removeSet.size(); i++)
        s1.erase(removeSet[i]);
}


float getDurationInSeconds(high_resolution_clock::time_point start)
{
    auto end = high_resolution_clock::now(); 
    duration<float> timeTaken = end - start;
    return timeTaken.count();
}

float getDurationInMicroseconds(high_resolution_clock::time_point start)
{
    auto end = high_resolution_clock::now(); 
    duration<float, std::micro> timeTaken = end - start;
    return timeTaken.count();
}

float getDurationInMilliseconds(high_resolution_clock::time_point start)
{
    auto end = high_resolution_clock::now(); 
    duration<float, std::milli> timeTaken = end - start;
    return timeTaken.count();
}
