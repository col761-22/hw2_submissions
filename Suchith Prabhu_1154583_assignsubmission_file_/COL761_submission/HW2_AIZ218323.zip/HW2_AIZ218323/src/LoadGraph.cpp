#include "LoadGraph.h"

LoadGraph::LoadGraph()
{
}

int LoadGraph::readGspanOutputBySize(string filename, 
        vector<vector<GraphType>> &freqGraphs, 
        vector<vector<std::unordered_set<int>>> &freqIdToGraphIds)
{
    ifstream fin(filename);
    if( !fin.is_open() )
    {
        cout << "ERROR::Unable to open the file '" << filename
            << "'" << endl;
        return 1;
    }

    int maxGraphSize = freqGraphs.size();

    string type;
    int freqGraphTransID, graphSupport, nodeNum, startNode, endNode, 
        nodeLabel, edgeLabel, graphTransID;

    string spChar_1, spChar_2;
    
    fin >> type;
    while( type == "t" )
    {
        fin >> spChar_1 >> freqGraphTransID >> spChar_2 
            >> graphSupport;

        GraphType graph;
        /*
         * Reading : v <nodeNum> <nodeLabel>
         */
        while( fin >> type and type == "v")
        {
            fin >> nodeNum >> nodeLabel;
            add_vertex(PropNode(nodeLabel), graph);
        }

        /*
         * Reading : e <edgeNum> <edgeLabel1> <edgeLabel2>
         */
        int tmp;
        if( type == "e" )
        {
            fin >> startNode >> endNode >> edgeLabel;
            if( startNode > endNode )
            {
                tmp = startNode;
                startNode = endNode;
                endNode = tmp;
            }
            add_edge(startNode, endNode, PropEdge(edgeLabel), graph);
            while( fin >> type and type == "e")
            {
                fin >> startNode >> endNode >> edgeLabel;
                if( startNode > endNode )
                {
                    tmp = startNode;
                    startNode = endNode;
                    endNode = tmp;
                }
                add_edge(startNode, endNode, 
                        PropEdge(edgeLabel), graph);
            }
        }

        std::unordered_set<int> graphTransIds;
        if( type == "x" )
        {
            int graphTransId;
            while( fin >> type && type != "t")
            {
                graphTransId = stoi(type);
                graphTransIds.insert(graphTransId);
            }
        }

        int graphSize = num_edges(graph);
        if( graphSize < maxGraphSize )
        {
            freqIdToGraphIds[graphSize].push_back(graphTransIds);
            freqGraphs[graphSize].push_back(graph);
        }
    }
    fin.close();
    return 0;
}


int LoadGraph::readGastonOutput(string filename, 
        vector<GraphType> &graphs)
{
    ifstream fin(filename);
    if( !fin.is_open() )
    {
        cout << "ERROR::Unable to open the file '" << filename
            << "'" << endl;
        return 1;
    }

    string type;
    string graphTransID;
    int graphSupport, nodeNum, startNode, endNode, nodeLabel, edgeLabel;
    
    fin >> type;
    while( type[0] == '#' )
    {
        GraphType graph;

        fin >> graphSupport;

        /*
         * Reading : t <transID>
         */
        fin >> type >> graphTransID;

        /*
         * Reading : v <nodeNum> <nodeLabel>
         */
        while( fin >> type and type == "v")
        {
            fin >> nodeNum >> nodeLabel;
            add_vertex(PropNode(nodeLabel), graph);
        }

        /*
         * Reading : e <edgeNum> <edgeLabel1> <edgeLabel2>
         */
        int tmp;
        if( type == "e" )
        {
            fin >> startNode >> endNode >> edgeLabel;
            if( startNode > endNode )
            {
                tmp = startNode;
                startNode = endNode;
                endNode = tmp;
            }
            add_edge(startNode, endNode, PropEdge(edgeLabel), graph);
            while( fin >> type and type == "e")
            {
                fin >> startNode >> endNode >> edgeLabel;
                if( startNode > endNode )
                {
                    tmp = startNode;
                    startNode = endNode;
                    endNode = tmp;
                }
                add_edge(startNode, endNode, PropEdge(edgeLabel), graph);
            }
        }

        graphs.emplace_back(graph);
    }

    fin.close();

    return 0;
}

int LoadGraph::readGraphFile(string filename, 
        vector<GraphType> &graphs,
        map<int, string> &graphIdToTrans, 
        map<string, int> &nodeLabelToId,
        map<string, int> &edgeLabelToId)
{
    ifstream fin(filename);
    if( !fin.is_open() )
    {
        cout << "ERROR::Unable to open the file '" << filename << "'" 
            << endl;
        return 1;
    }

    string line;

    int nodeLabelCount = 0, edgeLabelCount = 0, graphTransCount = 0;
    string graphTrans;

    fin >> line;
    while( line[0] == '#' )
    {
        GraphType graph;

        graphTrans = line.substr(1);
        graphIdToTrans[graphTransCount] = graphTrans;
        graphTransCount++;

        fin >> line;
        int numNode = stoi(line);
        for(int i=0; i < numNode; i++)
        {
            fin >> line;
            if( nodeLabelToId.find(line) == nodeLabelToId.end() )
            {
                nodeLabelToId[line] = nodeLabelCount;
                nodeLabelCount++;
            }
            /*
             * Adding vertex
             */
            add_vertex(PropNode(nodeLabelToId[line]), graph);
        }

        if( fin >> line )
        {
            if( line[0] != '#' )
            {
                int numEdges = stoi(line);
                int startNode, endNode;
                for(int i=0; i < numEdges; i++)
                {
                    fin >> startNode >> endNode >> line;
                    if( edgeLabelToId.find(line) == edgeLabelToId.end() )
                    {
                        edgeLabelToId[line] = edgeLabelCount;
                        edgeLabelCount++;
                    }

                    if( startNode > endNode )
                    {
                        int tmp = startNode;
                        startNode = endNode;
                        endNode = tmp;
                    }
                    /*
                     * Adding edge
                     */
                    add_edge(startNode, endNode, 
                            PropEdge(edgeLabelToId[line]),
                            graph);
                }
                if( !(fin >> line) )
                {
                    graphs.emplace_back(graph);
                    break;
                }
            }
        }
        else
            break;


        graphs.emplace_back(graph);
    }

    fin.close();

    return 0;
}

int LoadGraph::writeGspanInput(string filename, vector<GraphType> &graphs)
{
    ofstream fout(filename);
    if( !fout.is_open() )
    {
        cout << "ERROR::Unable to open the file '" << filename
            << "'" << endl;
        return 1;
    }

    int graphCtr = 0;
    for(auto g: graphs)
    {
        fout << "t # " << graphCtr << endl;

        GraphType::vertex_iterator vit, vend;
        for(tie(vit, vend) = vertices(g); vit != vend; ++vit)
        {
            string label = to_string(get(vertex_name, g)[*vit]);
            fout << "v " << *vit << " " << label << endl;
        }

        GraphType::edge_iterator eit, eend;
        for(tie(eit, eend) = edges(g); eit != eend; ++eit)
        {
            string label =  to_string(get(edge_name,g)[*eit]);
            string startNode = to_string(source(*eit, g));
            string endNode = to_string(target(*eit, g));

            fout << "e "<< startNode << " " << endNode << " "
                << label << endl;
        }

        graphCtr++;
    }

    fout.close();

    return 0;
}

int LoadGraph::writeQuerySearchResults(string outputFile,
        vector<std::unordered_set<string>> &answerSets)
{
    ofstream fout(outputFile);
    if( !fout.is_open() )
    {
        cout << "ERROR::Unable to open the file '" << outputFile
            << "'" << endl;
        return 1;
    }

    for(int i=0; i < answerSets.size(); i++)
    {
        int ctr = 0;
        for(auto id: answerSets[i])
        {
            if( ctr < answerSets[i].size() - 1 )
                fout << id << " ";
            else
                fout << id << endl;
            ctr++;
        }
    }
    return 0;
}

int LoadGraph::readIndex(string filename, Index &index)
{
    ifstream fin(filename, std::ios::binary);
    boost::archive::binary_iarchive inarchive(fin);
    inarchive >> index;
    return 0;
}


int LoadGraph::writeIndex(string filename, Index &index)
{
    ofstream fout(filename, std::ios::binary);
    boost::archive::binary_oarchive outarchive(fout);
    outarchive << index;
    return 0;
}

