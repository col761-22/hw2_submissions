#include "Index.h"

Index::Index()
{
}

void Index::extractNodeFeatures()
{
    GraphType::vertex_iterator it, end;

    string label;
    int graphCtr = 0;
    for(auto &g: m_database)
    {
        for(tie(it, end) = vertices(g); it != end; ++it)
        {
            label = to_string(get(vertex_name, g)[*it]); 

            if( m_featureNodes.find(label) != 
                    m_featureNodes.end() )
                m_featureNodes[label].insert(graphCtr);
            else
                m_featureNodes[label] = 
                    std::unordered_set<int>({graphCtr});
        }
        graphCtr++;
    }
}

void Index::extractEdgeFeatures()
{
    GraphType::edge_iterator it, end;

    int graphCtr = 0;
    string label, startNode, endNode, edgeString;
    for(auto &g: m_database)
    {
        for(tie(it, end) = edges(g); it != end; ++it)
        {
            label =  to_string(get(edge_name,g)[*it]);
            startNode = to_string(get(vertex_name, 
                        g)[source(*it, g)]);
            endNode = to_string(get(vertex_name, 
                        g)[target(*it, g)]);

            edgeString = getEdgeString(label, startNode, endNode);
            if( m_featureEdges.find(edgeString) != 
                    m_featureEdges.end() )
                m_featureEdges[edgeString].insert(graphCtr);
            else
                m_featureEdges[edgeString] = 
                    std::unordered_set<int>({graphCtr});
        }
        graphCtr++;
    }
}

double Index::getGamma(int idx, int graphSize, int featureSize)
{
    std::unordered_set<int> idxFeatureGraphIds;

    bool foundIsomorphic = false;
    for(int gs=0; gs <= graphSize; gs++)
    {
        for(int j=0; j < m_featureGraphs[gs].size(); j++)
        {
            if( gs == graphSize && j == featureSize )
                break;

            if( isIsoMorphic(m_featureGraphs[gs][j], 
                        m_featureGraphs[graphSize][idx]) )
            {
                if( idxFeatureGraphIds.size() == 0 )
                {
                    foundIsomorphic = true;
                    idxFeatureGraphIds = m_featGraphToGraphIds[gs][j];
                }
                else
                {
                    setIntersection(idxFeatureGraphIds,
                            m_featGraphToGraphIds[gs][j]);
                }
            }
        }
    }

    if( foundIsomorphic )
        return (double)idxFeatureGraphIds.size()/
            m_featGraphToGraphIds[graphSize][idx].size();
    else
        return -1;
}

void Index::extractGraphFeatures(string featureFile, double gammaCut)
{
    m_lg->readGspanOutputBySize(featureFile, m_featureGraphs,
            m_featGraphToGraphIds);

    double gamma;
    for(int gs=0; gs < m_featureGraphs.size(); gs++)
    {
        int featureCount = 0;
        for(int j=0; j < m_featureGraphs[gs].size(); j++)
        {
            gamma = getGamma(j, gs, featureCount);
            if(gamma < 0 || gamma > gammaCut)
            {
                /*
                cout << gamma << " -- ";
                */
                m_featureGraphs[gs][featureCount] = 
                    m_featureGraphs[gs][j];
                m_featGraphToGraphIds[gs][featureCount] = 
                    m_featGraphToGraphIds[gs][j];
                featureCount++;
            }
        }
        m_featureGraphs[gs].resize(featureCount);
        m_featGraphToGraphIds[gs].resize(featureCount);
    }
    /*
    cout << endl;
    */
}


void Index::pruneUsingFeatureNodes(GraphType &query, 
        std::unordered_set<int> &candidateIds)
{
    GraphType::vertex_iterator it, end;

    string label;
    for(tie(it, end) = vertices(query); it != end; ++it)
    {
        label = to_string(get(vertex_name, query)[*it]); 
        if( m_featureNodes.find(label) != m_featureNodes.end() )
        {
            if( candidateIds.size() == 0 )
                candidateIds = m_featureNodes[label];
            else
                setIntersection(candidateIds, 
                        m_featureNodes[label]); 
        }
        else
        {
            candidateIds.clear();
            break;
        }
    }
}


void Index::pruneUsingFeatureEdges(GraphType &query, 
        std::unordered_set<int> &candidateIds, bool &foundFeatureEdge)
{
    GraphType::edge_iterator it, end;

    string label, startNode, endNode, edgeString;
    for(tie(it, end) = edges(query); it != end; ++it)
    {
        label =  to_string(get(edge_name,query)[*it]);
        startNode = to_string(get(vertex_name, 
                    query)[source(*it, query)]);
        endNode = to_string(get(vertex_name, 
                    query)[target(*it, query)]);

        edgeString = getEdgeString(label, startNode, endNode);

        if( m_featureEdges.find(edgeString) != 
                m_featureEdges.end() )
        {
            foundFeatureEdge = true;
            if( candidateIds.size() == 0 )
                candidateIds = m_featureEdges[edgeString];
            else
                setIntersection(candidateIds, 
                        m_featureEdges[edgeString]); 

        }
        else
        {
            candidateIds.clear();
            break;
        }
    }
}

void Index::pruneUsingFeatureGraphs(GraphType &query, 
        std::unordered_set<int> &candidateIds, bool &foundFeatureGraph)
{
    int queryNumEdges = num_edges(query);

    for(int i=0; i < m_featureGraphs.size(); i++)
    {
        for(int j=0; j < m_featureGraphs[i].size(); j++)
        {
            if( i <= queryNumEdges )
            {
                if( isIsoMorphic(m_featureGraphs[i][j], query) )
                {
                    foundFeatureGraph = true;
                    if( candidateIds.size() == 0 )
                        candidateIds = m_featGraphToGraphIds[i][j];
                    else
                        setIntersection(candidateIds, 
                                m_featGraphToGraphIds[i][j]);
                }
            }
        }
    }
}

void Index::generateCandidateSet(GraphType &query, 
        std::unordered_set<int> &candidateIds, bool &performFullSearch)
{
    this->pruneUsingFeatureNodes(query, candidateIds);
    if( candidateIds.size() == 0 )
    {
        performFullSearch = false;
        return;
    }

    bool foundFeatureEdge = false;
    this->pruneUsingFeatureEdges(query, candidateIds, 
            foundFeatureEdge);
    if( candidateIds.size() == 0 )
    {
        if( foundFeatureEdge )
        {
            performFullSearch = false;
            return;
        }
        else if( num_edges(query) )
        {
            performFullSearch = false;
            return;
        }
    }

    bool foundFeatureGraph = false;
    this->pruneUsingFeatureGraphs(query, candidateIds, 
            foundFeatureGraph);
    if( candidateIds.size() == 0 )
    {
        if( foundFeatureGraph )
            performFullSearch = false;
        else
            performFullSearch = true;
    }
}

void Index::performSubgraphIsomorphism(GraphType &query,
        std::unordered_set<int> &candidateIds, 
        std::unordered_set<int> &answerIds,
        bool &performFullSearch)
{
    if( performFullSearch )
    {
        int graphCtr = 0;
        for(auto g: m_database)
        {
            if( num_edges(query) <= num_edges(g) && 
                    isIsoMorphic(query, g) )
                answerIds.insert(graphCtr);
            graphCtr++;
        }
    }
    else
    {
        for(auto ids: candidateIds)
        {
            if( num_edges(query) <= num_edges(m_database[ids]) &&
                    isIsoMorphic(query, m_database[ids]) )
                answerIds.insert(ids);
        }
    }
}

void Index::searchQueryInDatabase(GraphType &query,
        std::unordered_set<string> &answerSet)
{
    std::unordered_set<int> candidateIds, answerIds;

    bool performFullSearch = false;
    this->generateCandidateSet(query, candidateIds, performFullSearch);

    this->performSubgraphIsomorphism(query, candidateIds, answerIds,
            performFullSearch);

    for(auto id: answerIds)
        answerSet.insert(m_graphIdToTrans[id]);
}

void Index::construct(string databaseFile, double gammaCut, 
        double supportPerc, int maxGraphSize)
{
    /*
    cout << "Graph Size : " << endl;
    for(int i=0; i < m_featureGraphs.size(); i++)
    {
        int j=0;
        for(; j < m_featureGraphs[i].size(); j++)
            cout << num_edges(m_featureGraphs[i][j]) << "; ";

        if( j != 0 )
            cout << endl << endl;
    }
    */

    /*
     * Loading Graph Database
     */
    m_featureGraphs.resize(maxGraphSize);
    m_featGraphToGraphIds.resize(maxGraphSize);

    cout << "* Loading the graph database." << endl;

    high_resolution_clock::time_point start = 
        high_resolution_clock::now();

    m_lg->readGraphFile(databaseFile, m_database, m_graphIdToTrans, 
            m_nodeLabelToId, m_edgeLabelToId);

    cout << "- Time Taken to read dataset : " 
        << getDurationInSeconds(start) << " secs." << endl;

    /*
    //debug
    //int cgraph = 0;
    for(auto gc: m_graphIdToTrans)
    {
        cout << gc.second << endl;
        cout << gc.first << " : " << (gc.second == "42614805") 
            << " ; " << gc.second << endl;
        cgraph++;
        if( cgraph > 5 )
            break;
    }
    */

    /*
     * Extracting node features
     */
    cout << "* Extracting node features." << endl;
    this->extractNodeFeatures();
    
    /*
     * DEBUG
    cout << "NODE FEATURE" << endl;
    map<int, string> nodeIdToLabel;
    map<string, int>::iterator itr;
    for(itr = m_nodeLabelToId.begin(); itr != m_nodeLabelToId.end(); 
            itr++)
        nodeIdToLabel[itr->second] = itr->first;
    for(auto i: m_featureNodes)
        cout << nodeIdToLabel[stoi(i.first)] << " : " 
            << (i.second).size() << endl;
     * DEBUG
     */

    /*
     * Extracting edge features
     */
    cout << "* Extracting edges features." << endl;
    this->extractEdgeFeatures();

    /*
     * DEBUG
    cout << "EDGE FEATURE" << endl;
    for(auto i: m_featureEdges)
        cout << i.first << " : " << (i.second).size() << endl;
     * DEBUG
     */

    /*
     * Running Gspan
     */
    start = high_resolution_clock::now();

    cout << "* Writing GSPAN input file." << endl;
    int pos, poss=-1;
    while( (poss = databaseFile.find(".", poss+1)) != string::npos )
        pos = poss;

    string gspanInputFile = 
        databaseFile.substr(0, pos) + "_gspan.txt_graph";
    m_lg->writeGspanInput(gspanInputFile, m_database);

    cout << "* Running GSPAN on the database." <<endl;
    string gspanCommand = "./bin/gSpan -f " + gspanInputFile
        + " -s " + to_string(supportPerc) + " -o -i";
    const char *command = gspanCommand.c_str();
    system(command);

    cout << "- Time Taken to run gspan : " 
        << getDurationInSeconds(start) << " secs." << endl;

    cout << "* Extracting graph features." << endl;
    string featureFile = gspanInputFile + ".fp";
    this->extractGraphFeatures(featureFile, gammaCut);

    /*
     * GRAPH FEATURES
     *
    vector<GraphType> featureGraphs;
    for(int i=0; i < m_featureGraphs.size(); i++)
        for(int j=0; j < m_featureGraphs[i].size(); j++)
            featureGraphs.push_back(m_featureGraphs[i][j]);
    //printGraph(featureGraphs, m_nodeLabelToId, m_edgeLabelToId);
    cout << "Feature size : " << featureGraphs.size() << endl;
    return;
     */

    /*
    cout << m_featureNodes.size() << endl;
    cout << m_featureGraphs.size() << endl;
    cout << "Feature Graph size : " << endl;
    for(auto g: m_featureGraphs)
        cout << g.size() << endl;
    */

}


void Index::query(string queryFile, string outputFile)
{
    /*
     * READING QUERY
     */
    cout << "Loading query file." << endl;
    vector<GraphType> m_queries;
    std::map<int, string> queryIdToTrans;
    m_lg->readGraphFile(queryFile, m_queries, queryIdToTrans,
            m_nodeLabelToId, m_edgeLabelToId);

    /*
     * WRITING OUTPUT
     */
    cout << "* Processing query" << endl;
    vector<std::unordered_set<string>> answerSets;

    int qCounter = 1;
    for(auto query: m_queries)
    {
        std::unordered_set<string> answerSet;

        high_resolution_clock::time_point start = 
            high_resolution_clock::now();
        this->searchQueryInDatabase(query, answerSet);
        cout << "- Time Taken to process Query " << qCounter << " : " 
            << getDurationInMilliseconds(start) << " millisecs." << endl;

        answerSets.emplace_back(answerSet);
        /*
        cout << qCounter << " : " << answerSet.size() << endl;
        */
        qCounter++;
    }

    cout << "* Writing query results" << endl;
    m_lg->writeQuerySearchResults(outputFile, answerSets);
}

