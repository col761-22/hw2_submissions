#include <iostream>
#include <unordered_set>
using namespace std;

#include "LoadGraph.h"
#include "HelperFunction.h"
#include "Index.h"

int main(int argc, char *argv[])
{
    string databaseFile = argv[1];


    vector<GraphType> database;
    map<int, string> graphIdToTrans;
    map<string, int> nodeLabelToId, edgeLabelToId;

    LoadGraph m_lg;

    cout << "* Loading the graph database." << endl;
    m_lg.readGraphFile(databaseFile, database, graphIdToTrans, 
            nodeLabelToId, edgeLabelToId);


    cout << "* Writing algorithm input file." << endl;
    int pos, poss=-1;
    while( (poss = databaseFile.find(".", poss+1)) != string::npos )
        pos = poss;

    string algoInputFile = 
        databaseFile.substr(0, pos) + "_algoinput.txt_graph";
    m_lg.writeGspanInput(algoInputFile, database);


    return 0;
}
