#include <iostream>
#include <unordered_set>
using namespace std;

#include "LoadGraph.h"
#include "HelperFunction.h"
#include "Index.h"

int main(int argc, char *argv[])
{
    string indexFile = argv[1];

    Index index;
    LoadGraph lg;
    lg.readIndex(indexFile, index);

    string queryFile, outputFile;
    cout << "Enter query file  : ";
    cin >> queryFile;
    cout << "Enter output file : ";
    cin >> outputFile;

    index.query(queryFile, outputFile);

    return 0;
}


