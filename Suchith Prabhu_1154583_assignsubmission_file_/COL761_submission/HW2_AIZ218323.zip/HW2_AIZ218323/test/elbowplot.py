import sys
import argparse
import pandas as pd
import numpy as np
from sklearn import metrics
from sklearn.cluster import KMeans
from scipy.spatial.distance import cdist

import matplotlib.pyplot as plt

def set_default(figsize=(10, 10), dpi=100):
    plt.style.use(['dark_background', 'bmh'])
    plt.rc('axes', facecolor='k')
    plt.rc('figure', facecolor='k')
    plt.rc('figure', figsize=figsize, dpi=dpi)


parser = argparse.ArgumentParser()
parser.add_argument("data_path", type=str,
                    help="path to the dataset.")
parser.add_argument("dimension", type=str,
                    help="dimension of the points.")
parser.add_argument("image_path", type=str,
                    help="path to save the image.")
args = parser.parse_args()

dataset = args.data_path
dimension = args.dimension
outputPath = args.image_path

with open(dataset, "r") as file:
    result = [[float(x) for x in line.split()] for line in file]

distortions = []
inertias=[]

K = range(1,16)
for k in K:
    kmeanModel = KMeans(n_clusters=k).fit(result)
    kmeanModel.fit(result)
    """
    distortions.append(sum(np.min(cdist(result,
    kmeanModel.cluster_centers_,
    'euclidean'), axis=1)) / result.shape[0])
    """
    inertias.append(kmeanModel.inertia_)

# Plot the elbow
set_default(figsize=(15, 10))

plt.plot(K, inertias, '-bD',  c='cyan', mfc='red', mec='k')
plt.xlabel(r'Number of clusters $(k)$')
plt.ylabel('Inertia')
plt.title(f'ELBOW PLOT FOR {dimension}D DATA')
plt.savefig(outputPath)
