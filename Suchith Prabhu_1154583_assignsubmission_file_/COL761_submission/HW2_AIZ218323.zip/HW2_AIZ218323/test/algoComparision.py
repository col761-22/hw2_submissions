import os
import pickle
import argparse
import subprocess
import matplotlib.pyplot as plt
from timeit import default_timer as timer

def set_default(figsize=(10, 10), dpi=100):
    plt.style.use(['dark_background', 'bmh'])
    plt.rc('axes', facecolor='k')
    plt.rc('figure', facecolor='k')
    plt.rc('figure', figsize=figsize, dpi=dpi)


parser = argparse.ArgumentParser()
parser.add_argument("data_path", type=str,
                    help="path to the dataset.")
parser.add_argument("image_path", type=str,
                    help="path to save the image without the png.")
args = parser.parse_args()

timeout = 7200
supportThresholds = [5, 10, 25, 50, 95]
r = [0, 100]

#supportThresholds = [90, 93, 95, 97, 99]
#r = [90, 100]

os.makedirs('data/', exist_ok=True)

"""
GSPAN runtime.
"""
print("GSPAN")
gspanTime = []
for supportVal in supportThresholds:
    print(f"- Running GSPAN for support threshold {supportVal}.")
    try:
        command = f'./bin/gSpan -f {args.data_path} -s {supportVal/100} -o -i'
        print(command)
        start = timer()
        o = subprocess.run(command, shell=True, timeout=timeout)
        end = timer()
        gspanTime.append(end - start)
    except:
        gspanTime.append(timeout)
print()


"""
GASTON runtime.
"""
print("GASTON")
gastonTime = []

command = f"grep '#' {args.data_path} | wc -l"
o = subprocess.run(command, shell=True, stdout=subprocess.PIPE)
numTrans = int(o.stdout)

for supportVal in supportThresholds:
    print(f"- Running GASTON for support threshold {supportVal}.")
    try:
        command = f'./bin/gaston {numTrans*supportVal/100} {args.data_path}'
        print(command)
        start = timer()
        o = subprocess.run(command, shell=True, timeout=timeout)
        end = timer()
        gastonTime.append(end - start)
    except:
        gastonTime.append(timeout)


"""
FSG runtime.
"""
print("FSG")
fsgTime = []
for supportVal in supportThresholds:
    print(f"- Running FSG for support threshold {supportVal}.")
    try:
        command = f'./bin/fsg -s {supportVal} {args.data_path}'
        print(command)
        start = timer()
        o = subprocess.run(command, shell=True, timeout=timeout)
        end = timer()
        fsgTime.append(end - start)
    except:
        fsgTime.append(timeout)


with open('data/algoComparison.pkl', 'wb') as f:
    pickle.dump((gspanTime, gastonTime, fsgTime), f)

num_points = 0
for i in range(len(supportThresholds)):
    if gspanTime[i] == timeout or gastonTime[i] == timeout or fsgTime[i] == timeout:
        num_points+=1
    else:
        break

supportThresholds = supportThresholds[num_points:]
set_default(figsize=(15, 10))
plt.plot(supportThresholds, gspanTime[num_points:], '-o')
plt.plot(supportThresholds, gastonTime[num_points:], '-o')
plt.plot(supportThresholds, fsgTime[num_points:], '-o')

plt.xlim(r[0], r[1])
plt.ylim(0)
plt.xticks(range(r[0], r[1]+1,max(1, int( (r[1]- r[0])/20 )) ))
plt.xlabel(r'Support Threshold $(\%)$')
plt.ylabel(r'Time $(sec)$')
plt.legend(['GSPAN', 'GASTON', 'FSG'])
plt.savefig(f'{args.image_path}.png')

