#include <fstream>
#include <iostream>
#include <unordered_set>
using namespace std;

#include "LoadGraph.h"
#include "HelperFunction.h"
#include "Index.h"

int main(int argc, char *argv[])
{
    string databaseFile = argv[1];
    string indexFile = argv[2];

    double gammaCut = stof(argv[3]);

    double supportPerc = 0.3;
    if( argc > 4 )
        supportPerc = stoi(argv[4]);

    int maxGraphSize = 15;
    if( argc > 5 )
        maxGraphSize = stoi(argv[5]);

    high_resolution_clock::time_point start = 
        high_resolution_clock::now();

    Index index;
    index.construct(databaseFile, gammaCut, supportPerc, maxGraphSize);

    cout << "* Writing graph index." << endl;
    LoadGraph lg;
    lg.writeIndex(indexFile, index);

    cout << "+ Time Taken for index construction : " 
        << getDurationInSeconds(start) << " secs." << endl;

    return 0;
}

