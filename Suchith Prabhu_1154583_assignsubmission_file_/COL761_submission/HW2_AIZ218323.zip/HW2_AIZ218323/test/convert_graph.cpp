#include <iostream>
#include <fstream>
#include <map>
using namespace std;

int main(int argc, char *argv[])
{
    string inFile = argv[1];
    string outFile = argv[2];

    ifstream fin(inFile);
    if( !fin.is_open() )
    {
        cout << "ERROR::Unable to open the file '" << inFile 
            << "'" << endl;
        return 1;
    }

    ofstream fout(outFile);
    if( !fout.is_open() )
    {
        cout << "ERROR::Unable to open the file '" << outFile 
            << "'" << endl;
        return 1;
    }

    string line;

    map<string, int> graphTransToId;
    map<string, int> nodeLabelToId, edgeLabelToId;

    int nodeLabelCount = 0, edgeLabelCount = 0, graphTransCount = 0;
    string graphTrans;
    while( fin >> line && line[0] == '#')
    {
        graphTrans = line.substr(1);
        if( graphTransToId.find( graphTrans ) != graphTransToId.end() )
        {
            cout << "ERROR::Invalid dataset format, graph transaction IDs cannot be similar." << endl;
            return 0;
        }
        graphTransToId[graphTrans] = graphTransCount;
        //output into file
        fout << "t # " << graphTransCount << endl;
        graphTransCount++;

        fin >> line;
        int numNode = stoi(line);
        for(int i=0; i < numNode; i++)
        {
            fin >> line;
            if( nodeLabelToId.find(line) == nodeLabelToId.end() )
            {
                nodeLabelToId[line] = nodeLabelCount;
                nodeLabelCount++;
            }
            //output into file
            fout << "v " << i << " " << nodeLabelToId[line] << endl;
        }

        fin >> line;
        int numEdges = stoi(line);
        int startNode, endNode;
        for(int i=0; i < numEdges; i++)
        {
            fin >> startNode >> endNode >> line;
            if( edgeLabelToId.find(line) == edgeLabelToId.end() )
            {
                edgeLabelToId[line] = edgeLabelCount;
                edgeLabelCount++;
            }

            if( startNode > endNode )
            {
                int tmp = startNode;
                startNode = endNode;
                endNode = tmp;
            }

            //output into file
            fout << "e "<< startNode << " " << endNode << " "<< edgeLabelToId[line] << endl;
        }

    }

    fin.close();
    fout.close();

    return 0;
}
