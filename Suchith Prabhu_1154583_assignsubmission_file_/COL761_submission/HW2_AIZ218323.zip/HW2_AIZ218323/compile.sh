#!/bin/bash

mkdir -p bin obj src include lib data test
make
