==============================================
==============================================
COL 761 - Assignment - 1
==============================================
==============================================

Team Name - Flash
---------------------

_______________________________________________
Github Repo Link
---------------------

https://github.com/suchith720/COL761_submission

_______________________________________________
Contributions
---------------------

Suchith Chidananda Prabhu - 35%
Himali Bajaj              - 35%
Kaushik Hira              - 30%

____________________________________________________
Team Members Details
---------------------

Suchith Chidananda Prabhu
Entry No - 2021AIZ8323
Email ID - aiz218323@scai.iitd.ac.in

Himali Bajaj
Entry No - 2021SIY7593
Email ID - siy217593@cse.iitd.ac.in

Kaushik Hira
Entry No - 2021AIY7586
Email ID - aiy217586@scai.iitd.ac.in

_____________________________________________
Commands
---------------------

./scripts/index.sh <dataset_path>
    eg ./scripts/index.sh data/167.txt_graph

./scripts/query.sh <dataset_path>
    eg ./scripts/query.sh data/167.txt_graph

./scripts/elbow_plot.sh <dataset_path> <dimension> <output_image_path>
    eg ./scripts/elbow_plot.sh data/167.txt_graph 2 data/q3_2_AIZ218323.png


./AIZ218323.sh -q1 <dataset_path> <image_path_without_extension>
./AIZ218323.sh -q2a <dataset_path>
./AIZ218323.sh -q2b <dataset_path>
./AIZ218323.sh -q3 <dimension>
    eg ./AIZ218323.sh -q1 data/167.txt_graph data/algoComparison
    eg ./AIZ218323.sh -q2a data/167.txt_graph
    eg ./AIZ218323.sh -q2b data/167.txt_graph
    eg ./AIZ218323.sh -q3 3

_____________________________________________
Files
---------------------

./README.txt
++ This file.

./AIZ218323_install.sh
++ This will clone the repo, load necessary modules and build the
   binaries required to run the scripts.

./test
    ./test/algoComparision.py
    ++ Q1 code, for comparing graph mining algorithms.

    ./test/elbowplot.py
    ++ Q3 code, for K-mean algorithm.

    ./test/convertGraph.cpp
    ++ This converts the graph dataset into format that can be then be
       used by graph mining binaries.
    ./test/query.cpp
    ++ Q2 code for query processing.
    ./test/index.cpp
    ++ Q2 code for index construction.

./src
    ./src/HelperFunction.cpp
    ++ Contains helper functions.

    ./src/LoadGraph.cpp
    ++ Object used for loading and saving graph dataset.

    ./src/Index.cpp
    ++ Object for index construction

./include
    ./include/Global.h
    ./include/HelperFunction.h
    ./include/LoadGraph.h
    ./include/Index.h

./scripts
    ./scripts/index.sh
    ./scripts/elbow_plot.sh
    ./scripts/query.sh

./Makefile

./AIZ218323.sh

./compile.sh

./command.txt

./bin
    ./bin/fsg
    ./bin/gSpan
    ./bin/generateDataset_d_dim_hpc_compiled
    ./bin/gaston
    ./bin/query
    ./bin/convertGraph
    ./bin/index

./notebooks
    ./notebooks/graph_mining.ipynb
    ./notebooks/EDA.ipynb

./lib
    ./lib/gaston-1.1
    ./lib/pafi-1.0.1
    ./lib/gSpan6

./obj
    ./obj/LoadGraph.o
    ./obj/Index.o
    ./obj/HelperFunction.o

**********************************************
