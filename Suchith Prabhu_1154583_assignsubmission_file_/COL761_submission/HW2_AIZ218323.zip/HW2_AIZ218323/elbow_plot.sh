if [ $# -lt 3 ]
then
    echo ERROR::Invalid arguements
    echo ./scripts/elbow_plot.sh "<dataset_path> <dimension> <image_path>"
    exit 1
fi

if [ ! -f $1 ]
then
    echo ERROR::File \'$1\' does not exist.
    exit 1
fi

if [ $2 -lt 2 ] || [ $2 -gt 4 ]
then
    echo ERROR::Dimension should be between 2 - 4.
    exit 1
fi

python test/elbowplot.py $1 $2 $3

