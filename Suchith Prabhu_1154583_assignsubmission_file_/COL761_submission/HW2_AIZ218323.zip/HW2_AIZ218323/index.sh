if [ $# -lt 1 ]
then
    echo ERROR::Invalid format.
    echo ./scripts/index.sh '<dataset_path>'
    exit 1
fi

if [ ! -f $1 ]
then
    echo ERROR::File \'$1\' does not exist.
    exit 1
fi

dir_name=$(dirname $1)
indexFile=$(basename $1 | sed -E 's/(\w+)\.(\w+)/\1.index/g')
indexFile=$dir_name/$indexFile

numGraph=$(grep '#' $1 | wc -l)

gammaCut=1.05
if [ $numGraph -lt 50000 ]
then
    gammaCut=1.1
elif [ $numGraph -lt 40000 ]
then
    gammaCut=1.2
elif [ $numGraph -lt 30000 ]
then
    gammaCut=1.3
fi

./bin/index $1 $indexFile $gammaCut
