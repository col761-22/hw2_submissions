if [ $# -lt 1 ]
then
    echo ERROR::Invalid format.
    echo ./scripts/query '<dataset_path>'
    echo ./scripts/query '<dataset_path> <input_file>'
    exit 1
fi

if [ ! -f $1 ]
then
    echo ERROR::File \'$1\' does not exist.
    exit 1
fi

dir_name=$(dirname $1)
indexFile=$(basename $1 | sed -E 's/(\w+)\.(\w+)/\1.index/g')
indexFile=$dir_name/$indexFile

if [ ! -f $indexFile ]
then
    echo ERROR::File \'$indexFile\' does not exist, please run \
        index generation scipt.
    exit 1
fi

if [ $# -gt 1 ]
then
    if [ ! -f $2 ]
    then
        echo ERROR::File \'$2\' does not exist.
        exit 1
    fi
    ./bin/query $indexFile < $2
else
    ./bin/query $indexFile
fi

