if [ $# -lt 2 ]
then
    echo ERROR::Invalid format.
    echo ./AIZ218323.sh -q1  '<dataset_path> <image_path_without_extension>'
    echo ./AIZ218323.sh -q2a '<dataset_path>'
    echo ./AIZ218323.sh -q2b '<dataset_path>'
    echo ./AIZ218323.sh -q3  '<dimension>'
    exit 1
fi


if [ $1 == "-q1" ]
then
    if [ $# -lt 3 ]
    then
        echo ERROR::Invalid format.
        echo ./AIZ218323.sh -q1 '<dataset_path> <image_path_without_extension>'
        exit 1
    fi

    if [ ! -f $2 ]
    then
        echo ERROR::File \'$2\' does not exist.
        exit 1
    fi
    ./bin/bin/convertGraph $2

    dir_name=$(dirname $2)
    inputfile=$(basename $2 | sed -E 's/(\w+)\.(\w+)/\1_algoinput.\2/g')
    inputfile=$dir_name/$inputfile
    python test/algoComparision.py $inputfile $3

elif [ $1 == "-q2a" ]
then
    if [ ! -f $2 ]
    then
        echo ERROR::File \'$2\' does not exist.
        exit 1
    fi
    ./scripts/index.sh $2

elif [ $1 == "-q2b" ]
then
    if [ ! -f $2 ]
    then
        echo ERROR::File \'$2\' does not exist.
        exit 1
    fi
    ./scripts/query.sh $2 $3

elif [ $1 == "-q3" ]
then
    mkdir -p data

    rollno="AIZ218323"
    datafile=$rollno"_generated_dataset_$2D.dat"

    if [ $2 -lt 2 ] || [ $2 -gt 4 ]
    then
        echo ERROR::Invalid format.
        echo '<dimension> should be between 2 - 4.'
        exit 1
    fi

    dataset=data/$datafile
    if [ ! -f $dataset ]
    then
        ./bin/generateDataset_d_dim_hpc_compiled $rollno $2
        mv $datafile $dataset
    fi

    ./scripts/elbow_plot.sh $dataset $2 data/q3_$2'_'$rollno.png
else
    echo ERROR::Invalid first arguement.
fi

