#include <iostream>
#include <fstream>
#include <chrono>
#include <map>

#include <boost/graph/vf2_sub_graph_iso.hpp>
#include <boost/graph/graph_utility.hpp>
#include <boost/graph/adjacency_list.hpp>

using namespace std;
using namespace boost;
using namespace std::chrono;

#ifndef __GLOBAL__
#define __GLOBAL__

typedef property<edge_name_t, int> PropEdge;
typedef property<vertex_name_t, int, property<vertex_index_t, int> > PropNode;
typedef adjacency_list<vecS, vecS, undirectedS, PropNode, PropEdge> GraphType;

typedef property_map<GraphType, vertex_name_t>::type vertex_name_map_t;
typedef property_map_equivalent<vertex_name_map_t, vertex_name_map_t> vertex_comp_t;
typedef property_map<GraphType, edge_name_t>::type edge_name_map_t;
typedef property_map_equivalent<edge_name_map_t, edge_name_map_t> edge_comp_t;


template<typename Graph1, typename Graph2> struct vf2_callback
{
    vf2_callback(Graph1 g, Graph2 f){
    }
    template <typename CorrespondenceMap1To2,
          typename CorrespondenceMap2To1>
    bool operator()(CorrespondenceMap1To2 f, CorrespondenceMap2To1 g) const {
        return false;
    }
};
#endif
