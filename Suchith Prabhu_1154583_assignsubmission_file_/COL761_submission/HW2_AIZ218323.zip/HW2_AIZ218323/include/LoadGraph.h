#include <iostream>
#include <fstream>

#include "Global.h"

#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>

using namespace std;
using namespace boost;

#ifndef __LOAD_GRAPH__
#define __LOAD_GRAPH__

class Index;

#include "Index.h"

class LoadGraph 
{ 
    public:

    LoadGraph();

    int readGastonOutput(string filename, vector<GraphType> &graphs);
    int readGspanOutput(string filename, vector<GraphType> &graphs, 
            std::unordered_map<int, 
            std::unordered_set<int>> &freqIdToGraphIds);
    int readGspanOutputBySize(string filename, 
        vector<vector<GraphType>> &freqGraphs, 
        vector<vector<std::unordered_set<int>>> &freqIdToGraphIds);

    int readGraphFile(string filename, 
        vector<GraphType> &graphs,
        map<int, string> &graphIdToTrans, 
        map<string, int> &nodeLabelToId,
        map<string, int> &edgeLabelToId);

    int writeQuerySearchResults(string outputFile,
        vector<std::unordered_set<string>> &answerSets);

    int writeGspanInput(string filename, vector<GraphType> &graph);

    int readIndex(string filename, Index &index);

    int writeIndex(string filename, Index &index);
};

#endif

