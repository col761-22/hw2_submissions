#include <vector>
#include "Global.h"

#ifndef __HELPER_FUNCTION__
#define __HELPER_FUNCTION__

void printGraph(vector<GraphType> &graphs);
void printGraph(GraphType &g);

void printGraph(vector<GraphType> &graphs, 
        map<int, string> &m_graphIdToTrans,
        map<string, int> &nodeLabelToId, 
        map<string, int> &edgeLabelToId);

void printGraph(GraphType &g, 
        map<int, string> &nodeIdToLabel, 
        map<int, string> &edgeIdToLabel);

string getEdgeString(string &label, string &startNode, string &endNode);
bool isIsoMorphic(GraphType G1, GraphType G2);

void setIntersection(std::unordered_set<int> &s1,
        std::unordered_set<int> &s2);

float getDurationInSeconds(high_resolution_clock::time_point start);

float getDurationInMicroseconds(high_resolution_clock::time_point start);

float getDurationInMilliseconds(high_resolution_clock::time_point start);

#endif
