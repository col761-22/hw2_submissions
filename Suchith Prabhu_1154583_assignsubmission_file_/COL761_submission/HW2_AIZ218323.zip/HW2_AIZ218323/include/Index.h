#include <iostream>
#include <unordered_map>
#include <unordered_set>
#include "Global.h"
#include "HelperFunction.h"

#include <boost/archive/binary_oarchive.hpp>
#include <boost/archive/binary_iarchive.hpp>
#include <boost/serialization/map.hpp>
#include <boost/serialization/vector.hpp>
#include <boost/serialization/unordered_set.hpp>
#include <boost/serialization/unordered_map.hpp>
#include <boost/graph/adj_list_serialize.hpp>
#include <boost/serialization/serialization.hpp>

using namespace std;
using namespace boost; 

#ifndef __INDEX__
#define __INDEX__

class LoadGraph;

#include "LoadGraph.h"

class Index
{
    friend class boost::serialization::access;

    LoadGraph *m_lg;

    /*
     * Database meta-information
     */
    vector<GraphType> m_database;

    std::map<int, string> m_graphIdToTrans;
    std::map<string, int> m_nodeLabelToId, m_edgeLabelToId;

    /*
     * Database features
     */
    std::unordered_map<string, std::unordered_set<int>> 
        m_featureNodes; 

    std::unordered_map<string, std::unordered_set<int>> 
        m_featureEdges; 

    vector<vector<GraphType>> m_featureGraphs;
    vector<vector<std::unordered_set<int>>> 
        m_featGraphToGraphIds;

    template<class Archive>
    void serialize(Archive & ar, const unsigned int version)
    {
        ar & m_database;
        ar & m_graphIdToTrans;
        ar & m_nodeLabelToId;
        ar & m_edgeLabelToId;
        ar & m_featureNodes;
        ar & m_featureEdges;
        ar & m_featureGraphs;
        ar & m_featGraphToGraphIds;
    }

    public:

    Index();

    void extractNodeFeatures();

    void extractEdgeFeatures();

    double getGamma(int idx, int graphSize, int featureSize);
    void extractGraphFeatures(string featureFile, double gammaCut);

    void pruneUsingFeatureNodes(GraphType &query, 
            std::unordered_set<int> &candidateIds);
    void pruneUsingFeatureEdges(GraphType &query, 
        std::unordered_set<int> &candidateIds, bool &foundFeatureEdge);
    void pruneUsingFeatureGraphs(GraphType &query,
            std::unordered_set<int> &candidateIds, 
            bool &foundFeatureGraph);
    void generateCandidateSet(GraphType &query, 
            std::unordered_set<int> &candidateIds, 
            bool &performFullSearch);

    void performSubgraphIsomorphism(GraphType &query,
            std::unordered_set<int> &candidateIds, 
            std::unordered_set<int> &answerSet, 
            bool &performFullSearch);

    void searchQueryInDatabase(GraphType &query,
            std::unordered_set<string> &answerSet);


    void construct(string databaseFile, double gammaCut=1.4,
            double supportPerc=0.3, int maxGraphSize=15);

    void query(string queryFile, string outputFile);

};


#endif

