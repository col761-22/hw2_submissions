#!/bin/bash
python3 q3_MCS212124_kmeans.py "$1" "$2" "$3"