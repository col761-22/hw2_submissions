g++ gspanformatconverter.cpp -o gspanformatconverter -O3
g++ q2.cpp -I /home/apps/LIBBOOST/1.64.0/gnu_ucs71/include/ -o index -O3
g++ q2_query.cpp -I /home/apps/LIBBOOST/1.64.0/gnu_ucs71/include/ -o query -O3