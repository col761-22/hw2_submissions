git clone https://github.com/mrengima-aparsinghal/COL761-Dataminds.git
cd COL761-Dataminds
unzip HW2_MCS212124.zip
cd HW2_MCS212124
module load compiler/gcc/7.1.0/compilervars
module load compiler/python/3.6.0/ucs4/gnu/447
module load compiler/python/2.7.13/ucs4/gnu/447
module load lib/gnu/710/boost/1.64.0/gnu
module load lib/boost/1.64.0/gnu_ucs71
module load pythonpackages/3.6.0/numpy/1.15.0/gnu
module load pythonpackages/3.6.0/matplotlib/3.0.2/gnu
module load pythonpackages/3.6.0/ucs4/gnu/447/pandas/0.18.1/intel
module load pythonpackages/3.6.0/scikit-learn/0.21.2/gnu
module load pythonpackages/2.7.13/ucs4/gnu/447/scikit-learn/0.18.1/gnu
module load pythonpackages/2.7.13/ucs4/gnu/447/pandas/0.20.0rc1/gnu
module load pythonpackages/2.7.13/ucs4/gnu/447/matplotlib/2.0.0/gnu
module load pythonpackages/2.7.13/ucs4/gnu/447/numpy/1.12.1/gnu

