git clone https://github.com/mrengima-aparsinghal/COL761-Dataminds.git
cd COL761-Dataminds
unzip HW1_MCS212124.zip
cd HW1_MCS212124
module load pythonpackages/3.6.0/matplotlib/3.0.2/gnu
module load compiler/gcc/7.1.0/compilervars
module load compiler/python/3.6.0/ucs4/gnu/447

