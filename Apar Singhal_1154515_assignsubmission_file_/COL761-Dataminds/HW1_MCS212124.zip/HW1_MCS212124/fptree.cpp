
//#include <bits/stdc++.h>
#include <map>
#include <set>
#include <vector>
#include <iostream>
#include <cstring>
#include <string.h>
#include <sstream>
#include <fstream>
#include <unordered_map>
#include <algorithm>
#include<set>

//#include<bits/stdc++.h>
using namespace std;

struct Fpnode {
	int freq;
	int data;
	Fpnode * parent;
	unordered_map<int, Fpnode *>childNode;
};
struct Rtd {
	Fpnode *root;
	map<int, vector<Fpnode*>> ht;
	bool cmp(pair<int, int>&a, pair<int, int>&b)
	{
		if (a.second < b.second)
			return true;
		else if (a.second == b.second)
			return to_string(a.first) < to_string(b.first);
		else
			return false;

	}
};
void f1(Fpnode *root, map<int, vector<Fpnode*>> headTable, map<int, int>freq, float sv);
void f2(set<int>s, vector<vector<pair<int, int>>>ss, map<int, int>mrg, float sv);
set<set<int>>outcome;
typedef struct Fpnode Fpnode;
void recur(Rtd * rtd, map<int, int>mp, float sv, set<int>s2);
void treeprint(struct Fpnode *root)
{
	struct Fpnode*temp = root;


	cout << " data " << temp->data << " ";
	cout << " freq " << temp->freq << " ";
	if (temp->parent)
		cout << "parent " << temp->parent->data;
	else
		cout << "ROOT";

	for (auto it = temp->childNode.begin();it != temp->childNode.end();it++)
	{
		treeprint(it->second);
	}
	cout << endl;
}


typedef struct Rtd Rtd;
Rtd *createTree(Fpnode *root, vector<int>s, map<int, vector<Fpnode*>> &headTable)
{

	Fpnode *temp = root;
	if (s.empty() == true)
	{
		Rtd * out = new(Rtd);
		out->ht = headTable;
		out->root = root;
		return out;

	}
	auto it = s.begin();
	while (temp->childNode.count(*it) != 0 && it != s.end())
	{
		//temp->freq+=1;
		temp->childNode[*it]->freq += 1;
		temp = temp->childNode[*it];
		it++;
	}

	while (it != s.end())
	{
		Fpnode *node = new(Fpnode);
		temp->childNode[*(it)] = node;
		node->parent = temp;
		node->freq = 1;
		headTable[*it].push_back(node);
		node->data = *(it);
		temp = temp->childNode[*(it)];
		it++;

	}
	Rtd * out = new(Rtd);
	out->ht = headTable;
	out->root = root;
	return out;
}

bool sortbysecl(const pair<int,int> &a,
              const pair<int,int> &b)
{
    if (a.second > b.second)
	return true;
    else
    return false;
}

int main(int argc, char** argv)
{

	long long int countransaction = 0;
	string inputfilename = argv[1];
    float sv = std::stof(argv[2]);
    string outfilename = argv[3];
	//float sv;
	set<set<string>>result;
	//std::cout<<"sv";
	//cin >> sv;

	Fpnode * root1;
	string line;
	ifstream fin;
	fin.open(inputfilename);

	// Reading line by line

	map<int, int>mps;  //map to read a line  
	if (fin.is_open())
	{
		string line;
		while (getline(fin, line))
		{
			countransaction++;
			istringstream iss(line);
			int number;
			while (iss >> number)
			{
				mps[number]++;
			}
		}
	}
	fin.close();
	sv = (sv*countransaction) / 100;
	//cout << countransaction <<":::"<<sv<<endl;
	auto itr = mps.begin();
	int n = mps.size();
	map<int, int> mus;
	for (itr = mps.begin();itr != mps.end();itr++)
	{
		if (itr->second < sv)
		{
			continue;
		}
		else {
			mus[itr->first] = itr->second;
		}
	}
	mps = mus;
	// for (itr = mps.begin();itr != mps.end();itr++)
	// {
	// 	cout<< itr->first<<"-"<<itr->second<<"  ";
	// }
	set<string>mt;

	vector<pair<int, int>> m;
	for (auto itr = mps.begin();itr != mps.end();itr++)
	{
		m.push_back({itr->first, itr->second});
	}
	sort(m.begin(), m.end(), sortbysecl);

	Fpnode *root = new(Fpnode);
	root->data = 0;
	root->parent = NULL;
	root->freq = 0;

	root1 = root;


	ifstream  fin1;
	fin1.open(inputfilename);

	// Reading line by line

   // map<set<int>,int>mps;  //map to read a line  
	map<int, vector<Fpnode*>> headTable;
	while (true)
	{
		vector<int>v;
		string line1;
		getline(fin1, line1);
		map<int,int>mp2;

		istringstream iss(line1);

		int number;
		while (iss >> number)
		{
			// if (mps[number] != 0)
			// 	v.push_back(number);
			
			mp2[number]++;

		}
		for (int i = 0; i < m.size(); i++)
		{
			if (mp2[m[i].first] !=0)
			{
				v.push_back(m[i].first);
			}
		}
		//cout<<"RTead1"<<endl;
		// for (int i = 0;i < v.size() - 1;i++)
		// {
		// 	for (int j = i + 1;j < v.size();j++)
		// 	{
		// 		if (mps[v[i]] < mps[v[j]])
		// 		{
		// 			swap(v[i], v[j]);
		// 		}
		// 	}
		// }
		//cout<<"RTead2"<<endl;
		Rtd * res = new(Rtd);
		res = createTree(root1, v, headTable);
		root1 = res->root;
		headTable = res->ht;
		//cout<<"RTead3"<<endl;
		if (fin1.eof() == true) break;

	}
	//cout<<"Read over";
	fin1.close();
	Rtd * check = new(Rtd);
	check->root = root1;
	check->ht = headTable;

	//treeprint(root1);
	if (mps.size()!=0)
	{
		f1(root, headTable, mps, sv);
	}
	

	//cout << "  ans ";
	set<set<string>> outcome1;
	for (auto mit = outcome.begin();mit != outcome.end();mit++)
	{
		set<string> sa;
		for (auto sit = mit->begin();sit != mit->end();sit++)
		{ 
			sa.insert(to_string(*(sit)));
		}
		outcome1.insert(sa);
	}

	ofstream myfile;
	myfile.open(outfilename);

	for (auto mit = outcome1.begin();mit != outcome1.end();mit++)
	{
		for (auto sit = mit->begin();sit != mit->end();sit++)
		{
			//cout<<*sit<<" ";
			myfile << *sit << " ";
			//cout << *(sit) << " ";

		}
		myfile << endl;
		//cout << endl;
		//  cout<<endl;
	}

}
bool sortbysec(const pair<int,int> &a,
              const pair<int,int> &b)
{
    if (a.second < b.second)
	return true;
	else if(a.second==b.second)
	  return (to_string(a.first)<to_string(b.first));
	  else
	  return false;
}
void f1(Fpnode *root, map<int, vector<Fpnode*>> headTable, map<int, int>freq, float sv)
{

	vector<pair<int, int>>v;
	for (auto cit : freq)
	{
		if (cit.second >= sv)
		{
			v.push_back({cit.first,cit.second});
		}
	}
	
	sort(v.begin(), v.end(), sortbysec);

	for (int i=0; i<v.size(); i++)
    {
        // "first" and "second" are used to access
        // 1st and 2nd element of pair respectively
        // cout << v[i].first << " "
        //       << v[i].second << endl;
		set<int> s;
		s.insert(v[i].first);
		outcome.insert(s);

		vector<vector<pair<int, int>>>ss;
		for (auto it = headTable[v[i].first].begin();it != headTable[v[i].first].end();it++)
		{
			Fpnode *temp = *(it);
			vector<pair<int, int>>sx;
			int k = 0;
			while (temp->parent != NULL)
			{  
			//not entering the key data   
			if (v[i].first== temp->data)
					k = temp->freq;
			temp = temp->parent;
			}
			temp = *(it);
			while (temp->parent != NULL)
			{  
			if(v[i].first!=temp->data)
				sx.push_back(make_pair(temp->data, k));
			temp = temp->parent;
			}
			if (!sx.empty())   //if s is not empty then insert;
				ss.push_back(sx);
			sx.clear();
		}

		// for(auto it=ss.begin();it!=ss.end();it++)
		// {
		// 	for(auto mit=(*it).begin();mit!=(*it).end();mit++)
		// 	{
		// 		cout<<"data "<<mit->first<<"freq"<<mit->second;
		// 	}
		// 	cout<<endl;
		// }
		// cout<<"END OF PAHTA !"<<endl;
		map<int, int>mrg;

		for (auto it = ss.begin();it != ss.end();it++)
		{
			for (auto mit = (*it).begin();mit != (*it).end();mit++)
			{
				mrg[mit->first] += mit->second;
			}
		}

		// for (auto itr = mrg.begin();itr != mrg.end();itr++)
		// {
		// 	cout<< itr->first<<"-"<<itr->second<<"  ";
		// }

		auto kit = mrg.begin();
		int n = mrg.size();
		map<int, int> mus;
		for (kit = mrg.begin();kit != mrg.end();kit++)
		{
			if (kit->second < sv)
			{
				continue;
			}
			else {
				mus[kit->first] = kit->second;
			}
		}
		mrg = mus;
		kit = mrg.begin();
		n = mrg.size();

		// for (int i = 0;i < n;i++)
		// {
		// 	set<int>st = s;
		// 	st.insert(kit->first);
		// 	kit++;
		// 	outcome.insert(st);
		// 	st.clear();
		// }
		vector<vector<pair<int, int>>>ss1;
		for (auto it = ss.begin();it != ss.end();it++)
		{
			vector<pair<int, int>>stp1;
			for (auto mit = (*it).begin();mit != (*it).end();mit++)
			{
			if (mrg[mit->first] != 0)
			{
				stp1.push_back(make_pair(mit->first, mit->second));
			}
			}
			ss1.push_back(stp1);
			stp1.clear();
		}
		
		// for(auto it=ss1.begin();it!=ss1.end();it++)
		// {
		// 	for(auto mit=(*it).begin();mit!=(*it).end();mit++)
		// 	{
		// 		cout<<"data "<<mit->first<<"freq"<<mit->second;
		// 	}
		// 	cout<<endl;
		// }
		// cout<<"END OF PAHTA !"<<endl;c
		if (mrg.size()!=0)
		{
			f2(s, ss1, mrg, sv);
		}
    }
}

void f2(set<int>s, vector<vector<pair<int, int>>>ss, map<int, int>mrg, float sv)
{
	vector<pair<int, int>>vv;
	for (auto cit : mrg)
	{
		if (cit.second >= sv)
		{
			vv.push_back({cit.first,cit.second});
		}
	}
	sort(vv.begin(), vv.end(), sortbysec);


	//////////////////////////////////////////////////////////
	for (int i = 0;i < vv.size();i++)
	{
		set<int>s1 = s;
		s1.insert(vv[i].first);
		outcome.insert(s1);
		int k = mrg[vv[i].first];//kit->second;
		vector<vector<pair<int, int>>>ss1;
		vector<vector<pair<int, int>>>ss2;
		for (auto it = ss.begin();it != ss.end();it++)
		{
			vector<pair<int, int>>stp1;
			int f = 0;
			for (auto mit = (*it).begin();mit != (*it).end();mit++)
			{
				if (mit->first == vv[i].first)//kit->first)
				{
					f = 1;
				}
				else
				{
					stp1.push_back(make_pair(mit->first, mit->second));
				}
			}
			if (f == 1)
				ss1.push_back(stp1);
			ss2.push_back(stp1);
			stp1.clear();
		}
		
            // for(auto it=ss1.begin();it!=ss1.end();it++)
			// {
			// 	for(auto mit=(*it).begin();mit!=(*it).end();mit++)
			// 	{
			// 		cout<<"data "<<mit->first<<"freq"<<mit->second;
			// 	}
			// 	cout<<endl;
			// 		}

			// 		cout<<"END OF PAHTA !"<<endl;
				/////////////////////////////
			map<int, int>mrg1;

			for (auto it = ss1.begin();it != ss1.end();it++)
			{
				for (auto mit = (*it).begin();mit != (*it).end();mit++)
				{
					mrg1[mit->first] += mit->second;
				}
			}
			auto kit1 = mrg1.begin();
			int n = mrg1.size();
			map<int, int> mus;
			for (kit1 = mrg1.begin();kit1 != mrg1.end();kit1++)
			{
				if (kit1->second < sv)
				{
					continue;
				}
				else {
					mus[kit1->first] = kit1->second;
				}
			}
			mrg1 = mus;

				// for(int i=0;i<n;i++)
				// {
				//     if(kit1->second<sv)
				//       {
				//         mrg1.erase(kit1);
				//       }
				//       kit1++;
				// }

				//resutl skjf;lkas
			kit1 = mrg1.begin();
			n = mrg1.size();
			for (int i = 0;i < n;i++)
			{
				set<int>st = s1;
				st.insert(kit1->first);
				kit1++;
				outcome.insert(st);
				st.clear();
			}
			///////////////////////////////
		if (mrg1.size()!=0)
		{
			f2(s1, ss1, mrg1, sv);
		}
		if (ss2.size()==0)
		{
			break;
		}
		ss= ss2;
		s1.clear();
	}
}
