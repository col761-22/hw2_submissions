import matplotlib.pyplot as plt
import subprocess
import sys
from timeit import timeit

sv = [90,50,25,10,5]
a_times = []
fp_times = []
filename = sys.argv[1]
outputfilename = sys.argv[2]

def run_system_call_fptree(code_type,support,filename):
    subprocess.run(["./fptree",filename,str(support),"filename"+".txt"])
    
def run_system_call_apriori(code_type,support,filename):
    subprocess.run(["./apriori",filename,str(support),"filename"+".txt"])

def measure_time_function(func, *args, **kwargs):
    def time_function():
        return func(*args, **kwargs)
    return time_function

### Apriori Algo time ###
for support in sv:
    time_function = measure_time_function(run_system_call_apriori, "apriori",support,filename)
    a_times.append(timeit(time_function, number=1))

### FP tree Algo time ###
for support in sv:
    time_function = measure_time_function(run_system_call_fptree, "fptree",support,filename)
    fp_times.append(timeit(time_function, number=1))


print(fp_times)
print(a_times)

plt.plot(sv,a_times,'-b',label = '-Apriori')
plt.plot(sv,fp_times,'-r',label = '-Fptree')
plt.xlabel('Support %')
plt.ylabel('Run time (sec)')
plt.legend(loc='upper right')
plt.title('Comparision of thresholds vs running time for Apriori and Fptree')
plt.savefig(outputfilename+".png")
##plt.show()
