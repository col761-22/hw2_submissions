#include <bits/stdc++.h>
 
/* fstream header file for ifstream, ofstream,
  fstream classes */
#include <fstream>
 
using namespace std;
 
// Driver Code

void prints(map<set<int>,int>&mps)
{
  
  for(auto mpit= mps.begin();mpit!=mps.end();mpit++)
  {
  
    for(auto sit=mpit->first.begin();sit!=mpit->first.end();sit++)
    {
            cout<<*sit<<" ";
    }
    cout<<mpit->second<<endl;
  

  }
 
}



map<set<int>,int> pruning(map<set<int>,int>mps,int c,int s)
{

//cout<<"Pruning ..";
map<set<int>,int> mps2;
  int t=mps.size();
  if(t==0)
  return mps;
 auto mit=mps.begin();
 while(t--)
    {
    if(mit->second<s)
    {
   // cout<<"NO" <<" " ;
      //mps.erase(mit->first.begin(),mit->first.end());
    }
    else
    { mps2[mit->first]=mit->second;
    
    }
   mit++;
    
    }
return mps2;
}

map<set<int>,int>candidate_gen(map<set<int>,int>mps,int c,int v)
{
map<set<int>,int>mps2;

 //file name;
 string s;
 //cout<<"candidate Generation......";
for(auto mpit=mps.begin();mpit!=mps.end();mpit++)
{
    
   for(auto mpit2=mpit;mpit2!=mps.end();mpit2++)
   {
   
    
    
   //union of set 
   set<int>rs1;
    int n=mpit->first.size();
    
    auto sit1=mpit->first.begin();
    auto sit2=mpit2->first.begin();

  //checking valid candidate 
    int f=1;
    for(int i=0;i<n-1;i++)
    {
      if(*(sit1)!=*(sit2))
      {
        f=0;
        break;
      }
      sit1++;
      sit2++;
    }

    if(f==0)
    continue;
    else
    {
      if(*sit1==*sit2)
        continue;
      else
      {
        //making set for valid candidate
        
      for(auto sit=mpit->first.begin();sit!=mpit->first.end();sit++)
    {
            //cout<<*sit<<" ";
            rs1.insert(*sit);
    }
  
       for(auto sit=mpit2->first.begin();sit!=mpit2->first.end();sit++)
    {
            //cout<<*sit<<" ";
            rs1.insert(*sit);
    }
      }
    }
    
        
         
       //cout<<" rs1 size "<<rs1.size()<<" "<<validcandidate(rs1,s,v);
          
        //checking compatibility and inserting it in mps2  
      if(rs1.size()==mpit->first.size()+1)//&& validcandidate(rs1,s,v)==1)
        {
          mps2[rs1]=0;
          //cout<<72;
        }
        rs1.clear();
   }
}
return mps2;

}

map<set<int>,int>set_freq(map<set<int>,int>mps,int c,int v,string s)
{  
    string line;
    ifstream fin;
    fin.open(s);
  //  cout<<"freq count...";
    while (fin) 
    {
      int c=0;
      set<int> st;
        getline(fin, line);
        istringstream iss(line);
        int number;
        
       map<int,int>mp;
     while(iss >> number)
      {
     // cout<<number<<" ";
      
    
      mp[number]++;
      
     }
     
     
     for(auto it=mps.begin();it!=mps.end();it++)
     { int f=1;
     
        for(auto sit=it->first.begin();sit!=it->first.end();sit++)
        {
           if(mp[*sit]==0)
           { f=0;
            break;
           }
           
             
         }
         if(f==1)
          mps[it->first]++;
        
        
     }
     
     
      
     
    }
      fin.close();
      return mps;
    


}

int main(int argc, char** argv)
{
    //cout<<"sv";

    long long int countransaction=0;
    string inputfilename = argv[1];
    float sv = std::stof(argv[2]);
    string outputfilename = argv[3];
    //cin>>sv;
    string line;
    set<set<string>>result;
    ifstream fin;
    //cout<<"adkn:";
    fin.open(inputfilename);
 
    // Reading line by line
    
    map<set<int>,int>mps;
     map<set<int>,int>mps2,mps3;
     //cout<<"freq firsr";
    while (fin) 
    {
       countransaction++;
        getline(fin, line);
         if(fin.eof()==true) break;
        istringstream iss(line);
        int number;
     while(iss >> number)
      {
     // cout<<number<<" ";
      set<int>s;
      s.insert(number);
      mps[s]++;
     }
     
      
     
    }
    fin.close();
   // cout<<"pruning";
    
    sv=(sv*countransaction)/100;
    // cout<<countransaction<<" "<<sv;

    mps2=pruning(mps,1,sv);
    

  //number of items
    int n=mps2.size();
    int k=-1;
    
    auto fst=mps2.begin();
    while(n!=0&&mps2.size()!=1&&mps2.size()!=0)
    {
    
    
     n--;
    
    // k=mps2.size();

     for(auto it=mps2.begin();it!=mps2.end();it++)
     { 
     set<string>m;
        for(auto sit=it->first.begin();sit!=it->first.end();sit++)
        {
          
           m.insert(to_string(*sit));
           // cout<<(*sit) <<" ";
            
         }
         //cout<<endl;
         result.insert(m);
         m.clear();
     }
      map<set<int>,int>mps4;
     
    mps4=candidate_gen(mps2,1,sv);
    mps2=mps4;
   // cout<<"total candidate before pruning"<<mps2.size()<<" "<<mps4.size();
    
    mps2=set_freq(mps2,1,sv,inputfilename);
    mps2=pruning(mps2,1,sv);
    
    //cout<<"size "<<mps2.size()<<" ";
     
     

   
 
    
    }
    
    ofstream myfile;
  myfile.open (outputfilename);
  
    for(auto it=result.begin();it!=result.end();it++)
     { 
        for(auto sit=it->begin();sit!=it->end();sit++)
        {
         //  cout<<*sit<<" ";
            myfile<<*sit<<" ";
            
         }
         myfile<<endl;
       //  cout<<endl;
         
     }
  
    return 0;
}
