g++ -std=c++11 -O3 -Wno-deprecated query.cpp -o query -I./vf3lib-master/include -DVF3
num=$(<"meta_data.txt")
./query index_graph.txt converted.txt_graph index_support.txt output_CS1190408.txt 1 $num