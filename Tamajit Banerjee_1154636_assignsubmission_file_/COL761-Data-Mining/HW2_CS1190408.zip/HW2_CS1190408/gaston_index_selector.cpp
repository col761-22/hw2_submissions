#include <bits/stdc++.h>

int  N;

int main(int argv,char* argc[])
{

    N = std::stoi(argc[1]);
	std::string feature_file = argc[2];         //"gaston_small.txt";
    std::string selected_file = argc[3];     //"gaston_selected.txt";

    std::ifstream in;
	std::ofstream out;

    out.open(selected_file); //std::ios_base::app
	in.open(feature_file);

    std::vector<std::vector<int>> index;

    if ( !out || !in ){
        std:: cerr << " File didn't open\n";
        return 0;
    }

    std::string lin;
	int cnt = 0;
	bool wr = false;
    while(getline(in, lin)){
        if(lin.size() == 0 )
            continue;
        std::istringstream iss(lin);
        char ch;
		iss>>ch;
        int tid,sup,g;

        //std::string g;
		if(ch == 'v' && wr){
			int id,lab;
			iss>>id>>lab;
			out<<"v "<<id<<" "<<lab<<"\n";
		}
		else if(ch == 'e' && wr){
			int v1,v2,lab;
			iss>>v1>>v2>>lab;
			out<<"e "<<v1<<" "<<v2<<" "<<lab<<"\n";
		}
		else if(ch =='t' && wr){
            iss>>tid;
			out<<"t "<<tid<<"\n";
			cnt++;
		}
        else if(ch == '#'){
            iss>>sup;
            if(N > 3*sup){
				out<<"# "<<sup<<"\n";
				wr = true;
			}
			else{
				wr = false;
            }
        }

    }
    std::cout<<"Graphs Selected : "<<cnt<<"\n";
	in.close();
	out.close();
}
