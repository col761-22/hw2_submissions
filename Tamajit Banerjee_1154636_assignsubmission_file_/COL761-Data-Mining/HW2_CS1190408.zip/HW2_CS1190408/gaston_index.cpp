#include <stdio.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <stdlib.h>
#include <string>
#include <time.h>
#include <algorithm>
#include <chrono>
#include <set>
#include <map>
#include <vector>
#ifndef WIN32
#include <csignal>
#include <unistd.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <errno.h>
#else
#include <Windows.h>
#include <stdint.h>
#endif

#include "WindowsTime.h"
#include "VFLib.h"
#include "Options.hpp"

using namespace vflib;

void writeIndexFile(std::vector<std::vector<int>> &index,std::string feature_file,std::string index_graphs,std::string index_support )
{

    std::ifstream db;
	std::ofstream ind;

    db.open(feature_file);
	ind.open(index_graphs);

    if ( !db || !ind ){
        std:: cerr << " File didn't open\n";
        return ;
    }

    std::string lin;
	int tid = 0;
	bool wr = false;
    while(getline(db, lin)){
        std::istringstream iss(lin);
        char ch;
		iss>>ch;
		if(ch == 'v' && wr){
			int id,lab;
			iss>>id>>lab;
			ind<<"v "<<id<<" "<<lab<<"\n";
		}
		else if(ch == 'e' && wr){
			int v1,v2,lab;
			iss>>v1>>v2>>lab;
			ind<<"e "<<v1<<" "<<v2<<" "<<lab<<"\n";
		}
		else if(ch =='t'){
			if(index[tid].size()>0){
				ind<<"t # "<<tid<<" * "<<index[tid].size()<<"\n";
				wr = true;
			}
			else{
				wr = false;
			}
			tid++;
		}
    }
	ind.close();
	db.close();

	ind.open(index_support);

	for(auto u : index) {
		if(u.size()>0){
			for(auto v : u)
				ind<<v<<" ";
			ind<<"\n";
		}
	}

	ind.close();
	std::cout<<"index graph : "<<tid<<"\n";
	std::cout<<"index support : "<<index.size()<<"\n";
}

int main(int argv, char* argc[])
{

	auto start = std::chrono::high_resolution_clock::now();

	Options opt;
	uint32_t n1, n2;
	std::vector<MatchingSolution> solutions;
	std::vector<uint32_t> class_patt;
	std::vector<uint32_t> class_targ;
	uint32_t classes_count;

	std::string pat_file = argc[1]; //"gaston_small.txt"; // "/Users/abhinavjain/Desktop/col761/hw2_updated/gaston_working/gaston-1.1-re/gaston_small.txt";
	std::string tar_file = argc[2]; //"converted.txt_graph"; //"/Users/abhinavjain/Desktop/col761/hw2_updated/167_converted.txt_graph";
	
	opt.pattern = &pat_file[0];
	opt.target = &tar_file[0];
	opt.undirected = true;

	std::ifstream graphInPat(opt.pattern);
	std::ifstream graphInTarg(opt.target);

	std::vector<ARGLoader<data_t, data_t>* > superGraphs;
	ARGLoader<data_t, data_t>* pattloader;
	ARGLoader<data_t, data_t>* targloader;
	
	int tid =0;

	while(1){
		targloader = CreateLoader<data_t, data_t>(opt, graphInTarg);
		if(targloader->NodeCount() == 0 )
			break;
		superGraphs.push_back(targloader);
		tid++;
	}
	std::cout<<"No. of graphs in database : "<<tid<<"\n";

	// std::cout<<"nodes in pattern "<<patt_graph.NodeCount()<<"\n";

	std::ofstream log;
	log.open("log.txt");

	tid = 0;
	std::vector<std::vector<int>> index;

	int cnt=0;

	while(1){
		pattloader = CreateLoader<data_t, data_t>(opt, graphInPat);
		if(pattloader->NodeCount() == 0 )
			break;
		ARGraph<data_t, data_t> patt_graph(pattloader);
		n1 = patt_graph.NodeCount();

		index.push_back({});

		int i = 0;

		if((cnt>=100) || (n1>3 && rand()%10>0)){
			//std::cout<<tid<<" -> "<<index[tid].size()<<"\n";
			tid++;
			continue;
		}

		cnt++;

		for(auto targloader : superGraphs) {
			ARGraph<data_t, data_t> targ_graph(targloader);
			FastCheck<data_t, data_t, data_t, data_t > check(&patt_graph, &targ_graph);
			
			n2 = targ_graph.NodeCount();

			MatchingEngine<state_t >* me = CreateMatchingEngine(opt);
			if(check.CheckSubgraphIsomorphism())
				{
					NodeClassifier<data_t, data_t> classifier(&targ_graph);
					NodeClassifier<data_t, data_t> classifier2(&patt_graph, classifier);
					class_patt = classifier2.GetClasses();
					class_targ = classifier.GetClasses();
					classes_count = classifier.CountClasses();
					VF3NodeSorter<data_t, data_t, SubIsoNodeProbability<data_t, data_t> > sorter(&targ_graph);
					std::vector<nodeID_t> sorted = sorter.SortNodes(&patt_graph);

					state_t s0(&patt_graph, &targ_graph, class_patt.data(), class_targ.data(), classes_count, sorted.data());
					me->FindAllMatchings(s0);
					#ifdef TRACE
					me->FlushTrace();
					#endif

					if(me->GetSolutionsCount()>0){
						index[tid].push_back(i);
						//log<<i<<" -> \n";
					}
				}
			i++;
		}
		//std::cout<<tid<<" -> "<<index[tid].size()<<"\n";
		tid++;
	}
	
	std::cout<<cnt<<"\n";
	log.close();

	writeIndexFile(index,pat_file,"index_graph.txt","index_support.txt");
	graphInPat.close();
	graphInTarg.close();

	auto finish = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double, std::milli> elapsed = finish - start;
	std::cout << "Elapsed Time: " << elapsed.count()/1000.0 << " seconds" << std::endl;
}
