#include <bits/stdc++.h>
using namespace std;

int main(int argc, char *argv[])
{

    string infile = argv[1]; //"/Users/abhinavjain/Desktop/col761/hw2_updated/167.txt_graph";
    string outfile = argv[2]; //"/Users/abhinavjain/Desktop/col761/hw2_updated/167_converted.txt_graph";

    ifstream in;
    ofstream out;

    in.open(infile);
    out.open(outfile);

    if ( !in || !out ){
        std:: cerr << " File didn't open\n";
        return 0;
    }

    std::string lin;
	int tid = 0;
    map<string,int> mp;
    int cnt = 0;

    vector<int> v;

    while(getline(in, lin)){
        // getline(in, lin);
        // std::istringstream iss(lin);
        if(lin.length()==0) 
            continue;
        
        if(lin[0] == '#') {
            std::istringstream iss(lin);
            char ch;
            iss>>ch;
            int orig_id;
            iss>>orig_id;
            int nv,ne,v1,v2,el;
            in>>nv;
            string lab;
            v.push_back(orig_id);

            out<<"t # "<<tid<<"\n";

            for(int i = 0; i<nv; i++){
                in>>lab;
                if(mp.find(lab)==mp.end()){
                    mp[lab] = cnt;  cnt++;
                }
                out<<"v "<<i<<" "<<mp[lab]<<"\n";
            }

            in>>ne;
        
            for(int i = 0; i<ne; i++){
                in>>v1>>v2>>el;
                out<<"e "<<v1<<" "<<v2<<" "<<el<<"\n";
            }
            
            tid++;
        }
        //cout<<tid<<endl;
    }

    in.close();
    out.close();

    string map_file = argv[3]; //"/Users/abhinavjain/Desktop/col761/hw2_updated/label_map.txt";
    out.open(map_file);

    for(auto it = mp.begin(); it!=mp.end(); it++){
        out<<it->first<<" "<<it->second<<"\n";
    }
    out.close();

    string meta_file = argv[4]; // "/Users/abhinavjain/Desktop/col761/hw2_updated/meta_data.txt";
    out.open(meta_file);
    out<<tid<<"\n";
    out.close();

    string graph_file = argv[5]; //"/Users/abhinavjain/Desktop/col761/hw2_updated/graph_label.txt";
    out.open(graph_file);

    for(auto u : v){
        out<<u<<"\n";
    }
    out.close();

    return 0;
}