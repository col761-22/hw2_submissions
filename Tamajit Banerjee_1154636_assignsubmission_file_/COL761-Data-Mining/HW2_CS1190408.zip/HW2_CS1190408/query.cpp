#include <stdio.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <stdlib.h>
#include <string>
#include <time.h>
#include <algorithm>
#include <map>
#include <vector>
#include <set>
#include <chrono>
#ifndef WIN32
#include <csignal>
#include <unistd.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <errno.h>
#include <set>
#else
#include <Windows.h>
#include <stdint.h>
#endif

#include "WindowsTime.h"
#include "VFLib.h"
#include "Options.hpp"

using namespace vflib;

int N = 64110; //number of graphs in database

int main(int argv, char* argc[])
{
	Options opt_feature,opt_database;
	uint32_t n1, n2;
	std::vector<uint32_t> class_patt;
	std::vector<uint32_t> class_targ;
	uint32_t classes_count;

	std::string query_file; 					// "/Users/abhinavjain/Desktop/col761/hw2_updated/pat.txt";

	std::string feature_graph_file = argc[1]; 	//"/Users/abhinavjain/Desktop/col761/hw2_updated/index_graph.txt";
	std::string database_file = argc[2]; 		//"/Users/abhinavjain/Desktop/col761/hw2_updated/167_converted.txt_graph";
	std::string feature_support_file =argc[3]; 	//"/Users/abhinavjain/Desktop/col761/hw2_updated/index_support.txt";
    std::string ans_file = argc[4]; 			//"/Users/abhinavjain/Desktop/col761/hw2_updated/ans.txt";

	int format = std::stoi(argc[5]);
	N = std::stoi(argc[6]);
    // load the database
	std::cout<<"Loading Index \n";

	opt_database.target = &database_file[0];
	opt_database.undirected = true;

	std::ifstream graphInDatabase(opt_database.target);

	std::vector<ARGLoader<data_t, data_t>* > databaseGraphs;
	ARGLoader<data_t, data_t>* targloader;
	
	int tid =0;

	while(1){
		targloader = CreateLoader<data_t, data_t>(opt_database, graphInDatabase);
		if(targloader->NodeCount() == 0 )
			break;
		databaseGraphs.push_back(targloader);
		tid++;
	}
	std::cout<<"No. of graphs in database : "<<tid<<"\n";
    graphInDatabase.close();

    
    // load the feature graphs
	opt_feature.pattern = &feature_graph_file[0];
	opt_feature.undirected = true;

	std::ifstream graphInFeature(opt_feature.pattern);
	std::vector<ARGLoader<data_t, data_t>* > featureGraphs;
	
	tid = 0;
    
	while(1){
		targloader = CreateLoader<data_t, data_t>(opt_feature, graphInFeature);
		if(targloader->NodeCount() == 0 )
			break;
		featureGraphs.push_back(targloader);
		tid++;
	}
	std::cout<<"No. of feature graphs : "<<tid<<"\n";
    graphInFeature.close();
	
	//load graph labels
	std::vector<int> graph_id;
	std::ifstream inp_graph;
	inp_graph.open("graph_label.txt");
	std::string lin;
	int id;
	while(getline(inp_graph,lin)){
		if(lin.size()==0) continue;
		std::istringstream iss(lin);
		iss>>id;
		graph_id.push_back(id);
	}
	inp_graph.close();
	std::cout<<"graph_id "<<graph_id.size()<<"\n";

 	// load the feature support
    std::vector<std::set<int>> featureSupport;
    std::ifstream supportInFeature(feature_support_file);

    int n;
    while(getline(supportInFeature,lin)){
        std::istringstream iss(lin);
        featureSupport.push_back({});
        while(iss>>n){
            featureSupport.back().insert(n);
        }
    }

	std::cout<<"No. of features : "<<featureSupport.size()<<"\n";
    supportInFeature.close();

    std::set<int> init;
    for(int i=0; i<N;i++)
            init.insert(i);

	std::cout<<"Index Loaded \n";

	std::cout<<"Enter path of query file \n";
    // index loaded. Now take query file as input
    std::cin>>query_file;
	//query_file = "../custom_query.txt";

    auto start = std::chrono::high_resolution_clock::now();
    opt_database.pattern = &query_file[0];
    opt_feature.target = &query_file[0];
    std::ifstream graphInPat(opt_database.pattern);
    ARGLoader<data_t, data_t>* queryloader;

	// std::ofstream log;
	// log.open("log.txt");

	std::set<int> prunedGraphs;
    std::vector<std::vector<int>> ans;

	std::map<std::string,int> mp;
	if(format){
		std::ifstream inp;
		inp.open("label_map.txt");
		std::string lin;
		while(getline(inp,lin)){
			std::istringstream iss(lin);
			std::string lab;
			int id;
			iss>>lab>>id;
			mp[lab] = id;
		}
		inp.close();
		opt_database.mp = mp;
		opt_database.q = true;
	}

	while(1){
	
		queryloader = CreateLoader<data_t, data_t>(opt_database, graphInPat);
        //break if no more queries left
		if(queryloader->NodeCount() == 0 ){
            std::cout<<"All queries processed \n";
			break;
        }

		ARGraph<data_t, data_t> query_graph(queryloader);
		n2 = query_graph.NodeCount();

		int feature_index = 0;
		prunedGraphs = init;

		for(auto featureloader : featureGraphs) {
            n1 = featureloader->NodeCount();

            if(n1<2){
                feature_index++;
                continue;
            }

			ARGraph<data_t, data_t> feature_graph(featureloader);
			FastCheck<data_t, data_t, data_t, data_t > check(&feature_graph, &query_graph);
			
			

			MatchingEngine<state_t >* me = CreateMatchingEngine(opt_feature);
			if(check.CheckSubgraphIsomorphism())
				{
					NodeClassifier<data_t, data_t> classifier(&query_graph);
					NodeClassifier<data_t, data_t> classifier2(&feature_graph, classifier);
					class_patt = classifier2.GetClasses();
					class_targ = classifier.GetClasses();
					classes_count = classifier.CountClasses();
					VF3NodeSorter<data_t, data_t, SubIsoNodeProbability<data_t, data_t> > sorter(&query_graph);
					std::vector<nodeID_t> sorted = sorter.SortNodes(&feature_graph);

					state_t s0(&feature_graph, &query_graph, class_patt.data(), class_targ.data(), classes_count, sorted.data());
					me->FindAllMatchings(s0);
					#ifdef TRACE
					me->FlushTrace();
					#endif

					if(me->GetSolutionsCount()>0){
                        std::set<int> temp;
						for(auto f : prunedGraphs){
                             if(featureSupport[feature_index].find(f)!=featureSupport[feature_index].end())
                                temp.insert(f);
                        }
                        prunedGraphs = temp;
						//log<<i<<" -> \n";
					}
				}
            //log<<feature_index<<"\n";
			feature_index++;
		}


        std::cout<<"No. of Pruned Graphs : "<< prunedGraphs.size()<<"\n";

        //queryloader = CreateLoader<data_t, data_t>(opt_database, graphInPat);
        n1 = query_graph.NodeCount();
        ans.push_back({});

        // for(auto g : prunedGraphs){
        //     log<<"* "<<g<<"\n";
        // }
        // log<<"***** \n \n***** \n";

        for(auto g : prunedGraphs)
        {
            //log<<g<<"\n";
			ARGraph<data_t, data_t> targ_graph(databaseGraphs[g]);
			FastCheck<data_t, data_t, data_t, data_t > check(&query_graph, &targ_graph);
			
			n2 = targ_graph.NodeCount();

			MatchingEngine<state_t >* me = CreateMatchingEngine(opt_database);
			if(check.CheckSubgraphIsomorphism())
				{
					NodeClassifier<data_t, data_t> classifier(&targ_graph);
					NodeClassifier<data_t, data_t> classifier2(&query_graph, classifier);
					class_patt = classifier2.GetClasses();
					class_targ = classifier.GetClasses();
					classes_count = classifier.CountClasses();
					VF3NodeSorter<data_t, data_t, SubIsoNodeProbability<data_t, data_t> > sorter(&targ_graph);
					std::vector<nodeID_t> sorted = sorter.SortNodes(&query_graph);

					state_t s0(&query_graph, &targ_graph, class_patt.data(), class_targ.data(), classes_count, sorted.data());
					me->FindAllMatchings(s0);
					#ifdef TRACE
					me->FlushTrace();
					#endif

					if(me->GetSolutionsCount()>0){
						ans.back().push_back(g);
						//log<<i<<" -> \n";
					}
				}
        }
        std::cout<<ans.back().size()<<"\n";
	}
	
	//log.close();
	graphInPat.close();
    
    std::ofstream out;
	out.open(ans_file);

   // std::cout<<"nj\n";
	for(auto u : ans) {
		if(u.size()>0){
			for(auto v : u)
				out<<graph_id[v]<<"\t";
		}
        out<<"\n";
	}

	out.close();

    auto finish = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double, std::milli> elapsed = finish - start;
	std::cout << "\n ---- \n ---- \n ---- \n\nTotal Elapsed Time: " << elapsed.count() << " milli seconds" << std::endl;
}
