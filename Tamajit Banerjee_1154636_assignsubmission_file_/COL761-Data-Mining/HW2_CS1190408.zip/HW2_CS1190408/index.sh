path=$1
g++ -std=c++17 -O3 converter.cpp -o convert
g++ -std=c++17 -O3 gspan_index.cpp -o gspan_index
g++ -std=c++17 -O3 gaston_index_selector.cpp -o gaston_index_selector
g++ -std=c++11 -O3 -Wno-deprecated gaston_index.cpp -o gaston_index -I./vf3lib-master/include -DVF3
./convert $path converted.txt_graph label_map.txt meta_data.txt graph_label.txt
echo "File Format Converted"
./gSpan-64 -f converted.txt_graph -s 0.3 -o -i
num=$(<"meta_data.txt")
sup=$(expr $num / 20)
./gaston-1.1-re/gaston -m 5 $sup converted.txt_graph gaston_small.txt
./gaston_index_selector $num gaston_small.txt gaston_selected.txt
echo "Building Index"
./gaston_index gaston_selected.txt converted.txt_graph
echo "..."
./gspan_index $num converted.txt_graph.fp index_graph.txt index_support.txt
echo "Index Built"