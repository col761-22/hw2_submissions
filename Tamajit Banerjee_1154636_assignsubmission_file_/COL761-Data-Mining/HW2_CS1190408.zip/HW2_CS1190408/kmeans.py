from sklearn.cluster import KMeans
import numpy as np
import matplotlib.pyplot as plt
import argparse
from numpy.linalg import norm as np_norm

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset_path', type=str, default='dataset.dat')
    parser.add_argument('--dimension', type=int, default=2)
    parser.add_argument('--save_path', type=str, default="plot.png")
    return parser.parse_args()

def read_data(file_path):
    with open(file_path) as f:
        data = f.readlines()
    data = [d.replace("\n", "").split() for d in data]
    data = [[float(d1) for d1 in d] for d in data]
    return np.array(data)


if __name__ == "__main__":
    inertias = {}

    args = get_args()
    if args.save_path == "":
        args.save_path = "q3_{}_{}.png".format(args.dimension, "CS1190408")

    X = read_data(args.dataset_path)
    # print(X)
    # print(X.shape)

    K = range(1, 15)
    
    for k in K:
        model = KMeans(n_clusters=k)
        model.fit(X)

        inertias[k] = model.inertia_
    
    inertias = [inertias[k] for k in inertias.keys()]

    # plot inertias
    plt.plot(K, inertias, label = "variances")
    plt.scatter(K, inertias, label = "variances")
    plt.title("Elbow curve for dimension {}".format(args.dimension))
    plt.xlabel("K")
    plt.ylabel("Variation Within Clusters (Inertia)")
    plt.xticks(K)
    plt.savefig(args.save_path, dpi=300)
    plt.close()
