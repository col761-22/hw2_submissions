#include <bits/stdc++.h>

int  N;

int main(int argv,char* argc[])
{

    N = std::stoi(argc[1]);
	std::string feature_file = argc[2];         //"converted.txt_graph.fp";
    std::string index_graph_file = argc[3];     //"index_graph.txt";
	std::string index_support_file = argc[4];   //"index_support.txt";

    std::ifstream in;
	std::ofstream out;

    out.open(index_graph_file,std::ios_base::app); //std::ios_base::app
	in.open(feature_file);

    std::vector<std::vector<int>> index;

    if ( !out || !in ){
        std:: cerr << " File didn't open\n";
        return 0;
    }

    std::string lin;
	int tot = 0;
	bool wr = false;
    int tid,sup,g;
    while(getline(in, lin)){
        if(lin.size() == 0 )
            continue;
        std::istringstream iss(lin);
        char ch;
		iss>>ch;
        //std::string g;
		if(ch == 'v' && wr){
			int id,lab;
			iss>>id>>lab;
			out<<"v "<<id<<" "<<lab<<"\n";
		}
		else if(ch == 'e' && wr){
			int v1,v2,lab;
			iss>>v1>>v2>>lab;
			out<<"e "<<v1<<" "<<v2<<" "<<lab<<"\n";
		}
		else if(ch =='t'){
            iss>>ch;
            iss>>tid;
            iss>>ch;
            iss>>sup;
            //std::cout<<sup<<" ";
			if(2*N > 4*sup){
				out<<"t # "<<tid<<" * "<<sup<<"\n";
				wr = true;
                tot++;
			}
			else{
				wr = false;
			}
			
		}
        else if(ch == 'x' && wr){
            index.push_back({});
            int cnt = 0;
            while(cnt < sup){
                iss>>g;
                assert(g>=0 && g<=64110);
                index.back().push_back(g);  cnt++;
            }
            // std::cout<<"\n";
            // std::cout<<g<<" ";
            //break;
            //std::cout<<"\n";
            // std::cout<<index.size()<<" "<<index.back().size()<<" "<<sup<<"\n";
            //break;
            if(sup == 0)
                std::cout<<"he "<<tid<<"\n";
            assert(index.back().size()==sup);
        }
    }
	in.close();
	out.close();

	out.open(index_support_file,std::ios_base::app); //std::ios_base::app);

    std::cout<<"gspan index graphs "<<tot<<"\n";
    std::cout<<"gspan index support "<<index.size()<<"\n";
	for(auto u : index) {
		if(u.size()>0){
			for(auto v : u)
				out<<v<<" ";
			out<<"\n";
		}
        else{
            std::cout<<u.size()<<"\n";
        }
	}

	out.close();
}
