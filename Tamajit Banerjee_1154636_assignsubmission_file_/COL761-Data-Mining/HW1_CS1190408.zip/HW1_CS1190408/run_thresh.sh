alg=$1
path=$2
declare -a thresholds=("90" "50" "25" "10" "5")
for thr in "${thresholds[@]}"
do
    echo "===========================================" >&2
    echo "Running "$alg" algorithm with support threshold "$thr"%" >&2
    echo "===========================================" >&2
    time ./${alg} $path $thr output_temp.dat 
done