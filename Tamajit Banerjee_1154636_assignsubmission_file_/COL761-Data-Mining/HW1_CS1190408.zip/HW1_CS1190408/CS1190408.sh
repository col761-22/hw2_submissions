to_run=$1

if [ $to_run == "-apriori" ]; then
	./apriori $2 $3 $4
fi

if [ $to_run == "-fptree" ]; then
	./fptree $2 $3 $4
fi

if [ $to_run == "-plot" ]; then
	timeout 3600 ./run_thresh.sh fptree $2 2>./times_fptree.txt
	timeout 3600 ./run_thresh.sh apriori $2 2>./times_apriori.txt
	python3 plot.py $3
fi