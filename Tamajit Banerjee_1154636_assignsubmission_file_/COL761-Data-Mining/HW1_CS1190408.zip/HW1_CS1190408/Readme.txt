## Files  bundled

- Apriori.cpp
	This contains the core code  for frequent itemset mining using the Apriori algorithm.
- FP_Tree.cpp
	This contains the core code  for frequent itemset mining using the FP Tree algorithm.
-  plot.py 
	This contains code for parsing output prints and preparing a lint plot for time comparision between the two algorithms
- compile.sh
	This contains commands to compile both core codes
- 2019CS10408.sh 
	Main bash script to run either of the two algorithms or the comparision plot with necessary arguments as described in the problem statement.
- run_thresh.sh
	script run internally for running both algorithms on different thresholds for the plot
- plot.png
	actual plot we obtained for the provided webdocs.dat data


## Comparision between Apriori and FP Tree algorithms


The Apriori algorithm pairs different valid itemsets to generate new candidate itemsets by extending the itemset size by one during each iteration. After generating all candidate itemsets for a particular size, it scans through the transactions to calculate supports. Only the candidate itemsets are saved in  memory, and the transactions are read from the dataset everytime.

The FP-Tree algorithm generates a tree for producing frequent patterns. The tree is conditioned on every item in the dataset. Thus, only a single scan of the dataset is needed to prepare the tree initially. Both the candidate itemsets and the tree are saved in  memory, and the transactions are read from the dataset once. 

From the above descriptions, it can be seen that the FP Tree algorithm should generally take much lesser time than the Apriori algorithm. One major bottleneck is the reading of transactions from the dataset and since FP Tree requires lesser accesses to the dataset, it tends to perform better. This trend is observed  in the plot of the running times of these algorithms on different thresholds. For the case of threshold=90%, since the set  of itemsets is empty and FP-Tree algorithm goes through the dataset twice anyways, it takes longer than the Apriori algorithm, which in this case only goes through the dataset  once. In all other cases, we can see that FP-Tree performs much faster than the Apriori algorithm.


##  Team member details

1) 2019CS10408 - Tamajit Banerjee
2) 2019CS10322 - Abhinav Jain
3) 2019CS10341 - Mustafa Chasmai

## Contributions

1) Tamajit - 33%
2) Abhinav - 33%
3) Mustafa - 33%