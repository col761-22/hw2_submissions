#include <bits/stdc++.h>
using namespace std;

#pragma GCC target("avx2")

bool check_eq(vector<int>& a, vector<int>& b, int n){
    for(int i=0;i<n;i++)
        if( a[i] != b[i] )
            return false;
    return true;
}

int check_present(vector<int>& a, vector<vector<int> >& b, bool ind){
    int l = 0;
    int r = b.size();
    int sz = a.size();
    while( l < r){
        int mid = (l+r)/2;
        int comp = 1;
        for(int i=0;i<sz;i++){
            if( a[i] < b[mid][i] ){
                comp = 0;
                break;
            }else if( a[i] > b[mid][i] ){
                comp = 2;
                break;
            }
        }
        if( comp == 1 ){
            if( !ind )
                return 1;
            else
                return mid;
        }
        if( comp == 0 )
            r = mid;
        else
            l = mid + 1;
    }
    if( !ind )
        return 0;
    else
        return -1;
}

// b is subsequence of a and b and a are sorted
bool check_sub(vector<int>& a, vector<int>& b){
    int sz = a.size();
    int cur = 0;
    for(int i=0;i<sz;i++){
        if( b[cur] == a[i] )
            ++cur;
        if(cur == b.size())
            return true;
    }
    return false;
}


bool somp(int& a, int& b){
    return to_string(a) < to_string(b);
}

bool comp(vector<int>& a, vector<int>& b){
    string a_n = "";
    for(int i=0;i<a.size();i++){
        a_n += to_string(a[i]);
        if(i!=a.size()-1)
            a_n += ' ';
    }
    string b_n = "";
    for(int i=0;i<b.size();i++){
        b_n += to_string(b[i]);
        if(i!=b.size()-1)
            b_n += ' ';
    }

    int sz = min(a_n.size(),b_n.size());
    for(int i=0;i<sz;i++){
        if(a_n[i] < b_n[i])
            return  true;
        else if( a_n[i] > b_n[i])
            return false;
    }
    return a_n.size() < b_n.size();
}

std::chrono::high_resolution_clock::time_point t1;
bool exceed_THRESHOLD(){
    std::chrono::high_resolution_clock::time_point t2 = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> time_span = std::chrono::duration_cast<std::chrono::duration<double>>(t2 - t1);
    return (time_span.count() > 300.0);
}
string outputfile_;
void dump(vector<vector<int> >& valid_candidates_){
    for(int i=0;i<valid_candidates_.size();i++)
        sort(valid_candidates_[i].begin(),valid_candidates_[i].end(),somp);

    sort(valid_candidates_.begin(),valid_candidates_.end(),comp);
    ofstream outdata;
    outdata.open(outputfile_);

    for(int  i=0;i<valid_candidates_.size();i++){
        for(int j=0;j<valid_candidates_[i].size();j++){
            outdata << valid_candidates_[i][j];
            if( j < valid_candidates_[i].size() - 1)
                outdata << " ";
        }
        outdata << "\n";
    }

    outdata.close();

}


void Generate( vector<vector<int> >& cur_candidates_, vector<vector<int> >& possible_candidates_ ){
    if( cur_candidates_.size() == 0 )
        return;
    int sz = cur_candidates_[0].size();
    for(int i=0;i<cur_candidates_.size();i++){
        for(int j=i+1;j<cur_candidates_.size();j++){
            if(!check_eq(cur_candidates_[i],cur_candidates_[j],sz-1))
                break;
            vector<int> add = cur_candidates_[i];
            add.push_back(cur_candidates_[j][sz-1]);
            possible_candidates_.push_back(add);
        }
    }
}

void Prune( vector<vector<int> >& cur_candidates_, vector<vector<int> >& possible_candidates_,vector<vector<int> >& pruned_candidates_){
    if( possible_candidates_.size() == 0 )
        return;
    int sz = possible_candidates_[0].size();
    for(int i=0;i<possible_candidates_.size();i++){
        bool can_prune = false;
        vector<int> tm;
        for(int j=1;j<sz;j++)
            tm.push_back(possible_candidates_[i][j]);
        for(int j=0;j<sz-2;j++){
            can_prune |= !(check_present(tm,cur_candidates_,false));
            if( can_prune )
                break;
            tm[j] = possible_candidates_[i][j];
        }
        if( !can_prune )
            pruned_candidates_.push_back(possible_candidates_[i]);
    }
}

void ComputeSupport( vector<vector<int> >& pruned_candidates_, vector<vector<int> >& cur_candidates_, int minsup_, string file_){
    if( pruned_candidates_.size() == 0 )
        return;

    int itemsz = pruned_candidates_[0].size(); 
    int sz = pruned_candidates_.size();
    vector<int> support_cnt(sz,0);

    // open the file
    ifstream data;
    data.open(file_);

    //read the file to get all the distinct elements
    string lin;
    int trans_ids = 0;
    while(getline(data, lin)){
        istringstream iss(lin);
        vector<int> trans;
        int num;
        while( (iss >> num ) )
            trans.push_back(num);
        ++trans_ids;
        sort(trans.begin(),trans.end());
        auto it = unique(trans.begin(), trans.end());
        trans.resize(distance(trans.begin(), it));
        int transz = trans.size();
        if(itemsz == 2 and 25 * transz < sz){
            for(int i=0;i<transz;i++)
                    for(int j=i+1;j<transz;j++){
                        vector<int> temp = {trans[i],trans[j]};
                        int ind = check_present(temp, pruned_candidates_, true);
                        if(ind != -1)
                            ++support_cnt[ind];
                    }
            continue;
        }
        for(int i=0;i<sz;i++)
            if( check_sub(trans,pruned_candidates_[i]))
                ++support_cnt[i];
    }

    for(int i=0;i<sz;i++)
        if(support_cnt[i] >= minsup_)
            cur_candidates_.push_back(pruned_candidates_[i]);

    data.close();
}


int main(int argc, char *argv[]){

    assert(argc == 4);

    string file_ = argv[1]; // dataset path
    outputfile_ = argv[3]; // outputfilepath
    
    int minsup_ = 0;
    int trans_ids = 0;
    // open the file
    ifstream data;
    data.open(file_);
    if ( !data ){
        cerr << " File didn't open\n";
        return 0;
    }
    

    //read the file to get all the distinct elements 
    unordered_map<int,int> m;
    vector<int> ele;
    string lin;
    while(getline(data, lin)){
        istringstream iss(lin);
        int num;
        ++trans_ids;
        while( (iss >> num ) ){
            ++m[num];
            if( m[num] == 1 )
                ele.push_back(num);
        }
    }

    float x = (float)(stoi(argv[2]))/100; // x support threshold
    minsup_ = ceil(trans_ids*x);

    data.close();

    vector<vector<int> > valid_candidates_, cur_candidates_;

    int distinct_ele_ = m.size();

    for(int i=0;i<ele.size();i++)
        if(m[ele[i]] >= minsup_){
            vector<int> tm = {ele[i]};
            valid_candidates_.push_back(tm);
        }

    cur_candidates_ = valid_candidates_;

    dump(valid_candidates_);
    t1 = std::chrono::high_resolution_clock::now();
    for(int i=1;i<distinct_ele_;i++){
        if(exceed_THRESHOLD()){
            dump(valid_candidates_);
            t1 = std::chrono::high_resolution_clock::now();
        }
        // assumption : cur_candidates_ is lexicographically sorted containing
        // valid item sets of size i
        vector<vector<int> > possible_candidates_, pruned_candidates_;
        Generate(cur_candidates_, possible_candidates_);
        if(i>1)
            Prune(cur_candidates_,possible_candidates_,pruned_candidates_);
        else 
            pruned_candidates_ = possible_candidates_;
        cur_candidates_.clear();
        ComputeSupport(pruned_candidates_, cur_candidates_, minsup_, file_);
        if ( cur_candidates_.empty() )
            break;
        // cerr << cur_candidates_.size() << " \n ";
        for(int i=0;i<cur_candidates_.size();i++)
            valid_candidates_.push_back(cur_candidates_[i]);
    }

    dump(valid_candidates_);

    return 0;
}
