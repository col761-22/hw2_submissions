g++ -std=c++17 -O3 FP_Tree.cpp -o fptree
g++ -std=c++17 -O3 Apriori.cpp -o apriori

