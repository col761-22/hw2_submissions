#include <bits/stdc++.h>
using namespace std;

#pragma GCC target("avx2")

struct node{
    int item_name, count;
    node* node_link;
    node* parent_link;
    vector<node*> child_links;
    map<int,int> child_index; // for fast retrival
    node(){
        item_name = -1;
        count = 0;
        node_link = NULL;
        parent_link = NULL;
    }
};

bool somp(int& a, int& b){
    return to_string(a) < to_string(b);
}

bool domp(vector<int>& a, vector<int>& b){
    string a_n = "";
    for(int i=0;i<a.size();i++){
        a_n += to_string(a[i]);
        if(i!=a.size()-1)
            a_n += ' ';
    }
    string b_n = "";
    for(int i=0;i<b.size();i++){
        b_n += to_string(b[i]);
        if(i!=b.size()-1)
            b_n += ' ';
    }

    int sz = min(a_n.size(),b_n.size());
    for(int i=0;i<sz;i++){
        if(a_n[i] < b_n[i])
            return  true;
        else if( a_n[i] > b_n[i])
            return false;
    }
    return a_n.size() < b_n.size();
}

bool comp( pair<int,int>& a, pair<int,int>& b){
    if(a.second == b.second)
        return a.first < b.first;
    return a.second > b.second;
}

std::chrono::high_resolution_clock::time_point t1;
bool exceed_THRESHOLD(){
    std::chrono::high_resolution_clock::time_point t2 = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> time_span = std::chrono::duration_cast<std::chrono::duration<double>>(t2 - t1);
    return (time_span.count() > 1600.0);
}
string outputfile_;
void dump(vector<vector<int> >& valid_candidates_){
    for(int i=0;i<valid_candidates_.size();i++)
        sort(valid_candidates_[i].begin(),valid_candidates_[i].end(),somp);

    sort(valid_candidates_.begin(),valid_candidates_.end(),domp);

    ofstream outdata;
    outdata.open(outputfile_);

    for(int  i=0;i<valid_candidates_.size();i++){
        for(int j=0;j<valid_candidates_[i].size();j++){
            outdata << valid_candidates_[i][j];
            if( j < valid_candidates_[i].size() - 1)
                outdata << " ";
        }
        outdata << "\n";
    }

    outdata.close();

}

void DeleteTree(node* root){
    for(int i=0;i<root->child_links.size();i++)
        DeleteTree(root->child_links[i]);
    delete root;   
}

bool SimplePath( node* root){
    node* cur = root;
    while(cur->child_links.size()){
        if(cur->child_links.size() > 1)
            return false;
        cur = cur->child_links[0];
    }
    return true;
}

vector<vector<int> > GenerateAllSubsets( vector<int> items){
    vector<vector<int> > subsets;
    for(int i=0;i<items.size();i++){
        int sz = subsets.size();
        for(int j=0;j<sz;j++){
            vector<int> tm = subsets[j];
            tm.push_back(items[i]);
            subsets.push_back(tm);
        }
        vector<int> tm = {items[i]};
        subsets.push_back(tm);
    }
    return subsets;
}

void TreeInsert(vector<pair<int,int> >& trans, node* root,unordered_map<int, node*>& header_table, unordered_map<int, node*>& previous_table){
    node *cur = root;
    int sz = trans.size();
    for(int i=0;i<sz;i++){
        if( cur->child_index.find(trans[i].first) != cur->child_index.end() ){
            cur = cur->child_links[cur->child_index[trans[i].first]];
            cur->count += trans[i].second;
        }else{
            node* new_node = new node;
            cur->child_index[trans[i].first] = cur->child_links.size();
            cur->child_links.push_back(new_node);
            new_node->item_name = trans[i].first;
            new_node->count = trans[i].second;
            new_node->parent_link = cur;
            if( header_table.find(trans[i].first) != header_table.end())
                previous_table[trans[i].first]->node_link = new_node;
            else
                header_table[trans[i].first] = new_node;
            previous_table[trans[i].first] = new_node;
            cur = new_node;
        }
    }
}

void GenerateConditionalDatabase(unordered_map<int, node*>& header_table, int item,vector<vector<pair<int,int> > >& conditional_patterns){
        node* cur = header_table[item];
        while(cur != NULL){
            vector<pair<int,int> > pattern;
            node* temp = cur->parent_link;
            int support = cur->count;
            while(temp->parent_link != NULL){
                pattern.emplace_back(temp->item_name,support);
                temp = temp->parent_link;
            }
            if( pattern.size() )
                conditional_patterns.push_back(pattern);
            cur = cur->node_link;
        }
}

void FPGrowth(node* root, vector<int> alpha, unordered_map<int, node*>& header_table, vector<vector<int> >& valid_candidates_, vector<int>& elements, int minsup_){
    if(exceed_THRESHOLD()){
        dump(valid_candidates_);
        t1 = std::chrono::high_resolution_clock::now();
    }
    if(SimplePath(root)){
        vector<int> items;
        node* cur = root;
        while(cur->child_links.size()){
            cur = cur->child_links[0];
            items.push_back(cur->item_name);
        }
        vector<vector<int> > subsets = GenerateAllSubsets(items);
        for(int i=0;i<subsets.size();i++){
            vector<int> tm = alpha;
            for(int j=0;j<subsets[i].size();j++)
                tm.push_back(subsets[i][j]);
            valid_candidates_.push_back(tm);
        }
        valid_candidates_.push_back(alpha);
        return;
    }

    for(int i=0;i<elements.size();i++){
        // Generate conditional database of alpha union elements[i]
        vector<vector<pair<int,int> >> conditional_patterns;
        GenerateConditionalDatabase(header_table, elements[i],conditional_patterns);

        unordered_map<int,int> conditional_frequency;
        for(int i=0;i<conditional_patterns.size();i++)
            for(int j=0;j<conditional_patterns[i].size();j++)
                    conditional_frequency[conditional_patterns[i][j].first] += conditional_patterns[i][j].second;

        node* conditional_root = new node;
        unordered_map<int, node*> conditional_header_table, conditional_previous_table;
        
        set<int> dist_elements;
        for(int i=0;i<conditional_patterns.size();i++){
            vector<pair<int,int> > transaction;
            int sup = conditional_patterns[i][0].second;
            for(int j=0;j<conditional_patterns[i].size();j++){
                if(conditional_frequency[conditional_patterns[i][j].first] >= minsup_ ){
                    transaction.emplace_back(conditional_patterns[i][j].first,conditional_frequency[conditional_patterns[i][j].first]);
                    dist_elements.insert(conditional_patterns[i][j].first);
                }
            }
            sort(transaction.begin(),transaction.end(),comp);
            for(int j=0;j<transaction.size();j++)
                transaction[j].second = sup;
            TreeInsert(transaction,conditional_root,conditional_header_table,conditional_previous_table);
        }

        vector<int> conditional_elements;
        for(auto it:dist_elements)
            conditional_elements.push_back(it);
        
        vector<int> B = alpha;
        B.push_back(elements[i]);
        FPGrowth(conditional_root,B,conditional_header_table,valid_candidates_,conditional_elements,minsup_);
        DeleteTree(conditional_root);
    }
    if(alpha.size())
        valid_candidates_.push_back(alpha);
}

int main(int argc, char *argv[]){

    assert(argc == 4);

    t1 = std::chrono::high_resolution_clock::now();
    string file_ = argv[1]; // dataset path
    outputfile_ = argv[3]; // outputfilepath

    int minsup_ = 0;
    int trans_ids = 0;
    
    // open the file for statistics
    ifstream data;
    data.open(file_);
    if ( !data ){
        cerr << " File didn't open\n";
        return 0;
    }
    

    //read the file to get all the distinct elements 
    vector<int> ele;
    unordered_map<int, int> um;
    string lin;
    while(getline(data, lin)){
        istringstream iss(lin);
        int num;
        ++trans_ids;
        while( (iss >> num ) ){
            ++um[num];
            if(um[num] == 1)
                ele.push_back(num);
        }
        // if(trans_ids%10000==0)
            // cerr << trans_ids << " ";
    }
    // cerr << "\n";
    float x = (float)(stoi(argv[2]))/100; // x support threshold
    minsup_ = ceil(trans_ids*x);

    data.close();

    // cerr << "data reading done \n";

    // open the file for FP Tree construction
    data.open(file_);
    if ( !data ){
        cerr << " File didn't open\n";
        return 0;
    }

    unordered_map<int, node*> header_table, previous_table;
    node* root = new node;

    // construct FP Tree
    int read_lines = 0;
    while(getline(data, lin)){
        istringstream iss(lin);
        int num;
        vector<pair<int,int>> transaction;
        ++read_lines;
        while( (iss >> num ) )
            if( um[num] >= minsup_ )
                transaction.emplace_back(num,um[num]);
        sort(transaction.begin(),transaction.end(),comp);
        for(int i=0;i<transaction.size();i++)
            transaction[i].second = 1;
        TreeInsert(transaction,root,header_table,previous_table);
    }

    vector<int> distinct_elements;

    for(int i=0;i<ele.size();i++)
        if(um[ele[i]] >= minsup_)
            distinct_elements.push_back(ele[i]);

    // cerr << "FP Tree constructed\n";

    vector<vector<int> > valid_candidates_;
    vector<int> alpha;
    // FP Growth Mining
    FPGrowth(root,alpha,header_table,valid_candidates_,distinct_elements,minsup_);

    // cerr << "FP Mining done\n";
    dump(valid_candidates_);

    return 0;
}   
