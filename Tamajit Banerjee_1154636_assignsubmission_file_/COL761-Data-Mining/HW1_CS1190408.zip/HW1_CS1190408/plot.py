import matplotlib.pyplot  as plt
import numpy as np
import sys

plot_save_path =   sys.argv[1]


def pretty_print(dict_print, title):
	print(title)
	for k in dict_print.keys():
		print ("    Threshold {:3d}% : {:.2f}".format(k, dict_print[k]))

used_thresholds = [5, 10, 25, 50, 90]
algorithms = ["apriori", "fptree"]


timings = {alg: {t: 3600 for t in used_thresholds} for alg in algorithms}

for alg in algorithms:
	with open("times_{}.txt".format(alg)) as f:
		data = f.readlines()

	data = [d for d in data if "=" not in d]


	current_threshold = None
	for d in data:
		d = d.replace("\n", "")
		if "Running" in d:
			current_threshold = d.split(" ")[-1]
			current_threshold =  current_threshold[:-1]
			current_threshold = int(current_threshold)
		if "user" in d:
			time = d.split("\t")[-1]
			minutes, secs = time.split("m")
			secs = secs[:-1]

			total_time = int(minutes)*60 + float(secs)
			timings[alg][current_threshold] = total_time

for alg in algorithms:
	pretty_print(timings[alg], "timings for {}".format(alg))



xs = used_thresholds
ys = {alg: [timings[alg][th] for th in used_thresholds] for alg in algorithms}




# line plot

fig = plt.subplots(figsize=(12, 6))
for i, alg in enumerate(algorithms):
	plt.plot(xs, ys[alg], label =alg)
	plt.scatter(xs, ys[alg], s=10)


plt.xticks(xs)
plt.gca().invert_xaxis()
plt.legend()
plt.xlabel("Support Threshold (in %)")
plt.ylabel("Time (in sec)")
plt.title("Comparision of Apriori and FPTree algorithms")

plt.savefig(plot_save_path, dpi=300)

plt.close()