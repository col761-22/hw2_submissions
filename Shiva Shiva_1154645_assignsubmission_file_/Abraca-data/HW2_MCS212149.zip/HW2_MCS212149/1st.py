import time
import os
from matplotlib import pyplot as plt
import sys

fsg_script = "sh run_fsg.sh"
gspan_script = "sh run_gspan.sh"
gaston_script = "sh run_gaston.sh"
output_file = sys.argv[1]
supports = [95.0,50.0,25.0,10.0,5.0]

fsg = []
gSpan = []
gaston = []
file1 = open('count_graph.txt' , 'r')
s1=file1.readline()
total=int(s1)
for support in supports:
		# fsg......
		start = time.time()
		os.system(fsg_script+" fsg"+" "+str(support))
		end = time.time()
		fsg.append(end - start)
		# gspan......
		start = time.time()
		os.system(gspan_script+" gSpan-64"+" "+str(support/100))
		end = time.time()
		gSpan.append(end - start)
		# gaston.....
		start = time.time()
		os.system(gaston_script+" gaston"+" "+str((support*total)/100))
		end = time.time()
		gaston.append(end - start)
plt.figure()
plt.plot(supports, fsg, label='fsg')
plt.plot(supports, gSpan, label='gSpan')
plt.plot(supports, gaston, label='gaston')
plt.title('Running time Comparasion')
plt.xlabel('Support threshold')
plt.ylabel('Running Times(s)')
plt.legend()
plt.savefig(output_file+".png")
    
