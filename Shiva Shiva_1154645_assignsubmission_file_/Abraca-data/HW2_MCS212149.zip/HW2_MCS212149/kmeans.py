import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
input_file=sys.argv[1]
dimension=sys.argv[2]
plot_name=sys.argv[3]
d=str(dimension)
li2 = []
file=open(input_file, 'r')
while True:
    s1=file.readline()
    if not s1:
        break
    li = s1.split()
    li2.append(li)
# print(li2)
res=[]
for  i in range(1,16):
    ks=KMeans(n_clusters=i)
    ks.fit_predict(li2)
    res.append(ks.inertia_)
    
plt.figure()
plt.plot(range(1,16),res, label="kmeans")

plt.title('Elbow plot')
plt.xlabel('k-clusters')
plt.ylabel('sum of squared errors')
plt.legend()
plt.savefig(plot_name)
