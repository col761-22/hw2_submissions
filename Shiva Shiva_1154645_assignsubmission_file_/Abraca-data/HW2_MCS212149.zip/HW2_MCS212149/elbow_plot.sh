#! /bin/bash
inputfile=$1
dimension=$2
plot_name=$3
python3 kmeans.py $1 $2 $3