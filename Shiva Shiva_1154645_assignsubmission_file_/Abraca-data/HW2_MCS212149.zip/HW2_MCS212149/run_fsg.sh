#! /bin/bash
support=$2
algo=$1
./$algo -s $support fsg.dat