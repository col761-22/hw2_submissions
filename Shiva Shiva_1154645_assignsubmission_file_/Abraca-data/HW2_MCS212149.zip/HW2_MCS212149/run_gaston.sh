#! /bin/bash
support=$2
algo=$1
./$algo $support gaston.dat