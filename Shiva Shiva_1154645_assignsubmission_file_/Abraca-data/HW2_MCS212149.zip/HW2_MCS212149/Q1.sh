#! /bin/bash
inputfile=$1
plot_name=$2
chmod +x fsg
chmod +x gSpan-64
chmod +x gaston
python3 read_data.py $1 fsg.dat
python3 read_data.py $1 gspan.dat
python3 read_data.py $1 gaston.dat
chmod +x run_fsg.sh
chmod +x run_gspan.sh
chmod +x run_gaston.sh

python3 1st.py $2