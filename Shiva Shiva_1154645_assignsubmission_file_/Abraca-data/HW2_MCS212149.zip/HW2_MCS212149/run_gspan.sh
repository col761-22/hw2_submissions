#! /bin/bash
support=$2
algo=$1
./$algo -f gspan.dat -s $support