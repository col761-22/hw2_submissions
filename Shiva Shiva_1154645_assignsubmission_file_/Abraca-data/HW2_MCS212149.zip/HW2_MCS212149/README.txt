COL761(DATA MINING) ASSIGNMENT-2


--team members--
Nutan Singh - 2021MCS2143
Shiva - 2021MCS2149
Shivankar Garg - 2021MCS2151


--we need to load these libraries for hpc--

module load compiler/gcc/7.1.0/compilervars
module load pythonpackages/3.6.0/matplotlib/3.0.2/gnu
module load pythonpackages/3.6.0/scipy/1.1.0/gnu
module load compiler/intel/2019u5/intelpython3


--files zipped--
Q1 contains-
	fsg, gspan, gaston binary files.
	read_data.py - this file is used to generate frequent subgraphs by using fsg, gspan and gaston binary files.
	count_graph.txt - to store total number of graphs in the dataset.

    run_fsg.sh - to calculate the running time for fsg using fsg.dat file generated from read_data.py.
    run_gspan.sh - to calculate the running time for fsg using gspan.dat file generated from read_data.py.
    run_gaston.sh - to calculate the running time for fsg using gaston.dat file generated from read_data.py.
    
    
    
to execute- 
	chmod +x Q1.sh
	./Q1.sh <dataset> <plot_name>

Q3 contains-
	kmeans.py to determine the optimum value of k in k-means clustering on the dataset having 2,3,4 dimensions
	elbow_plot.sh file to run kmeans.py

to execute-
	chmod +x elbow_plot.sh
	./elbow_plot.sh <dataset> <dimension> q3_ <dimension>_ MCS212149.png




MCS212149_install.sh -  to extract our assignment from github repository to run on hpc
