import sys
file=sys.argv[2]
output_file = open(file, 'w')
temp=''
if file=='fsg.dat':
	temp="u "
else:
	temp="e "
input_file = sys.argv[1]
file1 = open(input_file , 'r')
id=0
while True:
	s1=file1.readline()
	if not s1:
		break
	if s1[0]=='#':
		t1="t # " + str(id)+ "\n"
		id=id+1
		output_file.write(t1)
		# output_file.writeline('\n')
		s2=file1.readline()
		v=int(s2)
		i=0
		while i<v:
			s3=file1.readline()
			p=s3[0]
			t2="v "+str(i)+" "+str(ord(p)) + "\n"
			output_file.write(t2)
			i=i+1
		s4=file1.readline()
		e=int(s4)
		j=0
		while j<e:
			s5=file1.readline()
			t3=temp+s5
			output_file.write(t3)
			j=j+1
	# id=id+1
temp1=open('count_graph.txt','w')
temp1.write(str(id))
