from collections import defaultdict
import os
import sys
import time


class Graph1:
    def __init__(self) -> None:
        self.graph_id = ""
        self.nodes = []
        self.edges = []


def convert(dataset_path, output_path, graph_id_path):
    all_nodes = set()
    graphs = []
    with open(dataset_path) as f:
        while True:
            graph = Graph1()
            graph.graph_id = f.readline().strip()
            if graph.graph_id == "":
                break
            num_nodes = int(f.readline().strip())
            for _ in range(num_nodes):
                node = f.readline().strip()
                all_nodes.add(node)
                graph.nodes.append(node)
            num_edges = int(f.readline().strip())
            for _ in range(num_edges):
                graph.edges.append(tuple(map(int, f.readline().strip().split())))
            f.readline()
            graphs.append(graph)

    node2idx = {node: idx for idx, node in enumerate(all_nodes)}

    with open(output_path, "w") as f1, open(graph_id_path, "w") as f2:
        for graph_num, graph in enumerate(graphs):
            f2.write(f"{graph.graph_id}\n")
            f1.write(f"t # {graph_num}\n")
            for idx, node in enumerate(graph.nodes):
                f1.write(f"v {idx} {node2idx[node]}\n")
            for src, dest, label in graph.edges:
                f1.write(f"e {src} {dest} {label}\n")

    with open("q2/node2idx.txt", "w") as f:
        for (node, idx) in node2idx.items():
            f.write(f"{node} {idx}\n")

    return len(graphs)


class Graph:
    def __init__(self):
        self.nodes = []
        self.edges = defaultdict(lambda: [])


def convert_input(infilename, outfilename):
    with open(infilename) as infile, open(outfilename, "w") as outfile:
        reading = True
        infile.readline()
        while reading:
            graph = Graph()
            while True:
                line = infile.readline().strip()
                if line == "":
                    reading = False
                    break
                if line.startswith("t"):
                    break
                if line.startswith("v"):
                    graph.nodes.append(line.split()[-1])
                    continue
                if line.startswith("e"):
                    src, dest, label = map(int, line.split()[1:])
                    graph.edges[src].append((dest, label))
                    continue
            outfile.write(f"{len(graph.nodes)}\n")
            for idx, node_label in enumerate(graph.nodes):
                outfile.write(f"{idx} {node_label}\n")
            for src in range(len(graph.nodes)):
                outfile.write(f"{len(graph.edges[src])}\n")
                for dest, label in graph.edges[src]:
                    outfile.write(f"{src} {dest} {label}\n")


def convert_output(infilename, outfilename, indexfilename, NUM_GRAPHS):
    with open(infilename) as infile, open(outfilename, "w") as outfile, open(indexfilename, "w") as indexfile:
        infile.readline()  # # Graph id
        reading = True

        a = {}
        i = 0

        while reading:
            infile.readline()
            graph = Graph()
            while True:
                line = infile.readline().strip()
                if line == "":  # t #
                    reading = False
                    break
                if line.startswith("v"):  # v idx label
                    node = line.split()[-1]
                    graph.nodes.append(line.split()[-1])
                    continue
                if line.startswith("e"):
                    src, dest, label = map(int, line.split()[1:])
                    graph.edges[src].append((dest, label))
                    continue
                if line.startswith("i"):
                    present = line.split()[1:]
                    # print(present)
                    for p in present:
                        p = int(p)
                        if p in a:
                            a[p].append(i)
                        else:
                            a[p] = [i]

                if line.startswith("# "):
                    break

            outfile.write(f"{len(graph.nodes)}\n")
            for idx, node_label in enumerate(graph.nodes):
                outfile.write(f"{idx} {node_label}\n")
            for src in range(len(graph.nodes)):
                outfile.write(f"{len(graph.edges[src])}\n")
                for dest, label in graph.edges[src]:
                    outfile.write(f"{src} {dest} {label}\n")
            i += 1
        subgraphs = i
        for i in range(NUM_GRAPHS):
            k = 0
            if i not in a:
                for j in range(subgraphs):
                    indexfile.write(f"0 ")
                indexfile.write(f"\n")
            else:
                for j in range(subgraphs):
                    if(k >= len(a[i])):
                        indexfile.write(f"0 ")
                    elif(a[i][k] == j):
                        indexfile.write(f"1 ")
                        k+=1
                    else:
                        indexfile.write(f"0 ")
                indexfile.write(f"\n")


def main():
    CONVERTED_DATABASE_PATH = "q2/converted_database.txt"
    VF3_DATABASE_PATH = "q2/vf3_database.txt"
    PATTERNS_PATH = "q2/patterns.txt"
    CONVERTED_PATTERNS_PATH = "q2/converted_patterns.txt"
    INDICES_PATH = "q2/indices.txt"
    IDX2GRAPH_ID_PATH = "q2/idx2graph_id.txt"
    SUPPORT = 0.5
    NUM_GRAPHS = convert(sys.argv[1], CONVERTED_DATABASE_PATH, IDX2GRAPH_ID_PATH)

    os.system(f"./q2/gaston {SUPPORT * NUM_GRAPHS} {CONVERTED_DATABASE_PATH} {PATTERNS_PATH}") # >/dev/null 2>/dev/null")

    start = time.time()
    convert_input(CONVERTED_DATABASE_PATH, VF3_DATABASE_PATH)
    end = time.time()
    print(end - start)

    start = time.time()
    convert_output(PATTERNS_PATH, CONVERTED_PATTERNS_PATH, INDICES_PATH, NUM_GRAPHS)
    end = time.time()
    print(end - start)


if __name__ == "__main__":
    main()
