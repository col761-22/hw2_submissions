import os
import time
from collections import defaultdict


class Graph:
    def __init__(self):
        self.nodes = []
        self.edges = defaultdict(lambda: [])


def convert(dataset_path, output_path):
    node2idx = {}
    with open("q2/node2idx.txt") as f:
        while True:
            line = f.readline()
            if line == "":
                break
            node, idx = line.strip().split()
            node2idx[node] = idx
    graph_num = 0
    with open(dataset_path) as f, open(f"{output_path}", "w") as f1:
        while True:
            graph = Graph()
            graph_id = f.readline().strip()
            if graph_id == "":
                break
            num_nodes = int(f.readline().strip())
            for _ in range(num_nodes):
                node = f.readline().strip()
                graph.nodes.append(node)
            num_edges = int(f.readline().strip())
            for _ in range(num_edges):
                src, dest, label = map(int, f.readline().strip().split())
                graph.edges[src].append((dest, label))
            f.readline()

            f1.write(f"{len(graph.nodes)}\n")
            for idx, node_label in enumerate(graph.nodes):
                f1.write(f"{idx} {node2idx[node_label]}\n")
            for src in range(len(graph.nodes)):
                f1.write(f"{len(graph.edges[src])}\n")
                for dest, label in graph.edges[src]:
                    f1.write(f"{src} {dest} {label}\n")

            graph_num += 1
    return graph_num


def filter_input(input_filename, output_filename, filtered_indices):
    i, j = 0, 0
    with open(input_filename) as f1, open(output_filename, "w") as f2:
        reading = True
        f1.readline()
        while reading:
            graph = Graph()
            while True:
                line = f1.readline().strip()
                if line == "":
                    reading = False
                    break
                if line.startswith("t"):
                    break
                if line.startswith("v"):
                    graph.nodes.append(line.split()[-1])
                    continue
                if line.startswith("e"):
                    src, dest, label = map(int, line.split()[1:])
                    graph.edges[src].append((dest, label))
                    continue
            if i < len(filtered_indices) and filtered_indices[i] == j:
                i += 1
                f2.write(f"{len(graph.nodes)}\n")
                for idx, node_label in enumerate(graph.nodes):
                    f2.write(f"{idx} {node_label}\n")
                for src in range(len(graph.nodes)):
                    f2.write(f"{len(graph.edges[src])}\n")
                    for dest, label in graph.edges[src]:
                        f2.write(f"{src} {dest} {label}\n")
            j += 1


def main():
    DATABASE_INDICES_PATH = "q2/indices.txt"
    QUERY_INDICES_PATH = "indices2.txt"
    CONVERTED_PATTERNS_PATH = "q2/converted_patterns.txt"
    IDX2GRAPH_ID_PATH = "q2/idx2graph_id.txt"
    DATABASE_PATH = "q2/converted_database.txt"
    FILTERED_DATABASE_PATH = "q2/filtered_database.txt"
    TO_CHECK_FILE_FOR_VF3 = "q2/to_check_file.txt"
    ANSWERS = "output_CS1190365.txt"
    VF3_DATABASE_PATH = "q2/vf3_database.txt"
    

    # Load the index
    # Load 0s and 1s
    with open(DATABASE_INDICES_PATH) as f:
        indices = [list(map(int, x.split())) for x in f.read().split("\n") if x]

    # Load index to graph id mapping
    with open(IDX2GRAPH_ID_PATH) as f:
        idx2graph_id = f.read().split("\n")
    if idx2graph_id[-1] == "":
        idx2graph_id.pop()

    while True:
        # Ask for the query file
        query_path = input("Enter path to query file: ")
        start = time.time()
        CONVERTED_QUERY_DIR = "q2/converted_query"
        QUERY_DIR_PATH = "q2/converted_query/all.txt"
        os.makedirs(CONVERTED_QUERY_DIR, exist_ok=True)

        # Build index for query file
        n = convert(query_path, QUERY_DIR_PATH)

        
        all_filtered = []
        
        command = f"./q2/vf3l -u {CONVERTED_PATTERNS_PATH} {QUERY_DIR_PATH}"
        os.system(command)

        with open(QUERY_INDICES_PATH) as f:
            query_indices = [list(map(int, x.split())) for x in f.read().split("\n") if x]

        for t in range(n):
            start = time.time()
            # Filter original database
            
            query_index = query_indices[t]

            filtered_indices = []
            for i, index in enumerate(indices):
                if not any(qi > 0 and index[j] == 0 for j, qi in enumerate(query_index)):
                    filtered_indices.append(1)
                else:
                    filtered_indices.append(0)
            all_filtered.append(filtered_indices)

            # start1 = time.time()
            # filter_input(DATABASE_PATH, FILTERED_DATABASE_PATH, filtered_indices)
            # end1 = time.time()
            # print(end1 - start1)

            # start1 = time.time()
            # command = f"./q2/vf3 -u {CONVERTED_QUERY_DIR}/{t} {FILTERED_DATABASE_PATH}"
            # os.system(command)
            # end1 = time.time()
            # print(end1 - start1)

                    ## This code(below) also need to be shifted outside this while loop

            # with open(QUERY_INDICES_PATH) as f:
            #     isomorphic_indices = [int(x) for x in f.read().split("\n") if x]
            # graph_ids = [idx2graph_id[filtered_indices[i]] for i, val in enumerate(isomorphic_indices) if val > 0]
            # f2.write("\t".join(graph_ids))
            # f2.write("\n")
            # print(graph_ids)
            # end = time.time()
            # print(end - start)
            
        f_to_check = open(TO_CHECK_FILE_FOR_VF3,"w")
        for a in all_filtered:
            for b in a:
                f_to_check.write(str(b)+" ")
            f_to_check.write("\n")

        command = f"./q2/vf3 -u {QUERY_DIR_PATH} {VF3_DATABASE_PATH} {TO_CHECK_FILE_FOR_VF3}"
        os.system(command)

        with open(ANSWERS, "w") as f2, open(QUERY_INDICES_PATH) as f:
            answers = [[] for _ in range(n)]
            isomorphic_indices = [list(map(int, x.split())) for x in f.read().split("\n") if x]
            for i, isomorphic_idex in enumerate(isomorphic_indices):
                for j, index in enumerate(isomorphic_idex):
                    if index > 0:
                        answers[j].append(idx2graph_id[i])
            for graph_ids in answers:
                f2.write("\t".join(graph_ids))
                f2.write("\n")
        end = time.time()
        print(f"Time in ms: {(end - start) * 1000}")


if __name__ == "__main__":
    main()
