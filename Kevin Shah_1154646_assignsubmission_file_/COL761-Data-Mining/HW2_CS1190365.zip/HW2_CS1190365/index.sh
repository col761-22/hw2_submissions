module load apps/anaconda/3
module load compiler/gcc/9.1.0
chmod +x q2/gaston
chmod +x q2/vf3
chmod +x q2/vf3l

python3 q2_index.py $1
