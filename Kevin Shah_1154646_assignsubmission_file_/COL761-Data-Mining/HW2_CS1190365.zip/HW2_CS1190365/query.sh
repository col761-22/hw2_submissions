module load apps/anaconda/3
module load compiler/gcc/9.1.0

python3 q2_query.py
