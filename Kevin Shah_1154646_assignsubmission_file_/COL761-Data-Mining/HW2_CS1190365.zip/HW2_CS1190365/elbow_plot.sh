module purge
module load compiler/gcc/9.1.0
module load apps/anaconda/3

python3 q3.py $1 $2 $3
