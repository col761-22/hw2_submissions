#include <stdio.h>
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string>
#include <time.h>
#include <algorithm>
#ifndef WIN32
#include <csignal>
#include <unistd.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <errno.h>
#else
#include <Windows.h>
#include <stdint.h>
#endif

#include "WindowsTime.h"
#include "VFLib.h"
#include "Options.hpp"

#include <chrono>
using namespace std::chrono;

using namespace vflib;

#ifndef WIN32
void sig_handler(int sig) {
    switch (sig) {
		case SIGKILL:
			std::cout << "Killed \n";
			exit(-1);
		case SIGABRT:
			std::cout << "Aborted \n";
			exit(-1);
		case SIGTERM:
			std::cout << "Terminated \n";
			exit(-1);
		case SIGSEGV:
			std::cout << "Segmentation fault \n";
			exit(-1);
		case SIGSTOP:
			std::cout << "Stopped \n";
			exit(-1);
		case SIGCHLD:
			std::cout << "Child stopped or terminated \n";
			exit(-1);
		default:
			std::cout << "Unexpected signal " <<  sig <<"\n";
			exit(-1);
		}
}
#endif

template <typename Node, typename Edge>
class Loader: public ARGLoader<Node, Edge> {
    public:
        /**
         * @brief Reads the graph data from a text istream
         * @param in The input stream
         * @param undirected If true, the graph is undirected
         */
        Loader(std::istream &in, bool undirected=false);
        virtual uint32_t NodeCount() const;
        virtual Node GetNodeAttr(nodeID_t node);
        virtual uint32_t OutEdgeCount(nodeID_t node) const;
        virtual nodeID_t GetOutEdge(nodeID_t node, uint32_t i, Edge *pattr);

    private:
        uint32_t node_count;
        std::vector<Node> nodes;
        std::vector< std::map<nodeID_t, Edge> > edges;
        typename std::map<nodeID_t, Edge>::iterator edge_iterator;
        nodeID_t last_edge_node;
        uint32_t last_edge_index;
};

template <typename Node, typename Edge>
Loader<Node,Edge>
::Loader(std::istream &in, bool undirected) {
    last_edge_node = NULL_NODE;

    if (!in.good())
      error("End of file or reading error");

    in >> node_count;
    nodes.resize(node_count);
    edges.resize(node_count);
    uint32_t edge_count;
    nodeID_t i, j, n1, n2;
    for(i=0; i<node_count; i++) {
        in >> n1 >> nodes[i];
        if (n1 != i)
            error("Error in file format reading node", n1);
    }

    for(i=0; i<node_count; i++) {
        in >> edge_count;
        for(j=0; j<edge_count; j++) {
            in >> n1 >> n2;
            if (n1 != i || n2 >= node_count || n1==n2)
                error("Error in file format reading edge", n1, n2);
            in >> edges[n1][n2];
            if (undirected)
                edges[n2][n1] = edges[n1][n2];
        }
    }
}

template <typename Node, typename Edge>
uint32_t
Loader<Node,Edge>
::NodeCount() const {
    return node_count;
}

template <typename Node, typename Edge>
Node
Loader<Node,Edge>
::GetNodeAttr(nodeID_t node) {
    return nodes[node];
}

template <typename Node, typename Edge>
uint32_t
Loader<Node,Edge>
::OutEdgeCount(nodeID_t node) const {
    return edges[node].size();
}

template <typename Node, typename Edge>
nodeID_t
Loader<Node,Edge>
::GetOutEdge(nodeID_t node, uint32_t i, Edge *pattr) {
    assert (i<OutEdgeCount(node));

    if (node != last_edge_node) {
        last_edge_node = node;
        edge_iterator = edges[node].begin();
        last_edge_index = 0;
    }
    while (last_edge_index < i) {
        edge_iterator ++;
        last_edge_index ++;
    }

    while (last_edge_index > i) {
        edge_iterator --;
        last_edge_index --;
    }

    *pattr = edge_iterator->second;
    return edge_iterator->first;
}


int32_t main(int32_t argc, char** argv)
{
	Options opt;
	bool to_check_filter;

	if(argc == 5) 			//Hardcoded to only work with ./exec -u g1 g2 tocheck or ./exec -u g1 g2
	{
		to_check_filter = 1;
	}
	else if(argc == 4)
	{
		to_check_filter = 0;
	}
	else {
		std::cout << "Hardcoded to only work with ./exec -u g1 g2 tocheck or ./exec -u g1 g2" ;
		exit(0);
	}

#ifndef WIN32
	std::signal(SIGKILL, sig_handler);
	std::signal(SIGABRT, sig_handler);
	std::signal(SIGTERM, sig_handler);
	std::signal(SIGSEGV, sig_handler);
	std::signal(SIGSTOP, sig_handler);
	std::signal(SIGCHLD, sig_handler);
#endif

	if(!GetOptions(opt, argc, argv))
	{
		exit(-1);
	}

	std::ifstream graphInPat(opt.pattern);
	std::ifstream graphInTarg(opt.target);

	std::vector<ARGLoader<data_t, Empty>*> database;
	std::vector<ARGLoader<data_t, Empty>*> patterns;

	auto start = high_resolution_clock::now();

	while (graphInPat.good()) {
		ARGLoader<data_t, Empty>* pattloader = new Loader<data_t, Empty>(graphInPat,opt.undirected);
		patterns.push_back(pattloader);
	}

	patterns.pop_back();

	while (graphInTarg.good()) {
		ARGLoader<data_t, Empty>* targloader = new Loader<data_t, Empty>(graphInTarg,opt.undirected);
		database.push_back(targloader);
	}

	database.pop_back();

	auto stop = high_resolution_clock::now();
	auto duration = duration_cast<microseconds>(stop - start);
	
	// To get the value of duration use the count()
	// member function on the duration object
	std::cout << "Time taken to load the files"<< duration.count() << std::endl;

	std::vector<std::vector<int>> indices(database.size(), std::vector<int>(patterns.size()));

	std::vector<std::vector<int>> to_check(database.size(), std::vector<int>(patterns.size(),1)); // TODO : Load this file..

	if(to_check_filter)
	{
		std::fstream f;
		f.open(argv[4],std::ios::in);
		for(int j=0;j<patterns.size();j++)
		{
			for(int i=0;i<database.size();i++)
			{
				f >> to_check[i][j];
			}
		}
	}

	int i = 0;
	for (auto *targloader: database) {
		int j = 0;
		for (auto *pattloader: patterns) {
			if(to_check_filter && to_check[i][j] == 1)
			{
				ARGraph<data_t, Empty> patt_graph(pattloader);
				ARGraph<data_t, Empty> targ_graph(targloader);
				uint32_t n1 = patt_graph.NodeCount();
				uint32_t n2 = targ_graph.NodeCount();
				if (n1 == 0 || n2 == 0) {
					std::cout << n1 << ' ' << n2 << '\n';
					std::cout << i << ' ' << j << '\n';
					exit(1);
				}
				std::vector<uint32_t> class_patt;
				std::vector<uint32_t> class_targ;
				uint32_t classes_count = 0;

				MatchingEngine<state_t >* me = CreateMatchingEngine(opt);

				if(!me)
				{
					exit(-1);
				}

				FastCheck<data_t, data_t, Empty, Empty > check(&patt_graph, &targ_graph);
				if(check.CheckSubgraphIsomorphism())
				{
					NodeClassifier<data_t, Empty> classifier(&targ_graph);
					NodeClassifier<data_t, Empty> classifier2(&patt_graph, classifier);
					class_patt = classifier2.GetClasses();
					class_targ = classifier.GetClasses();
					classes_count = classifier.CountClasses();
				}

				me->ResetSolutionCounter();

				if(check.CheckSubgraphIsomorphism())
				{
					VF3NodeSorter<data_t, Empty, SubIsoNodeProbability<data_t, Empty> > sorter(&targ_graph);
					std::vector<nodeID_t> sorted = sorter.SortNodes(&patt_graph);

					state_t s0(&patt_graph, &targ_graph, class_patt.data(), class_targ.data(), classes_count, sorted.data());
					me->FindAllMatchings(s0);
				}

				size_t sols = me->GetSolutionsCount();
				indices[i][j] = sols;
				delete me;
			}
			j++;
		}
		i++;
	}

	auto stop2 = high_resolution_clock::now();
	duration = duration_cast<microseconds>(stop2 - stop);
	
	// To get the value of duration use the count()
	// member function on the duration object
	std::cout << "Time taken by vf3 in microsec" << duration.count() << std::endl;

	std::ofstream out{"indices2.txt"};
	for (const auto& index: indices) {
		for (auto i: index) {
			out << i << ' ';
		}
		out << '\n';
	}

	return 0;
}
