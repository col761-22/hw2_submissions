import sys
import matplotlib.pyplot as plt
import numpy as np
from sklearn.cluster import KMeans

possibleKList = range(1,16)

def readDataset(dataset_name):
    text = open(dataset_name,'r')
    lines = text.readlines()

    data = []
    for line in lines:
        featureS = line.split()
        thisPoint = []
        for thisFeature in featureS:
            thisPoint.append(float(thisFeature))
        data.append(thisPoint)

    return np.array(data)


if __name__ == "__main__":

    if(len(sys.argv)!=4):
        print("Please enter <dataset> <dimension> <plot_name> as arguments")
        exit()
    
    dataset_name = str(sys.argv[1])
    dimension = int(sys.argv[2])
    plot_name = str(sys.argv[3])

    X = readDataset(dataset_name)

    wcs = []
    
    for this_k in possibleKList:
        kmeans = KMeans(n_clusters=this_k, init='k-means++', max_iter=250, n_init=10, random_state=0)
        kmeans.fit(X)
        wcs.append(kmeans.inertia_)
    
    plt.plot(possibleKList, wcs)
    plt.title('Elbow Method')
    plt.xlabel('Number of clusters')
    plt.ylabel('Within cluster sum of squares')
    plt.savefig(plot_name)
    

    
