# DATA MINING HW-2

## Team Details
* Team Name: Akagami
* GitHub Repo: https://github.com/Kevin-379/COL761-Data-Mining.git
* Kevin Shah, 2019CS10365
* Mohit Thakur, 2019CS10373
* Sidharth Agarwal, 2019CS50661


List of Files and usage:
	1. q1.py : code for question 1 
	2. elbow_plot.sh : It internally call q3.py to generate the elbow plots with pre-defined specifications.
	3. CS1190365.pdf : Report with graphs and observations for q1 and q3
	4. Gaston executable : modified from original code to output index structure lists
        5. vf3 & vf3l executable : modified from original to take multiple graphs and subgraphs and return index structures.
	6. index.sh : for running the q2_index.py
	7. query.sh : for running q2_query.py
	8. q3.py : code for question 3 to generate the elbow plot
	9. q3_<dim>_CS1190365.png : the graphs for the dataset generated on hoc using entry number
	10. q2_query.py: query processing for question 2
	11. q2_index.py : preprocessing for question 2
	12. q1_CS1190365.png : graph for question 1 from report.
	13. output_CS1190365.txt : graph ids corresponding to queries in question 2
	14. CS1190365_generated_dataset_<dim>D.dat : dataset generated for given dimension on hoc.

Instructions to execute:
    q1) python3 q1.py <path/to/dataset>
    q2) sh index.sh <path/to/dataset
        sh query.sh
    q3) sh elbow_plot.sh <dataset> <dimension> <output png>


Contributions:
    Kevin       (33%)
        Implemented Q1
        Modified vf3 to support multiple dataset graphs and multiple subgraphs and return index structure
        Implemented functions of q2.py to handle input and output formats for different APIs
    Mohit       (33%) 
        Modified vf3 to support edge labels.
        Modified Gaston to return list of all supergraphs of mined subgraph
        Implemented functions of q2.py to handle input and output formats for different APIs
    Sidharth    (33%)
        Implemented Q3
        Modified Gaston to return list of all supergraphs of mined subgraph