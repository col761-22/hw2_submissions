import os
import sys
import time
import matplotlib.pyplot as plt


class Graph1:
    def __init__(self) -> None:
        self.graph_id = ""
        self.nodes = []
        self.edges = []


def convert(dataset_path, output_path):
    all_nodes = set()
    graphs = []
    with open(dataset_path) as f:
        while True:
            graph = Graph1()
            graph.graph_id = f.readline().strip()
            if graph.graph_id == "":
                break
            num_nodes = int(f.readline().strip())
            for _ in range(num_nodes):
                node = f.readline().strip()
                all_nodes.add(node)
                graph.nodes.append(node)
            num_edges = int(f.readline().strip())
            for _ in range(num_edges):
                graph.edges.append(tuple(map(int, f.readline().strip().split())))
            f.readline()
            graphs.append(graph)

    node2idx = {node: idx for idx, node in enumerate(all_nodes)}

    with open(output_path, "w") as f1:
        for graph_num, graph in enumerate(graphs):
            f1.write(f"t # {graph_num}\n")
            for idx, node in enumerate(graph.nodes):
                f1.write(f"v {idx} {node2idx[node]}\n")
            for src, dest, label in graph.edges:
                f1.write(f"e {src} {dest} {label}\n")

    return len(graphs)


def main():
	times = {
		"gspan": [],
		"fsg": [],
		"gaston": [],
		"gaston-re": [],
	}
	DATABASE_PATH = "q1/converted_database.txt"
	convert(sys.argv[1], DATABASE_PATH)
	MIN_SUP = [.95, .5, .25, .1, .05]
	NUM_GRAPHS = 64110
	for min_sup in MIN_SUP:
		start = time.time()
		os.system(f"./q1/gSpan-64 -f {DATABASE_PATH} -s {min_sup} > /dev/null 2> /dev/null")
		end = time.time()
		times["gspan"].append(end - start)

		start = time.time()
		os.system(f"./q1/fsg {DATABASE_PATH} -s {min_sup * 100} > /dev/null 2> /dev/null")
		end = time.time()
		times["fsg"].append(end - start)

		start = time.time()
		os.system(f"./q1/gaston {int(min_sup * NUM_GRAPHS)} {DATABASE_PATH} > /dev/null 2> /dev/null")
		end = time.time()
		times["gaston"].append(end - start)

		start = time.time()
		os.system(f"./q1/gaston-re {int(min_sup * NUM_GRAPHS)} {DATABASE_PATH} > /dev/null 2> /dev/null")
		end = time.time()
		times["gaston-re"].append(end - start)

	for alg, time1 in times.items():
		plt.plot(MIN_SUP, time1, label=alg)

	plt.legend()
	plt.xlabel("% support")
	plt.ylabel("Time (in s)")
	plt.savefig("temp.png")


if __name__ == "__main__":
	main()
