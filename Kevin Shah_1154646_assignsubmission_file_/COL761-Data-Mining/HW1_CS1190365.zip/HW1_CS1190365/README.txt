# DATA MINING HW-1

## Team Details
* Team Name: Akagami
* GitHub Repo: https://github.com/Kevin-379/COL761-Data-Mining.git
* Kevin Shah, 2019CS10365
* Mohit Thakur, 2019CS10373
* Sidharth Agarwal, 2019CS50661

## Contributions :

### Mohit Thakur : 33%
* Basic function declarations and protocols of interations between objects for both algorithms
* wrote functions for initializing fptree and header table, mine_patters function of fptree
* Implemented hash function on vectors to store the count of itemsets in hashmap
### Kevin Shah : 34%
* Python implementation of both algorithms for validating our understanding of the algorithms
* set and reset function of fptree algorithm and init function of apriory tree algorithm 
### Sidharth Agarwal : 33%
* Wrote c++ implementation of generate candidates, prune candidates and update counts of all cadidates from dataset.
* Wrote all the involved scripts for plotting, setup, compile and execution.

## Files : 
* **fptree.cpp** contains c++ implementation of fptree algorithm
* **apriory.cpp** contains c++ implementation of apriory algorithm
* **plot.py** contains code which plots time vs support threshold graph
* **compile.sh** Compiles the c++ code and creates executable which are then used by CS1190365.sh to run the algorithms
* **CS1190365.sh** Runs the algorithm and plots required graphs depending on flags and inputs

## Explanation of q4(q3): 
* We observe that runtime increases as we decrease the support threshold, this is because of the fact that there are more itemsets that are above support threshold and this leads to lesser possibility of pruning. Theoritically at support threshold of 0% all possible subsets of all items needs to be considered which will lead to checking of O(2^n) items.
* For low threshold values FPTree is faster than Apriori algorithm, this is observed because FPTree stores all the transactions details in a data structure and then uses this data structure in subsequent sections of algorithm while in case of Apriori algorithm it traverses the whole database after each iteration of algorithm.
* At high threshold values both algorithms have similar performances, FPTree needs to spend time and memory in builing tree and in Apriori algorithms' execution there will be lot of pruning.