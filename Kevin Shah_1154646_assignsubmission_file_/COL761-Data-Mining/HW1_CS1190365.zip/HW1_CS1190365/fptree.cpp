#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <unistd.h>
#include <csignal>

using Item = std::int64_t;
using Itemset = std::vector<Item>;

class FPTreeNode
{
  public:
    explicit FPTreeNode(Item item, FPTreeNode *parent = nullptr)
        : item(item)
        , parent(parent)
    {
    }

    Item item;
    std::uint64_t count = 1;
    FPTreeNode *parent;
    FPTreeNode *next = nullptr;
    std::vector<FPTreeNode *> children;
    std::vector<Item> conditional_items;
    std::vector<std::uint64_t> conditional_counts;
};

class FPTree
{
  public:
    FPTree(double support, const std::string &filename, const std::string &output_file_name)
        : support(support / 100)
        , filename(filename)
        , output_file_name(output_file_name)
    {
        root = new FPTreeNode(-1);
    }

    // Calls init pass to create list of items in order sorted by count..
    // Then in one pass over the database it creates fptree
    void initialize_tree();
    void mine_patterns();
    std::vector<Itemset> _mine_patterns(Item item, const std::unordered_map<Item, std::uint64_t> &counts);

    std::unordered_map<Item, std::uint64_t> set(FPTreeNode *node, const Item *item);
    void reset(FPTreeNode *node);

    // To sort the itemsets in orders of decreasing frequency, this will ensure lower branching factor..
    // But it has huge cost to pay, one pass through database.. We should also try without this pass
    // Sets num_transactions and items(items in sorted order)
    void init_pass();

    // INPUT : One transaction in sorted order
    // Updates root node and header table of this data structure, with items observed in this transaction.
    void add_transation_to_tree(const Itemset &transaction);
    void write_to_file();

  private:
    double support;
    std::uint64_t num_transactions = 0;
    FPTreeNode *root;
    std::string filename;
    std::string output_file_name;
    Itemset items; // Sorted in order of decreasing occurence in data base
    std::unordered_map<Item, std::uint64_t> item_count;
    std::unordered_map<Item, FPTreeNode *> header_table;
    std::vector<std::vector<std::string>> frequent_itemsets;
};

std::unordered_map<Item, std::uint64_t> FPTree::set(FPTreeNode *node, const Item *item)
{
    std::unordered_map<Item, std::uint64_t> counts;
    auto *cur_node_1 = node;
    while (cur_node_1 != nullptr)
    {
        if (item != nullptr && (cur_node_1->conditional_items.empty() || cur_node_1->conditional_items.back() != *item))
        {
            cur_node_1 = cur_node_1->next;
            continue;
        }
        auto *cur_node = cur_node_1;
        std::uint64_t cur = item == nullptr ? cur_node_1->count : cur_node_1->conditional_counts.back();
        while (cur_node != nullptr)
        {
            if (!cur_node->conditional_items.empty() && cur_node->conditional_items.back() == node->item)
            {
                counts[cur_node->item] += cur;
                cur_node->conditional_counts.back() += cur;
            }
            else
            {
                counts[cur_node->item] += cur;
                cur_node->conditional_items.push_back(node->item);
                cur_node->conditional_counts.push_back(cur);
            }
            cur_node = cur_node->parent;
        }
        cur_node_1 = cur_node_1->next;
    }
    counts.erase(node->item);
    return counts;
}

void FPTree::reset(FPTreeNode *node)
{
    auto *cur_node_1 = node;
    while (cur_node_1 != nullptr)
    {
        auto *cur_node = cur_node_1;
        while (cur_node != nullptr)
        {
            if (!cur_node->conditional_items.empty() && cur_node->conditional_items.back() == node->item)
            {
                cur_node->conditional_counts.pop_back();
                cur_node->conditional_items.pop_back();
            }
            cur_node = cur_node->parent;
        }
        cur_node_1 = cur_node_1->next;
    }
}

void FPTree::mine_patterns()
{
    for (const auto &[item, node] : header_table)
    {
        auto temp_count = set(node, nullptr);
        auto _frequent_itemsets = _mine_patterns(item, temp_count);
        for (auto &_frequent_itemset : _frequent_itemsets)
        {
            std::vector<std::string> frequent_itemset;
            frequent_itemset.reserve(_frequent_itemset.size());
            for (auto _item : _frequent_itemset)
            {
                frequent_itemset.push_back(std::to_string(_item));
            }
            std::sort(frequent_itemset.begin(), frequent_itemset.end());
            frequent_itemsets.push_back(frequent_itemset);
        }
        reset(node);
    }
}

std::vector<Itemset> FPTree::_mine_patterns(Item item, const std::unordered_map<Item, std::uint64_t> &counts)
{
    std::vector<Itemset> _frequent_itemsets = {{item}};
    for (auto &[_item, _node] : header_table)
    {
        if (counts.find(_item) == counts.end() || counts.at(_item) < support * num_transactions) { continue; }
        auto temp_count = set(_node, &item);
        auto _frequent_itemsets1 = _mine_patterns(_item, temp_count);
        for (auto _frequent_itemset : _frequent_itemsets1)
        {
            _frequent_itemset.push_back(item);
            _frequent_itemsets.push_back(_frequent_itemset);
        }
        reset(_node);
    }
    return _frequent_itemsets;
}

void FPTree::add_transation_to_tree(const Itemset &transaction)
{
    auto *cur = root;
    for (const auto &item : transaction)
    {
        bool new_child = true;
        for (auto *child : cur->children)
        {
            if (child->item == item)
            {
                child->count++;
                cur = child;
                new_child = false;
                break;
            }
        }
        if (!new_child) { continue; }
        auto *node = new FPTreeNode(item, cur);
        cur->children.push_back(node);
        node->next = header_table[item];
        header_table[item] = node;
        cur = node;
    }
}

void FPTree::initialize_tree()
{
    init_pass();
    std::ifstream in(filename); // Open file
    std::string line;
    while (std::getline(in, line) && !line.empty()) // Read line
    {
        std::stringstream ss(line); // Split transaction into items
        Item item{};
        std::vector<std::pair<std::uint64_t, Item>> temp_vec(0);
        while (ss >> item)
        {
            if (item_count[item] < support * num_transactions) { continue; }
            temp_vec.emplace_back(item_count[item], item);
        }
        sort(temp_vec.rbegin(), temp_vec.rend());

        std::vector<Item> transaction(0);
        for (const auto &a : temp_vec)
        {
            transaction.push_back(a.second);
        }
        add_transation_to_tree(transaction);
    }
}

void FPTree::init_pass()
{
    std::ifstream in(filename); // Open file
    std::string line;
    while (std::getline(in, line) && !line.empty()) // Read line
    {
        std::stringstream ss(line); // Split transaction into items
        Item item{};
        num_transactions += 1;
        while (ss >> item)
        {
            item_count[item]++; // Update item count
        }
    }
    std::vector<std::pair<std::uint64_t, Item>> temp_vec(0);
    for (const auto &[item, count] : item_count)
    {
        temp_vec.emplace_back(count, item);
    }
    sort(temp_vec.rbegin(), temp_vec.rend());
    for (const auto &a : temp_vec)
    {
        items.push_back(a.second);
    }
}

void FPTree::write_to_file() {
    std::ofstream out(output_file_name);
    std::vector<std::string> lines;
    std::sort(frequent_itemsets.begin(), frequent_itemsets.end());
    for (const auto &itemset : frequent_itemsets)
    {
        for (auto i = 0ULL; i < itemset.size() - 1; i++)
        {
            out << itemset[i] << ' ';
        }
        out << itemset.back() << '\n';
    }
}

FPTree *ptr = nullptr;

void handler(int signum) {
    if (ptr == nullptr) {
        return;
    }
    ptr->write_to_file();
    exit(1);
}

int main(int argc, char **argv)
{
    signal(SIGALRM, handler);
    alarm(3550);
    if (argc != 4) { std::cout << "Expected Input : ./exec dataset_name X output_file_name"; }
    FPTree fptree(std::stod(argv[2]), argv[1], argv[3]);
    ptr = &fptree;
    fptree.initialize_tree();
    fptree.mine_patterns();
    fptree.write_to_file();
}