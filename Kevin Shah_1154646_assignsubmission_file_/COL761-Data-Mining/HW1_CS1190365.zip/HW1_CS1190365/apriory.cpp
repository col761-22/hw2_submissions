#include <algorithm>
#include <boost/functional/hash.hpp>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>
#include <unistd.h>
#include <csignal>

const bool DEBUG = false;

template <typename Container> // we can make this generic for any container [1]
struct container_hash
{
    std::size_t operator()(Container const &c) const { return boost::hash_range(c.begin(), c.end()); }
};

class Apriori
{
    using Item = std::uint64_t;
    using Itemset = std::vector<Item>;

  public:
    Apriori(double support, const std::string &filename, const std::string &output_file_name)
        : support(support / 100)
        , filename(filename)
        , output_file_name(output_file_name)
    {
    }

    void run_algorithm()
    {
        auto candidates = init();

        if (DEBUG) { std::cout << "Init done!!\n"; }

        while (!candidates.empty())
        {
            candidates = generate_candidates(candidates);
            if (DEBUG) { std::cout << "generated candidates: " << candidates.size() << std::endl; }
            if (candidates.empty()) { break; }

            candidates = prune_after_join(candidates);
            if (DEBUG) { std::cout << "pruned candidates: " << candidates.size() << std::endl; }
            if (candidates.empty()) { break; }

            candidates = update_frequent_itemset_count(candidates);
            if (DEBUG) { std::cout << "updated candidates: " << candidates.size() << std::endl; }
        }
    }

    // It updates num_transactions, items, frequent_itemsets_count, frequent_itemset : Can call
    // update_frequent_itemset_count internally.
    std::vector<Itemset> init()
    {
        std::ifstream in(filename); // Open file
        std::string line;
        while (std::getline(in, line) && !line.empty()) // Read line
        {
            std::stringstream ss(line); // Split transaction into items
            Item item{};
            std::vector<Item> transVec;

            num_transactions += 1;
            while (ss >> item)
            {
                transVec.push_back(item);
            }
            std::sort(transVec.begin(), transVec.end());

            for (const auto &zdx : transVec)
            {
                frequent_itemsets_count[{zdx}]++;
            }
        }

        if (DEBUG) { std::cout << "Init func, freq_itemsets_size: " << frequent_itemsets_count.size() << std::endl; }

        std::vector<Itemset> candidates;
        // Filter candidates with frequency >= support
        for (const auto &[key, value] : frequent_itemsets_count)
        {
            if (value >= support * num_transactions)
            {
                std::vector<std::string> itemset;
                itemset.reserve(key.size());
                for (auto item : key)
                {
                    itemset.push_back(std::to_string(item));
                }
                std::sort(itemset.begin(), itemset.end());
                frequent_itemsets.push_back(itemset);
                candidates.push_back(key);
            }
        }
        std::sort(candidates.begin(), candidates.end());
        return candidates;
    }

    // Generates candidates by joining 2 possible candidates, creates new vector to store candidates of size k+1, and
    // return this vector.
    std::vector<Itemset> generate_candidates(const std::vector<Itemset> &fk)
    {
        std::vector<Itemset> ck;
        int n = fk.size();
        int k = fk[0].size();

        for (int idx = 0; idx < n; idx++)
        {
            bool same = true;
            for (int jdx = idx + 1; jdx < n; jdx++)
            {
                Itemset fi = fk[idx];
                Itemset fj = fk[jdx];
                for (int tdx = 0; tdx < k - 1; tdx++)
                {
                    if (fi[tdx] != fj[tdx])
                    {
                        same = false;
                        break;
                    }
                }
                if (!same) { break; }
                Itemset fi_copy = fi;
                fi_copy.push_back(fj.back());
                ck.push_back(fi_copy);
            }
        }
        return ck;
    }

    // Prune Itemsets which have any subset which is not frequent.
    std::vector<Itemset>
    prune_after_join(const std::vector<Itemset> &cand) // NOTE : Experiment without this function also
    {
        std::vector<Itemset> pruneCand;
        int n = cand.size();
        int k = cand[0].size();

        for (int idx = 0; idx < n; idx++) // for each candidate.
        {
            bool test = true;
            for (int jdx = 0; jdx < k; jdx++) // for each item in itemset..
            {
                Itemset subSet;
                for (int kdx = 0; kdx < k; kdx++)
                {
                    if (kdx != jdx) { subSet.push_back(cand[idx][kdx]); }
                }
                if (frequent_itemsets_count.find(subSet) != frequent_itemsets_count.end())
                {
                    if (frequent_itemsets_count[subSet] < support * num_transactions) { test = false; }
                }
                else
                {
                    test = false;
                }

                if (!test) { break; }
            }
            if (test) { pruneCand.push_back(cand[idx]); }
        }
        return pruneCand;
    }

    // One pass through a database to update count for all itemset in cadidates, store this count in
    // frequent_itemsets_count, then in one  iteration add elements to frequent_itemsets based on frequency observed
    std::vector<Itemset> update_frequent_itemset_count(const std::vector<Itemset> &cand)
    {
        std::vector<Itemset> newCand;
        auto n = cand.size();

        std::ifstream in(filename); // Open file
        std::string line;

        while (std::getline(in, line) && !line.empty()) // Read line
        {
            std::stringstream ss(line); // Split transaction into items
            Item item{};
            std::vector<Item> transVec;

            while (ss >> item)
            {
                transVec.push_back(item);
            }

            std::sort(transVec.begin(), transVec.end());

            for (auto idx = 0ULL; idx < n; idx++)
            {
                auto poin = 0ULL;
                for (const auto &jdx : transVec)
                {
                    if (poin == cand[idx].size()) { break; }
                    if (jdx == cand[idx][poin]) { poin++; }
                }
                if (poin == cand[idx].size()) { frequent_itemsets_count[cand[idx]]++; }
            }
        }

        for (auto idx = 0ULL; idx < n; idx++)
        {
            if (frequent_itemsets_count[cand[idx]] >= support * num_transactions)
            {
                std::vector<std::string> itemset;
                const auto &items = cand[idx];
                itemset.reserve(items.size());
                for (auto item : items)
                {
                    itemset.push_back(std::to_string(item));
                }
                std::sort(itemset.begin(), itemset.end());
                frequent_itemsets.push_back(itemset);
                newCand.push_back(cand[idx]);
            }
        }

        return newCand;
    }

    void outputToFile()
    {
        std::sort(frequent_itemsets.begin(), frequent_itemsets.end());
        std::ofstream out(output_file_name);
        for (auto it : frequent_itemsets)
        {
            for (auto idx = 0ULL; idx < it.size(); idx++)
            {
                out << it[idx];
                if (idx != it.size() - 1) { out << " "; }
            }
            out << std::endl;
        }
        out.close();
    }

  private:
    double support;
    double num_transactions = 0;
    Itemset items;
    std::unordered_map<Itemset, int, container_hash<Itemset>> frequent_itemsets_count;
    std::vector<std::vector<std::string>> frequent_itemsets;
    std::string filename;
    std::string output_file_name;
};

Apriori *ptr = nullptr;

void handler(int signum) {
    if (ptr == nullptr) {
        return;
    }
    ptr->outputToFile();
    exit(1);
}

int main(int argc, char **argv)
{
    signal(SIGALRM, handler);
    alarm(3550);
    if (argc != 4) { std::cout << "Expected Input : ./exec dataset_name X output_file_name"; }

    std::string dataset_name = argv[1];
    double support = std::stof(argv[2]);
    std::string output_file_name = argv[3];

    Apriori a(support, dataset_name, output_file_name);
    ptr = &a;
    a.run_algorithm();
    a.outputToFile();

    return 0;
}