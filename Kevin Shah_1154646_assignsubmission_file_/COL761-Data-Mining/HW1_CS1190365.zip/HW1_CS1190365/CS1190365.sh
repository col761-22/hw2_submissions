#!/usr/bin/bash
if [[ "$1" == "-apriori" ]]
then
	./apriory $2 $3 $4
elif [[ "$1" == "-fptree" ]]
then
	./fptree $2 $3 $4
elif [[ "$1" == "-plot" ]]
then
	python3 plot.py $2 $3
else
	echo "Error: Expected one of -apriori, -fptree, -plot"
fi
