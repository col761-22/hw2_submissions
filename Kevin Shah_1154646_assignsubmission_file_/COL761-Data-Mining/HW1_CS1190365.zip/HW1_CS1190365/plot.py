import sys
import time
import matplotlib.pyplot as plt
import signal
import subprocess


MAX_RUN_TIME = 3550

dataset_path = sys.argv[1]
image_path = sys.argv[2]
if not image_path.endswith(".png"):
    image_path += ".png"
apriori_times = []
fptree_times = []
SUPPORTS = [90, 50, 25, 10, 5]


def plot():
    # plt.scatter(SUPPORTS[:len(apriori_times)], apriori_times, label="apriori")
    # plt.scatter(SUPPORTS[:len(fptree_times)], fptree_times, label="fptree")
    plt.plot(SUPPORTS[: len(apriori_times)], apriori_times, label="apriori", marker="o")
    plt.plot(SUPPORTS[: len(fptree_times)], fptree_times, label="fptree", marker="x")
    plt.legend()
    plt.xlabel("Support %")
    plt.ylabel("Time (in seconds)")
    plt.savefig(image_path)


def handler(signum, frame):
    plot()
    sys.exit(1)


signal.signal(signal.SIGALRM, handler)
signal.alarm(MAX_RUN_TIME)


for support in SUPPORTS:
    start = time.time()
    subprocess.call(["./fptree", dataset_path, str(support), "/dev/null"])
    end = time.time()
    fptree_times.append(end - start)

    start = time.time()
    subprocess.call(["./apriory", dataset_path, str(support), "/dev/null"])
    end = time.time()
    apriori_times.append(end - start)
