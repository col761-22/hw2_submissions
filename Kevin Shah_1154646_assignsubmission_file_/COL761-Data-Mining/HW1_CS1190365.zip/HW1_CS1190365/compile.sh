#!/usr/bin/bash
g++ -O3 -Wall -std=c++1z -o fptree fptree.cpp
g++ -O3 -Wall -std=c++1z -o apriory apriory.cpp
