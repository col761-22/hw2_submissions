if [ $1 == "-apriori" ] 
then
python3 apriori.py $2 $3 $4
fi

if [ $1 == "-fptree" ] 
then
python3 fptree.py $2 $3 $4
fi

if [ $1 == "-plot" ] 
then
python3 draw.py $2 $3
fi