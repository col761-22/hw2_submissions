from sortedcontainers import SortedSet,SortedDict
import sys
fi=sys.argv[1]
op_fi=sys.argv[3]
minsup=int(sys.argv[2])
items=SortedDict()#all items
nonfrequent=[]#non frequent itemsets
trans=0
res=SortedDict()#resultant frequency
freq=[]
bivas=[]
def intersection(f1,f2):
    inter = [e1 for e1 in f1 for e2 in f2 if e1 == e2]
    if len(inter)==len(f1)-1:
        return True
    return False

def candidate_generate(freq):
    cand=[]
    for i in range(len(freq)-1):
        for j in range (i+1,len(freq)):
            f1=freq[i]
            f2=freq[j]
            if intersection(f1,f2):
                x=SortedSet()
                x.update(f1)
                x.update(f2)
                x=tuple(x)
                cand.append(x)
    return cand

def if_exist(tup,line):
    
    for i in tup:
        if i not in line:
            return False
    # print(tup,line)
    return True

def frequent_item_generation(candidates):
    freq=SortedDict()
    #nonfrequent=[]
    for cand in candidates:
        #print(cand,"canduiwjefhwj")
        #print(minsup)
        if findSubset(cand):
            c=0
            f=open(fi)
            while True:
                x=f.readline()
                # print(x)
                if not x:
                    break
                x=x.split(' ')
                x=[i.strip() for i in x]
                #print(cand,x,"KK")
                if if_exist(cand,x):
                    c+=1
            
            if c>=minsup_:
                # print(cand,c)
                #print(c)
                freq[cand]=c
            else:
                nonfrequent.append(cand)

    #print(nonfrequent)
    # print(freq)
    return freq

def findSubset(tup):
    #print(tup)
    n=len(tup)
    k=n-1
    ksub=list(range(k))
    Flag=0
    def generate(tup,n,k,index,i,ksub):
        if index>=k:
            if ksub in nonfrequent:
                Flag=1
            return False
        if i>=n:
            return 
        #print(index,i,n,k)
        ksub[index]=tup[i]
        generate(tup,n,k,index+1,i+1,ksub)
        generate(tup,n,k,index,i+1,ksub)
    generate(tup,n,k,0,0,ksub)
    if Flag==0:
        return True
    return False
    
if __name__=='__main__':
    first=SortedDict()
    f=open(fi)
    while True:
        x=f.readline()
        trans+=1
        if not x:
            trans-=1
            break
        x=x.split(' ')
        for i in x:
            i=i.strip()
            if i=='':
                continue
            if (i,) not in items:
                items[(i,)]=0
            items[(i,)]+=1
    minsup_=(trans*minsup)/100
    # print(minsup_)
    for i in items:
        if items[i]<minsup_:
            nonfrequent.append(i)
        else:
            first[i]=items[i]
            freq.append(i)
    # res.update(first)
    bivas+=first.keys()

    while True:
        # print(freq)
        x=candidate_generate(freq)
        y=frequent_item_generation(x)
        if not y:
            break
        freq=list(y.keys())
        bivas+=freq
        # res.update(y)
        # print
    bivas.sort()
    op_file=open(op_fi,'w')
    for i in bivas:
        op=''
        for j in i:
            op+=j+' '
        op+='\n'
        op_file.write(op)
        #print()
