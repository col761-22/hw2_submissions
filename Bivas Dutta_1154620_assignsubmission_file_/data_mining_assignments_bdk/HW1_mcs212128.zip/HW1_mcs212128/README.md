README
# HomeWork 1
# Team Members:                                    Contribution
1. Bivas Ranjan Dutta (2021MCS2128)          		~33%
2. Kriti Kaushal (2021MCS2135)                          ~33%
3. Battala DivyaTeja (2021MCS2126)                      ~33%

In this Assignment, we have implemented two algorithms
1. Apriori Algorithm
2. FP Tree Algorithm

# Apriori Algorithm
- We have generated the candidates one by one from the Transactions and prune them using the Apriori property. The remaining candidates are tested against the threshold value specified by the user.
- The drawback of this algorithm is that we have to traverse the transactions repeatedly.

# FP Tree Algorithm 
- We have built the FP Tree using the transaction entries and the frequency of each item.
- For generating the frequent itemset, we traverse the tree repeatedly.
- This algorithm is faster than Apriori Algorithm because we don't need to traverse the transactions repeatedly.

# Comparison (Answer for Q4)
- The plotted graph (plot.png) shows that the FP tree performs better than the Apriori Algorithm.
- As the threshold value decreases, the running time increases because, if the threshold decreases, we have to parse more candidates.
- As the threshold increases, the running time decreases as we have to deal with fewer candidates. 

# File Content
	1. install.sh
		- It loads all the required modules to run the code.
		- It clones the code from github and unzip the folder.
	2. apriori.py
		- It is the python implementation of the Apriori Algorithm.
		- It runs as follows:-
			- python3 apriori.py a x b
			- where a is the input test case, x is the support threshold (in %), and b is the output data file
	 3. fptree.py
		 - It is the python implementation of the FP-Tree Algorithm.
		 - It runs as follows:-
			- python3 fptree.py a x b
			- where a is the input test case, x is the support threshold (in %), and b is the output data file
	3. draw.py
		- It draws the comparision between FP-tree and  Apriori Algorithm.
		-  It runs as follows:-
			- python3 draw.py a b
			- a is the input dataset
			- b is the output file, i.e. it produces a b.png image, which shows the comparison.
	4. plot.png
		- It is a demo image file which shows the support threshold Vs. time graph.
	5. mcs212128.sh
		- ./mcs212128.sh -apriori a x b 
			- will run the apriori algorithm for input file a with a support threshold of x%
		-  ./mcs212128.sh -fptree a x b 
			- will run the fptree algorithm for input file a with a support threshold of x%
		-  ./mcs212128.sh -plot a b
			- will raw the graph named b.png which shows the comparision of FP-Tree Vs. Apriori Algorithm.

 