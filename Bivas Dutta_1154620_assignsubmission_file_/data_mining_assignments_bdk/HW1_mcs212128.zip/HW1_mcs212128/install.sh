#!/bin/bash
module load compiler/python/3.6.0/ucs4/gnu/447
module load pythonpackages/3.6.0/matplotlib/3.0.2/gnu
pip install matplotlib --user
pip install sortedcontainers --user
git clone https://github.com/battaladivyateja/data_mining_assignments_bdk.git
cd data_mining_assignments_bdk
unzip HW1_mcs212128.zip
cd HW1_mcs212128


