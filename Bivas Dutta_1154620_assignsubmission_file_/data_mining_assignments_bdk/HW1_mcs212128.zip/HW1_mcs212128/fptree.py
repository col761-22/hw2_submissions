from sortedcontainers import SortedSet,SortedDict
import sys
freq=[]

class Node:
    def __init__(self,val):
        self.val=val
        self.next=None

class Tree:
    def __init__(self,val):
        self.val=val
        self.child={}
        self.parent=None
        self.freq=1

def print_Tree(root):
    if root is None:
        return 
    for i in root.child:
        print(root.child[i].val,root.child[i].freq,root.child[i].parent.val)
        print_Tree(root.child[i])

def find_order(f,minsup):
    dic={}
    # global trans
    trans=0
    while True:
        x=f.readline()
        if not x:
            break
        trans+=1
        x=x.split()
        x=[i.strip() for i in x]
        for y in x:
            if y not in dic:
                dic[y]=1
            else:
                dic[y]+=1
    minsup_=minsup*trans/100
    dic=sorted(dic.items(),key=lambda i:i[1],reverse=True)
    res=[]
    for i,j in dic:
        if j>=minsup_:
            res.append(i)
    return [res,minsup_]

def tree_gen(f,minsup,flist):
    root=Tree(None)
    HeaderTable={}
    # global trans
    while True:
        x=f.readline()
        if not x:
            break
        x=x.split()
        x=[i.strip() for i in x]
        x=[e1 for e1 in x for e2 in flist if e1 == e2]
        x=sorted(x,key=flist.index)
        temp=root
        for y in x:
            if y in temp.child:
                temp.child[y].freq+=1

            else:
                temp.child[y]=Tree(y)
            if y not in HeaderTable:
                h_root=Node(None)
                tail=h_root
                HeaderTable[y]=[h_root,tail]
                HeaderTable[y][1].next=Node(temp.child[y])
                HeaderTable[y][1]=HeaderTable[y][1].next
            else:
                HeaderTable[y][1].next=Node(temp.child[y])
                HeaderTable[y][1]=HeaderTable[y][1].next

            temp.child[y].parent=temp
            temp=temp.child[y]
    # minsup=minsup*trans/100
    return [root,HeaderTable]

def gen_freq(con,item,minsup_):
    # print(item)
    res=sum([con[i] for i in con])
    # print(res)
    if res>=minsup_:
        x=item[:]
        freq.append(x)
        bc={}
        for i in con:
            j=i.parent
            while j.val:
                if j.val in bc:
                    if j not in bc[j.val]:
                        bc[j.val][j]=con[i]
                    else:
                        bc[j.val][j]+=con[i]
                else:
                    bc[j.val]={j:con[i]}
                j=j.parent
        for items in bc:
            item=[items]+item
            gen_freq(bc[items],item,minsup_)
            item=item[1:]

if __name__=='__main__':
    fi=sys.argv[1]
    op_fi=sys.argv[3]
    minsup=int(sys.argv[2])
    f=open(fi)
    dic,minsup_=find_order(f,minsup)
    # print(dic)
    f=open(fi)
    root,HeaderTable=tree_gen(f,minsup,dic)
    dic.reverse()
    for i in dic:
        s=HeaderTable[i][0].next
        cn={}
        while s:
            cn[s.val]=s.val.freq
            s=s.next
        gen_freq(cn,[i],minsup_)
    for i in range(len(freq)):
        freq[i].sort()
    freq.sort()
    # print(freq)
    op_file=open(op_fi,'w')
    for i in freq:
        op=''
        for j in i:
            op+=j+' '
        op+='\n'
        op_file.write(op)


