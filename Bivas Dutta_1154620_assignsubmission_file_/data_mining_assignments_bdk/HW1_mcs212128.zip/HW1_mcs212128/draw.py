import sys
import time
import subprocess
import matplotlib.pyplot as plt


thresholds = [5, 10, 25, 50, 90]  # x axis
data_file = sys.argv[1]
output_file_name = sys.argv[2]

apr = []
fpbias = []

for t in thresholds:
    start = time.time()
    subprocess.run(["python3", "apriori.py", data_file,str(t), "temp.txt"])
    end = time.time()
    apr.append(round(end - start, 3))
    start = time.time()
    subprocess.run(["python3", "fptree.py", data_file,str(t), "temp.txt"])
    end = time.time()
    fpbias.append(round(end - start, 3))
plt.xlabel('Support Threshold')
plt.ylabel('Time (M. Sec)')
plt.plot(thresholds,apr, c='g')
plt.plot(thresholds,fpbias, c='b')
plt.legend(['Appriori Algorithm Time', 'FP-Tree Algorithm Time'],loc='upper right')
plt.savefig(output_file_name+".png")


