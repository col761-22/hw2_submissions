#include "fptree.h"

void catchAlarm(int sig){
	cerr << "TLE (1 hr)" << endl;
	exit(-1);
}

void destroyTree(Node* root){
	if(root==NULL) return;
	for(auto node: root->child){
		destroyTree(node);
	}
	delete root;
}

bool cmp(pair<string, int> &a, pair<string, int> &b){
	//helper function to sort frequent 1-itemset
	if(a.second==b.second) return a.first<b.first;
	return a.second>b.second;
}
bool descendingOrder(tuple<string,int,vector<Node*>>& a, tuple<string,int,vector<Node*>>& b){
	//helper function to sort header table in descending order

	if(get<1>(a) == get<1>(b)) return (get<0>(a) < get<0>(b));
	return get<1>(a) > get<1>(b);
}

vector<vector<string>> subset(vector<string>& p, int i){
	//helper function to generate all subsets of a vector

	vector<vector<string>> res;
	if(i>=p.size()){
		vector<string> temp;
		res.push_back(temp);
		return res;
	}
	res = subset(p, i+1);
	vector<vector<string>> cp(res);
	for(auto a: cp){
		a.push_back(p[i]);
		res.push_back(a);
	}
	return res;
}

FpTree::FpTree(string dataFile, float support, string outFile){
	this -> dataFile = dataFile;
	this->support = support;
	this -> outFile = outFile;
}

void FpTree::initialize(){
	//read database to generate frequent 1-itemsets

	ifstream infile(dataFile);
	if(!infile){
		cout << "Unable to open data file." << endl;
		exit(0);
	}
	string line;
	numTransactions = 0;
	unordered_map<string,int> freq;
	while(getline(infile, line)){
		numTransactions++;
		stringstream str(line);
		string item;
		while(str>>item){
			freq[item]++;
		}
	}
	infile.close();
	for(auto it=freq.begin(); it!=freq.end();it++){
		if(((float)it->second)/numTransactions*100>=support)
			freqItems.push_back({it->first,it->second});
	}
	sort(freqItems.begin(),freqItems.end(), cmp);
}

void FpTree::makeTree(){
	//Create the initial FP tree

	fpTree = new Node("", NULL, 0);
	ifstream infile(dataFile);
	if(!infile){
		cout << "Unable to open file." << endl;
		exit(0);
	}
	string line;
	unordered_map<string,pair<int,vector<Node*>>> helper;
	while(getline(infile,line)){
		set<string> s;
		pair<vector<string>,int> transaction;
		transaction.second = 1;
		string item;
		stringstream str(line);
		while(str>>item){
			s.insert(item);
		}
		for(auto g:freqItems){
			if(s.find(g.first)!=s.end())
				(transaction.first).push_back(g.first);
		}
		insert(transaction, 0, fpTree,helper);
		
	}
	infile.close();
	freqItems.clear();
	for(auto it = helper.begin(); it!=helper.end();it++){
		headerTable.push_back(make_tuple(it->first,(it->second).first, (it->second).second));
	}
	sort(headerTable.begin(),headerTable.end(), descendingOrder);
}

void FpTree::insert(pair<vector<string>,int>& transaction, int index, Node* parent, 
		unordered_map<string,pair<int,vector<Node*>>>& helper){
	//recursive function to insert a node in tree

	vector<string> t= transaction.first;
	int counter = transaction.second;
	if(index>=(int)t.size()) return;
	for(auto node: parent->child){
		if(node->item == t[index]){
			node->count += counter;
			helper[node->item].first += counter;
			insert(transaction, index+1, node, helper);
			return;
		}
	}
	Node *node = new Node(t[index], parent, counter);
	helper[node->item].first += counter;
	helper[node->item].second.push_back(node);
	parent->child.push_back(node);
	insert(transaction, index+1, node, helper);
}

vector<pair<vector<string>,int>> FpTree::conditionalPatternBase(vector<Node*>& list){
	//generate conditional Pattern base

	vector<pair<vector<string>,int>> dataset;
	for(auto& node: list){
		int k = node->count;
		Node* crawl=node->parent;
		vector<string> temp;
		while(crawl->parent!=NULL){
			temp.push_back(crawl->item);
			crawl = crawl->parent;
		}
		if((int)temp.size()==0)continue;
		reverse(temp.begin(),temp.end());
		dataset.push_back({temp,k});
	}
	return dataset;
}

Node* FpTree::conditionalPatternTree(vector<pair<vector<string>,int>>& dataset, unordered_map<string,pair<int,vector<Node*>>>& helper){
	//generate conditional pattern tree

	Node *root = new Node("", NULL, 0);
	for(auto transaction:dataset){
		insert(transaction, 0, root, helper);
	}
	return root;
}


void FpTree::fpGrowth(Node* root, vector<string>& alpha, vector<tuple<string,int,vector<Node*>>>& headerTable){
	//recursive function for tree mining
	
	if(root->child.size()==0){
		destroyTree(root);
		return;
	}
	int mx = -1;
	Node* crawl = root;
	while(crawl->child.size()!=0){
		mx = max(mx, (int)crawl->child.size());
		crawl = crawl->child[0];
	}
	if(mx==1){
		//generate all possible subsets
		Node* traverse = root->child[0];
		vector<string> items;
		while(1){
			if((float)traverse->count/numTransactions*100>=support)
				items.push_back(traverse->item);
			else break;
			if(traverse->child.size()>0)traverse = traverse->child[0];
			else break;
		}
		vector<vector<string>> patterns = subset(items,0);
		//erase null subset
		vector<string> temp;
		auto it = find(patterns.begin(),patterns.end(), temp);
		patterns.erase(it);
		
		for(auto& pattern: patterns){
			pattern.insert(pattern.end(), alpha.begin(),alpha.end());
			sort(pattern.begin(),pattern.end());
			freqSets.push_back(pattern);
		}
	}
	else{
		for(int i = headerTable.size()-1;i>=0;i--){
			if(((float)get<1>(headerTable[i]))/numTransactions*100<support) continue;

			vector<string> beta(alpha);
			beta.push_back(get<0>(headerTable[i]));
			sort(beta.begin(),beta.end());
			freqSets.push_back(beta);

			vector<pair<vector<string>,int>> dataset = conditionalPatternBase(get<2>(headerTable[i]));
			
			unordered_map<string,pair<int,vector<Node*>>> helper;
			Node* tree = conditionalPatternTree(dataset, helper);

			vector<tuple<string,int,vector<Node*>>> nextHeader;
			for(auto it = helper.begin(); it!=helper.end();it++){
				nextHeader.push_back(make_tuple(it->first,(it->second).first, (it->second).second));
			}
			helper.clear();
			sort(nextHeader.begin(),nextHeader.end(),descendingOrder);
			
			fpGrowth(tree, beta, nextHeader);
		}
	}
	destroyTree(root);
}

void FpTree::writeAllFreqSets(){
	//write frequent Items to the output file

	sort(freqSets.begin(),freqSets.end());
	ofstream outToFile(outFile);
	for(auto freq:freqSets){
		for(auto s:freq)
			outToFile << s << " ";
		outToFile.seekp((long long)outToFile.tellp()-1);
		outToFile << endl;
	}
	outToFile.close();
}

void FpTree::runFpTree(){
	initialize();
	makeTree();
	fpGrowth(fpTree, alpha, headerTable);
}

int main(int argc, char *argv[]){
	string inputfile = argv[1];
	float support = stof(argv[2]);
	string outfile;
	if(argc>3)
		outfile = argv[3];

	// comment out the below 2 lines if you want timeout of 1 hr
	// signal(SIGALRM, catchAlarm);
	// alarm(3600);

	auto start = chrono::high_resolution_clock::now();
	FpTree fp(inputfile, support, outfile);
	fp.runFpTree();
	auto end = chrono::high_resolution_clock::now();

	fp.writeAllFreqSets();

	auto int_ms = std::chrono::duration_cast<std::chrono::microseconds>(end-start);
	auto duration = (int_ms.count()/1000000.0);
	cout << "Duration: " << duration << " -FpTree Dataset:" << inputfile
	 << " Support(%):" << support << endl;
}
