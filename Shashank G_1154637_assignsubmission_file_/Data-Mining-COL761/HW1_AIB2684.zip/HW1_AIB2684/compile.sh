#!/bin/bash
g++ -O3 apriori.h apriori_main.cpp -o apriori
g++ -O3 fptree.h fptree_main.cpp -o fptree
