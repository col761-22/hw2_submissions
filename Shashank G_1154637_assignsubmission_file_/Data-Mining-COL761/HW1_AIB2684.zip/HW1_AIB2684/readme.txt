github repo link: https://github.com/devanshu-suneja/Data-Mining-COL761

Team Name: Xcavators

2022AIB2682: Braj Raj Nagar
2022AIB2684: Shashank G
2022AIB2685: Devanshu Suneja

Explanation of files

apriori.h - Header file for apriori implementation
fptree.h - Header file for fptree implementation
apriori_main.cpp - implementation of the Apriori algorithm
fptree_main.cpp - implementation of the Frequent Pattern Tree algorithm
compile.sh - shell script to generate executable binaries of the respective algorithms
AIB2684.sh - shell scrpt for all commands as mentioned in HW1

Contributions

Devanshu Suneja(33.33%)-Implemented Apriori Algorithm and generated plot for the same
Shashank G(33.33%), Braj Raj Nagar(33.33%) - Implemented FP-tree algorithm, and generated plot for the same

Explanation for Q3 plot:

-Apriori is similar to a breadth first search algorithm, it generates candidates of one size greater every iteration and continues this process until no more candidates can be generated where as FP tree algorithm uses a depth first approch by pruning paths which is not guranteed to give frequent itemsets.
-Apriori generates a huge set of candidates and it requires us to count the frequency each time the candidate set is generated whereas FP-tree does not use such candidate generation step and it also requires two database access which makes FP-Tree algorithm significantly faster
-With the decrease in support percentage, the number of frequent itemsets increaeses exponetially which means both algorithm take more time. However Apriori algorithm requires more database acccesses which makes it more slower than FP-Tree algorithm

