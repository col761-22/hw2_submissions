#include<signal.h>
#include<iostream>
#include<sstream>
#include<fstream>
#include<algorithm>
#include<map>
#include<chrono>
#include<vector>
#include<string>

using namespace std;

class Apriori{
public:
	string dataFile;
	string outFile;
	int numTransactions;
	float support;
	map<vector<string>,int> freqItemCount;
	vector<vector<string>> freqSet;
	vector<vector<string>> prevSet;
	vector<vector<string>> candidateSet;

	Apriori(string dataFile, float support, string outFile);
	void initialize();
	void generateCandidates(int k);
	bool pruneCheck(vector<string> candidate);
	void calculateFrequency();
	void writeAllFreqSets();
	void runApriori();
};