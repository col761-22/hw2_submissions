import sys, os, subprocess
import matplotlib.pyplot as plt
import numpy as np

inpname = sys.argv[1]
outname = sys.argv[2]+'.png'


support_list = [90,50,25,10,5]
apriori = []
fptree = []

for x in support_list:
	cmdap= './apriori ' + inpname + ' ' + str(x)
	try:
		print('running apriori for '+ inpname + ' with support ' + str(x) + '...', end = ' ')
		sys.stdout.flush()
		result = subprocess.run(cmdap, stdout = subprocess.PIPE, shell = True, timeout = 3600, check = True)
	
	except subprocess.TimeoutExpired as obj:
		print('TLE '+ str(obj.timeout/3600) + 'hr')
		apriori.append(np.nan)
	
	except subprocess.CalledProcessError as err:
		print(err.returncode)
		apriori.append(np.nan)
	
	else:
		out = result.stdout.decode('UTF-8')
		duration = float(out.split()[1])
		print('done '+ str(duration) + 's')
		apriori.append(duration)

	cmdfp = './fptree ' + inpname + ' ' + str(x)
	try:
		print('running fptree for '+ inpname + ' with support ' + str(x) + '...', end = ' ')
		sys.stdout.flush()
		result = subprocess.run(cmdfp, stdout = subprocess.PIPE, shell = True, timeout = 3600, check = True)
	
	except subprocess.TimeoutExpired as obj:
		print('TLE '+ str(obj.timeout/3600) + 'hr')
		fptree.append(np.nan)
	
	except subprocess.CalledProcessError as err:
		print(err.returncode)
		fptree.append(np.nan)
	
	else:
		out = result.stdout.decode('UTF-8')
		duration = float(out.split()[1])
		print('done '+ str(duration) + 's')
		fptree.append(duration)

# Making the plots and showing/storing them
plt.plot(support_list, apriori, 'b', support_list,fptree, 'tab:orange')
plt.xlabel('Support (in percentage)')
plt.ylabel('Execution time (in seconds)')
plt.legend(['Apriori','FP-tree'])
plt.savefig(outname)
