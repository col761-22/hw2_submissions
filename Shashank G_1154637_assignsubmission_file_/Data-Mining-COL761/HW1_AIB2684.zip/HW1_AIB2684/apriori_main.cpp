#include "apriori.h"

void catchAlarm(int sig){
	cerr << "TLE (1 hr)" << endl;
	exit(-1);
}

Apriori::Apriori(string dataFile, float support, string outFile){
	this->dataFile = dataFile;
	this->support = support;
	this->outFile = outFile;
}

void Apriori::initialize(){
	//Genererate frequent 1-itemset from the transaction database
	ifstream infile(dataFile);
	if(!infile){
		cout << "unable to open file";
		exit(0);
	}
	string line;
	numTransactions = 0;
	while(getline(infile,line)){
		numTransactions++;
		stringstream str(line);
		string item;
		while(str>>item){
			freqItemCount[vector<string> (1,item)]++;
		}
	}
	for(auto it=freqItemCount.begin(); it!=freqItemCount.end();it++){
		if(((float)(it->second)/numTransactions)*100>=support){
			freqSet.push_back(it->first);
		}
	}
	//cout << numTransactions << " " << numSupp << '\n';
	prevSet= freqSet;
	sort(prevSet.begin(),prevSet.end());
	freqItemCount.clear();
}

bool Apriori::pruneCheck(vector<string> candidate){
	//check if a (k-1)-itemset subset of candidate is part of L[k-1];
	int k = candidate.size();
	for(int i = 0;i<k;i++){
		vector<string> temp;
		for(int j = 0;j<k;j++){
			if(i==j) continue;
			temp.push_back(candidate[j]);
		}
		if(find(prevSet.begin(),prevSet.end(),temp)==prevSet.end()){
			return false;
		}
	}
	return true;
}

void Apriori::generateCandidates(int k){
	//generate all possible candidates and prune candidates which are not valid
	for(int i = 0;i<prevSet.size();i++){
		for(int j = i+1;j<prevSet.size();j++){
			vector<string> l1 = prevSet[i];
			vector<string> l2 = prevSet[j];
			if(l1.size()==1){
				candidateSet.push_back(vector<string> {l1[0],l2[0]});
				continue;
			}
			if((vector<string> (l1.begin(),l1.end()-1) == vector<string> (l2.begin(),l2.end()-1))
			 && (l1[k-2]!=l2[k-2])){
				vector<string> candidate(l1.begin(),l1.end());
				candidate.push_back(l2[k-2]);
				if(pruneCheck(candidate)){
					candidateSet.push_back(candidate);
				}
			}	
		}
	}
}

void Apriori::calculateFrequency(){
	//calculate the frequency of the candidates generated which are then added to freqSet.
	ifstream infile(dataFile);
	if(!infile){
		cout << "unable to open file";
		exit(0);
	}
	string line;
	while(getline(infile,line)){
		stringstream str(line);
		string item;
		vector<string> transaction;
		while(str>>item){
			transaction.push_back(item);
		}
		sort(transaction.begin(),transaction.end());
		for(vector<string> candidate:candidateSet){
			if(includes(transaction.begin(),transaction.end(), candidate.begin(),candidate.end()))
				freqItemCount[candidate]++;
		}
	}
	infile.close();
	vector<vector<string>> goodCandidates;
	for(auto it=freqItemCount.begin(); it!=freqItemCount.end();it++){
		if(((float)(it->second)/numTransactions)*100>=support){
			goodCandidates.push_back(it->first);
			freqSet.push_back(it->first);
		}
	}
	prevSet= goodCandidates;
	sort(prevSet.begin(),prevSet.end());
	candidateSet.clear();
	freqItemCount.clear();
}

void Apriori::writeAllFreqSets(){
	sort(freqSet.begin(),freqSet.end());
	ofstream outToFile(outFile);
	for(vector<string> freq:freqSet){
		for(string s:freq)
			outToFile << s << ' ';
		outToFile.seekp((long long)outToFile.tellp()-1);
		outToFile << endl;
	}
	outToFile.close();
}

void Apriori::runApriori(){
	initialize();
	for(int k = 2;(int)prevSet.size()>1;k++){
		generateCandidates(k);
		calculateFrequency();
	}
}
int main(int argc, char *argv[]){
	string inputfile = argv[1];
	float support = stof(argv[2]);
	string outfile;
	if(argc>3)
		outfile = argv[3];

	// comment out the below 2 lines if you want timeout of 1 hr
	// signal(SIGALRM, catchAlarm);
	// alarm(3600);

	auto start = chrono::high_resolution_clock::now();
	Apriori ap(inputfile, support, outfile);
	ap.runApriori();
	auto end = chrono::high_resolution_clock::now();

	ap.writeAllFreqSets();

	auto int_ms = std::chrono::duration_cast<std::chrono::microseconds>(end-start);
	auto duration = (int_ms.count()/1000000.0);
	cout << "Duration: " << duration << " -Apriori Dataset:" << inputfile
	 << " Support(%):" << support << endl;
}