#include<signal.h>
#include<iostream>
#include<sstream>
#include<fstream>
#include<algorithm>
#include<map>
#include<chrono>
#include<vector>
#include<string>
#include<set>
#include<unordered_map>

using namespace std;

class Node{
public:
	string item;
	int count;
	Node* parent;
	vector<Node*> child;

	Node(string name, Node* parent, int counter){
		this -> item = name;
		this ->count = counter;
		this ->parent = parent;
	}
};

class FpTree{
public:
	string dataFile;
	string outFile;
	int numTransactions;
	float support;
	Node *fpTree;
	vector<pair<string, int>> freqItems; // freq 1-itemsets
	vector<tuple<string,int,vector<Node*>>> headerTable;
	vector<string> alpha;
	vector<vector<string>> freqSets;


	FpTree(string dataFile, float support, string outFile);
	void initialize();
	void makeTree();
	void insert(pair<vector<string>,int>& transaction, int index, Node* parent,unordered_map<string,pair<int,vector<Node*>>>& helper);
	vector<pair<vector<string>,int>> conditionalPatternBase(vector<Node*>& list);
	Node* conditionalPatternTree(vector<pair<vector<string>,int>>& dataset, unordered_map<string,pair<int,vector<Node*>>>& helper);
	void fpGrowth(Node* root, vector<string>& alpha ,vector<tuple<string,int,vector<Node*>>>& headerTable);
	void writeAllFreqSets();
	void runFpTree();	
};