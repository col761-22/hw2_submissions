github repo link: https://github.com/devanshu-suneja/Data-Mining-COL761

Team Name: Xcavators

2022AIB2682: Braj Raj Nagar
2022AIB2684: Shashank G
2022AIB2685: Devanshu Suneja

Explanation of files
fsg             - executable file for fsg algorithm
gaston          - executable file for gaston algorithm
gSpan           - executable file for gSpan algorithm
convert.py      - python file convert the given graph dataset to a format which other algorithms require
plot.py         - python file used to plot the comparison between different algorithms
elbow_plot.sh   - bash script to run q3.py using arguments as specified in q3
q3.py           - python file used to plot the elbow plot

1st question: use the command
            python plot.py <filename>
            where <filename> is the yeast dataset ending with '.txt' format

3rd question: use the command
            sh elbow_plot.sh <dataset> <dimension> q3_<dimension>_<RollNo>.png
            as mentioned in the question


Contributions

Devanshu Suneja(33.33%)-Implemented 3rd question.
Shashank G(33.33%), Braj Raj Nagar(33.33%) - Implemented 1st question and did other miscellaneous work.
