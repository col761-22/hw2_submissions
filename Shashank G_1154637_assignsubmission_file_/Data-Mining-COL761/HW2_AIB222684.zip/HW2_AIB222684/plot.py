import subprocess
import os,sys
import time
import re
import matplotlib.pyplot as plt

filename = sys.argv[1]

algos = ['gspan','fsg','gaston']
prefix = re.sub(r'\..*','',filename)

min_suplist = [5.0, 10.0, 25.0, 50.0, 95.0]
gspan, fsg, gaston = [], [], []

cmd = 'python convert.py ' + filename
output = subprocess.run(cmd, stdout = subprocess.PIPE, shell = True)
n_graphs = int(output.stdout.decode())
print(n_graphs)

for sup in min_suplist:
	for algo in algos:
		if algo=='gspan':
			file = prefix + '_gspan'
			start = time.time()
			cmd = './gSpan' + ' -f '+ file + ' -s '+ str(sup/100) + ' -o'
			subprocess.run(cmd, shell = True)
			end = time.time()
			gspan.append(end-start)
		elif algo == 'fsg':
			start = time.time()
			file = prefix + '_fsg'
			cmd = './fsg -s ' + str(sup) +  ' ' + file
			subprocess.run(cmd, shell = True, check = True)
			end = time.time()
			fsg.append(end-start)
		elif algo == 'gaston':
			start = time.time()
			file = prefix + '_gaston'
			freq = sup/100*n_graphs
			cmd = './gaston ' + str(freq) + ' ' + file + ' ' + file + '.fp'
			subprocess.run(cmd, shell = True, check = True)
			end = time.time()
			gaston.append(end-start)

plt.plot(min_suplist, gspan, 'tab:blue', min_suplist, fsg, 'tab:orange', min_suplist, gaston, 'tab:red')
plt.xlabel('Support (in percentage)')
plt.ylabel('Execution time (in seconds)')
plt.legend(['gspan','FSG', 'Gaston'])
plt.savefig('comparison.jpg')
