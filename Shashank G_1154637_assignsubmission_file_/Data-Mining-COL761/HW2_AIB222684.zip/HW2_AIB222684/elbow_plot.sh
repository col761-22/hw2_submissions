#!/bin/bash

python q3.py $1 $2 $3
