import numpy as np
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import sys


x_data = np.genfromtxt(sys.argv[1])
# print(x_data.shape)
k_list = [k for k in range(1,16)]
# print(k_list)
error = []
for i in k_list:
    km = KMeans(
        n_clusters=i, init='random',
        n_init=10, max_iter=300, 
        tol=1e-04, random_state=0
    )
    y_km = km.fit_predict(x_data)

    error.append(km.inertia_)
    # print(y_km)

plt.plot(k_list, error, marker = 'o')
plt.xlabel('No. of Clusters')
plt.ylabel('Sum of Squared Errors')
plt.title('K-means Clustering')
plt.savefig(sys.argv[3])
