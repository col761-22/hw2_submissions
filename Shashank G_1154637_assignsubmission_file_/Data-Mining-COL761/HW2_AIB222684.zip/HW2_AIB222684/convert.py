import os,sys
import re

filename = sys.argv[1]

algos = ['gspan','gaston', 'fsg']

file = open(filename,'r')
filelines = file.readlines()
file.close()
total = 0

for algo in algos:
	lines = filelines.copy()
	output = re.sub(r'\..*','',filename) + '_' + algo
	outfile = open(output,'w')
	mapping = dict()
	global_count = 0
	count = 0
	int_label = 0

	vertex = False
	edge = False
	i=0
	while i < len(lines):
		if lines[i][0]=='#':
			outfile.write('t # '+ str(global_count) + '\n')
			global_count+=1
			vertex = True
			i+=1
			
		elif vertex == True:
			vertex_count = int(lines[i])
			for j in range(1,vertex_count+1):
				label = lines[i+j].replace('\n','')
				if label in mapping:
					int_label = mapping[label]
				else:
					int_label = count
					mapping[label]=count
					count+=1
				outfile.write('v '+ str(j-1) + ' ' + str(int_label) + '\n')
			i += vertex_count+1
			vertex = False
			edge = True
			
		elif edge == True:
			edge_count = int(lines[i])
			for j in range(1,edge_count+1):
				line = lines[i+j]
				if algo == 'gaston' or algo == 'gspan':
					outfile.write('e '+line)
				else:
					outfile.write('u '+line)
			i += edge_count+1
			edge = False
			
		else:
			i+=1
	outfile.close()
	total = global_count
print(total)