import argparse

def get_apriori_results(INPUT_FILE, SUPPORT_PERCENTAGE):
    """
    --> Reads transactions from input file from disk without loading into main memory,
        executes Apriori algorithm to identify frequent itemsets, and returns them.
    :param: INPUT_FILE: input file path (.dat) where transactions data is stored.
    :pararm: SUPPORT_PERCENTAGE: The support percentage threshold above which a candidate will be considered frequent.
    :return: List of frequent itemsets of all sizes.
    """
    # Opening the file
    with open(INPUT_FILE, "r") as trans_file:
        # Generating candidates of size 1
        ITEMSET_SIZE = 1
        deg_1_itemset, TOTAL_TRANSACTIONS = gen_1_degree_itemset(trans_file)
        TOTAL_ITEMS = len(deg_1_itemset)

        # Computing support count threshold from support percentage and total transactions
        SUPPORT_COUNT = SUPPORT_PERCENTAGE / 100 * TOTAL_TRANSACTIONS

        # Getting frequent itemsets of size 1
        freq_itemset = dict()
        freq_itemset[ITEMSET_SIZE] = {itemset: freq for itemset, freq in deg_1_itemset.items() if freq >= SUPPORT_COUNT}

        # Generating the frequent itemsets of size K from size K-1, until no more candidates of size K can be generated
        while(True):
            ITEMSET_SIZE += 1
            trans_file.seek(0)

            candidate_itemset_k = generate_size_k_itemset([set(x) for x in freq_itemset[ITEMSET_SIZE-1].keys()], ITEMSET_SIZE)
            if len(candidate_itemset_k) == 0:
                break
            freq_itemset[ITEMSET_SIZE] = get_freq_itemset(trans_file, candidate_itemset_k, SUPPORT_COUNT)
            if len(freq_itemset) <= 1:
                break
    return freq_itemset

def gen_1_degree_itemset(trans_file):
    """
    --> Generating all the candidate itemsets of size 1 along with their frequency,
        along with returning the total number of transactions in the file.
    :param: trans_file: It the input file object that contains all the transactions residing in a disk file.
    :return: (itemset_1, total_transactions) -> Itemset of size 1 & total number of transactions.
    """
    itemset_1 = dict()
    total_transactions = 0
    for transaction in trans_file:
        total_transactions += 1
        for item in transaction.split():
            itemset = tuple([item])
            if itemset in itemset_1:
                itemset_1[itemset] += 1
            else:
                itemset_1[itemset] = 1
    return itemset_1, total_transactions

def generate_size_k_itemset(prev_freq_itemset, itemset_size):
    """
    --> Generating candidate itemset of size K, using the frequent itemsets of size (K-1).
    :param: prev_freq_itemset: The list of frequent itemset of size (itemset_size - 1).
    :param: itemset_size: The size of itemset (K) for which the candidate itemsets must be generated.
    :return: The list of all the candidate itemsets of size "itemset_size".
    """
    itemset_size_k = dict()
    for i, itemset1 in enumerate(prev_freq_itemset[:-1]):
        for itemset2 in prev_freq_itemset[i+1:]:
            if itemset_size == 2 or len(itemset1.intersection(itemset2)) == itemset_size - 2:
                combined_itemset = tuple(sorted(itemset1.union(itemset2)))
                if combined_itemset in itemset_size_k.keys():
                    itemset_size_k[combined_itemset] += 1
                else:
                    itemset_size_k[combined_itemset] = 1
    total_subsets = itemset_size * (itemset_size - 1) / 2
    return [itemset for itemset, freq in itemset_size_k.items() if freq == total_subsets]

def get_freq_itemset(trans_file, size_k_itemset, support_count):
    """
    --> Finds the frequency of each candidate itemset of size K in the file.
    --> It returns the dictionary of frequent itemsets along with their support count.
    --> A candidate itemset is considered frequent, if its frequency >= support_count.
    :param: trans_file: It the input file object that contains all the transactions residing in a disk file.
    :param: size_k_itemset: The list of candidate itemsets of size K.
    :param: support_count: Support count threshold for considering an itemset as frequent.
    :return: A dictionary of frequent itemsets of size K with their frequency.
    """
    freq_itemset = {itemset: 0 for itemset in size_k_itemset}
    for transaction in trans_file:
        trans_itemset = transaction.split()
        for itemset in size_k_itemset:
            if all(item in trans_itemset for item in itemset):
                freq_itemset[itemset] += 1
    return {itemset: freq for itemset, freq in freq_itemset.items() if freq >= support_count}

def format_output(freq_itemset):
    """
    --> Formatting output based on the desired structure:
        - Items within itemsets are seperated via space & sorted via ASCII value
        - Itemsets are also sorted via ASCII values
    :param: freq_itemset: List of all the frequent itemsets
    :return: List of all the itemsets sorted & formatted in the desired manner. 
    """
    all_freq_itemsets = []
    for itemsets_k in freq_itemset.values():
        for itemset in itemsets_k.keys():
            all_freq_itemsets.append(" ".join(itemset))
    all_freq_itemsets.sort()
    return all_freq_itemsets

def main():
    """
    --> The main function that parses arguments, executes Apriori algorihtm without loading transactions
        into main memory and saves the output in the given file in the desired format.
    """
    # Parsing the input arguments
    parser = argparse.ArgumentParser()
    parser.add_argument("--input","-inp_file",required=True,type=str)
    parser.add_argument("--support","-sup",required=True,type=float)
    parser.add_argument("--output","-out_file",required=True,type=str)
    args = parser.parse_args()
    INPUT_FILE = args.input
    OUTPUT_FILE = args.output
    SUPPORT_PERCENTAGE = args.support

    # Get frequent itemsets using Apriori Algorithm
    freq_itemset = get_apriori_results(INPUT_FILE, SUPPORT_PERCENTAGE)
        
    # Formatting the output based on the desired structure
    all_freq_itemsets = format_output(freq_itemset)

    # Saving the output to the output file in the given path
    with open(OUTPUT_FILE, "w") as f:
        for itemset in all_freq_itemsets:
            f.write(itemset + "\n")

if __name__=="__main__":
    main()
