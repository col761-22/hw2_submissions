import argparse
import time
import sys
from matplotlib import pyplot as plt

from apriori import get_apriori_results
from fptree import get_fptree_results

if __name__=="__main__":
    # Parsing the input arguments
    parser = argparse.ArgumentParser()
    parser.add_argument("--input","-inp_file",required=True,type=str)
    parser.add_argument("--output","-out_file",required=True,type=str)
    args = parser.parse_args()
    INPUT_FILE = args.input
    OUTPUT_FILE = args.output
    
    threshold_values = [90, 50, 25, 10, 5]
    
    apriori_algo = []
    fptree_algo = []

    for sup in threshold_values:
        print(sup)
        # Apriori execution results
        start_time = time.time()
        apriori_results = get_apriori_results(INPUT_FILE, sup)
        end_time = time.time()
        apriori_algo.append(end_time-start_time)
        
        # FP-Tree execution results
        start_time = time.time()
        fptree_results = get_fptree_results(INPUT_FILE, sup)
        end_time = time.time()
        fptree_algo.append(end_time-start_time)
        
    # Plotting results
    plt.figure()
    plt.plot(threshold_values, apriori_algo, label='Apriori Algo')
    plt.plot(threshold_values, fptree_algo, label='FPtree ALgo')
    plt.title('Apriori v/s FP-Tree Execution Time Comparison')
    plt.xlabel('Support threshold (%)')
    plt.ylabel('Execution Time (s)')
    plt.legend()
    plt.savefig(OUTPUT_FILE + '.png')
