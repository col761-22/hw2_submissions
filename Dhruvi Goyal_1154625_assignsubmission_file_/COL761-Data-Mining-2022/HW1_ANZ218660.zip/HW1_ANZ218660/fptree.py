import argparse
from collections import defaultdict


class Node:
    def __init__(self, item_name, freq, parent_node):
        self.item_label = item_name
        self.count = freq
        self.parent = parent_node
        self.children = {}
        self.next = None

    def increment(self, freq):
        self.count += freq


def construct_fp_tree(database, sup_per):
    # creating the header table
    database_length = 0
    header_table = defaultdict(int)
    with open(database, 'r') as file:
        for transaction in file:
            transaction = transaction.split()
            database_length += 1
            for item in transaction:
                header_table[item] += 1

    min_sup = (sup_per / 100) * database_length

    # deleting items below minimum support
    temp = []
    for item in header_table:
        if header_table[item] >= min_sup:
            temp.append((item, header_table[item]))
    header_table = dict(temp)
    if len(header_table) == 0:
        return None, None, None

    # linking header table to headnodes and keeping track of all the nodes
    for item in header_table:
        header_table[item] = [header_table[item], None]

    # creating the fp tree
    fp_tree = Node('Null', 1, None)
    with open(database, 'r') as file:
        for transaction in file:
            frequent_items = []
            transaction = transaction.split()
            database_length += 1
            for item in transaction:
                # filtering items which are not there in header table
                if item in header_table:
                    frequent_items.append(item)

            # sorting frequent items in descending order
            frequent_items.sort(key=lambda item: header_table[item][0], reverse=True)

            # updating the tree with frequent items of each transaction
            current_node = fp_tree
            for item in frequent_items:
                current_node = update_tree(item, current_node, header_table)

    return fp_tree, header_table, min_sup


def update_tree(item, node, header_table):
    if item in node.children:
        # if the item is already there in the tree, increase the count by 1
        node.children[item].increment(1)
    else:
        # if the item is not already there in the tree, create a new node
        new_node = Node(item, 1, node)
        node.children[item] = new_node
        # this node needs to be added to the header table to keep track of all nodes with same label
        update_header(item, new_node, header_table)

    return node.children[item]


def update_header(item, node, header_table):
    if header_table[item][1] is None:
        header_table[item][1] = node
    else:
        # looking at the last node in the header table and ading new node to it
        last_node = header_table[item][1]
        while last_node.next is not None:
            last_node = last_node.next
        last_node.next = node


def mine_fp_tree(header_table, min_sup, init_set, freq_items):
    # sort the header table items by frequency in ascending order and create a list of items only
    temp_list = sorted(list(header_table.items()), key=lambda p: p[1][0])
    sorted_list = []
    for item in temp_list:
        sorted_list.append(item[0])

    for item in sorted_list:
        new_set = init_set.copy()
        new_set.add(item)
        freq_items.append(new_set)
        # need to make conditional pattern base
        conditional_pattern, frequency = traversal(item, header_table)
        # making conditional fp trees
        conditional_tree, new_header = construct_conditional_tree(conditional_pattern, frequency, min_sup)
        if new_header is not None:
            # Mining recursively on the tree
            mine_fp_tree(new_header, min_sup, new_set, freq_items)


def traversal(base, header_table):
    node = header_table[base][1]
    conditional_pattern = []
    freq = []
    while node is not None:
        path = []
        path_finder(node, path)
        if len(path) > 1:
            conditional_pattern.append(path[1:])
            freq.append(node.count)

        node = node.next
    return conditional_pattern, freq


def path_finder(node, path):
    if node.parent is not None:
        path.append(node.item_label)
        path_finder(node.parent, path)


def construct_conditional_tree(cond_pattern_list, freq, min_sup):
    # creating the header table
    header_table = defaultdict(int)
    for idx, itemSet in enumerate(cond_pattern_list):
        for item in itemSet:
            header_table[item] += freq[idx]

    # deleting items below minimum support
    temp = []
    for item in header_table:
        if header_table[item] >= min_sup:
            temp.append((item, header_table[item]))
    header_table = dict(temp)
    if len(header_table) == 0:
        return None, None

    for item in header_table:
        header_table[item] = [header_table[item], None]

    # linking header table to headnodes and keeping track of all the nodes
    cond_fp_tree = Node('Null', 1, None)
    for idx, itemSet in enumerate(cond_pattern_list):
        itemSet = [item for item in itemSet if item in header_table]
        itemSet.sort(key=lambda item: header_table[item][0], reverse=True)

        node = cond_fp_tree
        for item in itemSet:
            node = update_conditional_tree(item, node, header_table, freq[idx])

    return cond_fp_tree, header_table


def update_conditional_tree(item, node, header_table, freq):
    if item in node.children:
        # if the item is already there in the tree, increase the count
        node.children[item].increment(freq)
    else:
        # if the item is not already there in the tree, create a new node
        new_node = Node(item, freq, node)
        node.children[item] = new_node
        # this node needs to be added to the header table to keep track of all nodes with same label
        update_header(item, new_node, header_table)

    return node.children[item]


def get_fptree_results(database, sup_per):
    fp_tree, header_table, min_sup = construct_fp_tree(database, sup_per)

    if fp_tree is None:
        print('No frequent item set')
        return []
    else:
        freq_items = []
        mine_fp_tree(header_table, min_sup, set(), freq_items)
        return freq_items


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", "-inp_file", required=True, type=str)
    parser.add_argument("--support", "-sup", required=True, type=float)
    parser.add_argument("--output", "-out_file", required=True, type=str)
    args = parser.parse_args()
    INPUT_FILE = args.input
    OUTPUT_FILE = args.output
    SUPPORT_PERCENTAGE = args.support

    freqItemSet = get_fptree_results(INPUT_FILE, SUPPORT_PERCENTAGE)

    out_ = []
    if freqItemSet is not None:
        for item in freqItemSet:
            temp = sorted(item)
            temp2 = ' '.join(temp)
            out_.append(temp2)
        out_ = sorted(out_)

    with open(OUTPUT_FILE, 'w') as fp:
        for item in out_:
            fp.write("%s\n" % item)
