if [ $1 = "-apriori" ]
then
    python3 apriori.py -inp_file $2 -sup $3 -out_file $4
elif [ $1 = "-fptree" ]
then
    python3 fptree.py -inp_file $2 -sup $3 -out_file $4
elif [ $1 = "-plot" ]
then
    python3 plot.py -inp_file $2 -out_file $3
else
    echo "Wrong option"
fi