# File Details
1) **ANZ218660.sh** - It takes different options and runs appropriate command to execute python script 
based on the arguments being passed. The 3 options are execution of Apriori algorithm (-apriori),
FP-Tree algorithm (-fptree) and comparison of runtime of the 2 algos based on different support thresholds
(-plot). All these options take input and output file as arguments, whereas -apriori & -fptree also takes
support percentage threshold as input.
```
./ANZ218660.sh -apriori input_file.dat 30 output_file.dat
./ANZ218660.sh -fptree input_file.dat 30 output_file.dat
./ANZ218660.sh -plot input_file.dat output_plot
```

2) **apriori.py** - It is the python script containing code for finding the frequent itemsets using
the Apriori algorithm. It takes input file (-inp_file), support percentage threshold (-sup) and 
output file (-out_file) as arguments.
```
python3 apriori.py -inp_file input_file.dat -sup 30 -out_file output_file.dat
```

3) **fptree.py** - It is the python script containing code for finding the frequent itemsets using
the FP-Tree algorithm. It takes input file (-inp_file), support percentage threshold (-sup) and 
output file (-out_file) as arguments.
```
python3 fptree.py -inp_file input_file.dat -sup 30 -out_file output_file.dat
```

4) **plot.py** - It is the python script file containing code for running Apriori and FP-Tree algorithms
for different support threshold values and computes their respective execution time of generating frequent itemsets
for given thresholds. It then plots the runtime info of both the algorithms with respect to given support
percentage thresholds (currently for [5, 10, 25, 50, 90] support%), and saves to the given output file in png format.
```
python3 plot.py -inp_file input_file.dat -out_file output_plot
```


# Apriori v/s FP-Tree Runtime Performance Comparison
It was discovered that the FP-growth algorithm runs faster than the Apriori algorithm. 

As the size of candidate sets increases, the pattern matching operation of comparing candidate sets with transactions becomes quite expensive in Apriori algorithm. The breadth first search approach used by Apriori can be memory expensive because it requires always keeping all k and k -1 itemsets in memory (for k > 1). This effectively becomes less efficient approach for large datasets.

On the other hand, there is no candidate generation in FP-tree. It eliminates the need to compute the pairs to be counted (which requires expensive computation). An important point to highlight here is that the FP-Growth algorithm adopts DFS approach and keeps a compressed version of the database in memory. This is one significant advantage of the fp-growth algorithm that it only investigates frequent itemsets in the search space, hence avoids considering many infrequent itemsets, or itemsets that don't occur in the database. There is no candidate generation in case of FP Tree algorithm. It simply needs to scan the database twice only unlike Apriori which scans for each iteration.

As observed, the time complexity of Apriori, is another drawback. As opposed to Apriori, the FP-growth method is substantially faster. In addition, as the support threshold increases, the running time of both Apriori and FP-growth decreases. In comparison to Apriori, the decrease in FP-growth is smaller. Whenever new candidates are generated, a database scan is necessary, which necessitates more database scans than FP-growth. However, FP- tree only needs two DB scans making it significantly more efficient computationally.


# Team Members & Contributions
- Dhruvi Goyal - 2021ANZ8660
- Hargun Singh Grover - 2021AIZ8326
- Kirtika Sharma - 2022SRZ8379


# Contributions
- Dhruvi Goyal (33.3%) - Apriori Algorithm Code, Creating Bash Scripts & Readme, Testing Results

- Hargun Singh Grover (33.3%) - FP-Tree Algorithm Code

- Kirtika Sharma (33.3%) - Performance Comparison Code & Evaluation, FP Tree Refinements
