/*
--> This file contains some common utility functions that are used across the files.
--> Note: For boost-graph, few code blocks are taken from its official 
    documentation - https://www.boost.org/doc/libs/1_63_0/libs/graph/doc/
*/

#ifndef functions_h
#define functions_h


#include<iostream>
#include<algorithm>
#include <fstream>
#include <string>  
#include <vector> 
#include <list>
#include <unordered_map>
#include <unordered_set>
#include <set>
#include<cmath>
#include<string>
#include<sstream>
#include <chrono> 
#include<cstdio>
#include <boost/graph/vf2_sub_graph_iso.hpp>
#include <boost/graph/graph_utility.hpp>
#include <boost/graph/adjacency_list.hpp>

using namespace std::chrono; 
using namespace std;
using namespace boost;

typedef property<edge_name_t, int> edge_char;
typedef property<vertex_name_t, int, property<vertex_index_t, int> > vertex_char;
typedef adjacency_list<vecS, vecS, undirectedS, vertex_char, edge_char> graph_adjacency_list;
typedef property_map<graph_adjacency_list, vertex_name_t>::type graph_vertex_label_map_type;
typedef property_map_equivalent<graph_vertex_label_map_type, graph_vertex_label_map_type> graph_vertex_label_eqv;
typedef property_map<graph_adjacency_list, edge_name_t>::type graph_edge_label_map_type;
typedef property_map_equivalent<graph_edge_label_map_type, graph_edge_label_map_type> graph_edge_label_eqv;

template<typename Graph1, typename Graph2> struct vf2_callback{
    /*
    --> VF2 callback, taken from its official document.
    */
    vf2_callback(Graph1 g, Graph2 f){
    }
    template <typename CorrespondenceMap1To2,
          typename CorrespondenceMap2To1>
    bool operator()(CorrespondenceMap1To2 f, CorrespondenceMap2To1 g) const {
        return false;
    }
};


bool is_subgraph_isomorphic(graph_adjacency_list graph_1, graph_adjacency_list graph_2){
    /*
    --> Returns true if graph_1 is subgraph isomorphic to graph_2, else false
    */
    graph_vertex_label_eqv vertex_comp =
        make_property_map_equivalent(get(vertex_name, graph_1), get(vertex_name, graph_2));
    graph_edge_label_eqv edge_comp =
        make_property_map_equivalent(get(edge_name, graph_1), get(edge_name, graph_2));
    vf2_callback<graph_adjacency_list , graph_adjacency_list> callback(graph_1,graph_2);
    return vf2_subgraph_mono(graph_1, graph_2, callback, vertex_order_by_mult(graph_1),
                       edges_equivalent(edge_comp).vertices_equivalent(vertex_comp));
}

vector<std::string> split(std::string &inp_string, char split_delimeter){
    /*
    --> It splits the string based on the given delimeter and returns the vector of strings.
    */
    std::stringstream string_stream(inp_string);
    std::string sub_string;
    std::vector<std::string> substr_vector;
    while (std::getline(string_stream, sub_string, split_delimeter)){
       substr_vector.push_back(sub_string);
    }
    return substr_vector;
}


void load_graphs_from_db(string input_file, vector<graph_adjacency_list> &inp_db_graphs,std::unordered_map<string,int> &graph_char_label_to_index,std::unordered_map<int,int> &map_index_to_graph_id){
    /*
    --> Loading all the graphs in adjacency_list format from the given input file.
    */
    ifstream graph_db_file;
    graph_db_file.open(input_file);
    stringstream file_content_stream;
    file_content_stream << graph_db_file.rdbuf(); 
    string content_str = file_content_stream.str(); 
    vector<string> total_line_count = split(content_str,'\n');

    int graph_counter = 0;
    int file_counter = 0;
    int label_counter = 1;
    while(file_counter < total_line_count.size()){
        string line = total_line_count[file_counter];
        //check for start of a new graph
        if (line.size() > 0 && line[0] == '#'){
            // initialize graph of boost
            graph_adjacency_list graph;
            int total_vertices = 0;
            int total_edges = 0;
            // id of graph written after hash
            int graph_id = stoi(line.substr(1));

            file_counter++;
            // next line has total number of vertices
            total_vertices = stoi(total_line_count[file_counter]);
            for(int i =0; i<total_vertices; i++){
                file_counter++;
                string vertex_label = total_line_count[file_counter];
                //if label is not in map, add to it
                if(graph_char_label_to_index.find(vertex_label) == graph_char_label_to_index.end()){
                graph_char_label_to_index[vertex_label] = label_counter;
                label_counter++;
                }
                // add vertex to boost graph
                add_vertex(vertex_char(graph_char_label_to_index[vertex_label]), graph);
            }

            file_counter++;
            //checking for hash again because graphs might not have any edges
            if(total_line_count[file_counter][0] != '\n' && total_line_count[file_counter][0]!= '#'){
                total_edges = stoi(total_line_count[file_counter]);
                for(int i = 0;i < total_edges;i++){
                    int source_vertex_;
                    int dest_vertex_;
                    string edge_label_;
                    file_counter ++;
                    istringstream line_stream(total_line_count[file_counter]);
                    line_stream >> source_vertex_ >> dest_vertex_ >> edge_label_;
                    if (source_vertex_ > dest_vertex_){
                    int temp_var = source_vertex_;source_vertex_ = dest_vertex_; dest_vertex_ =temp_var;
                    }
                    //if label is not in map, add to it
                    if(graph_char_label_to_index.find(edge_label_) == graph_char_label_to_index.end()){
                    graph_char_label_to_index[edge_label_] = label_counter;
                    label_counter += 1;
                    }
                    // add edge to boost graph
                    add_edge(source_vertex_, dest_vertex_, edge_char(graph_char_label_to_index[edge_label_]), graph);
                }
            }
            else
                file_counter = file_counter -1;

            inp_db_graphs.emplace_back(graph);
            map_index_to_graph_id[graph_counter] = graph_id;
            graph_counter++;
        }
        file_counter += 1;
    }
}


string get_unique_edge_name(string &vertex_1,string &vertex_2, string &edge_label){
    /*
    --> Returns the unique edge label by combining the vertices along with the existing edge
        label to get it (like a hash code).
    */
  string hash_key  = "";
  if(vertex_1 < vertex_2) 
    hash_key += vertex_1+"||"+vertex_2;
  else
    hash_key += vertex_2+"||"+vertex_1;
  return hash_key+"||"+edge_label;
}


void load_sorted_frequent_subgraphs(string subraph_file,
 vector<vector<graph_adjacency_list>> &inp_db_graphs, 
 vector<vector<std::unordered_set<int>>> &graphs_ids){
    /*
    --> Loading all the frequent subgraphs from the given file in the increasing order of their size.
    --> Here, size represents the number of edges in the subgraphs.
    */
    ifstream graph_db_file;
    graph_db_file.open(subraph_file); 
    stringstream file_content_stream;
    file_content_stream << graph_db_file.rdbuf(); 
    string content_str = file_content_stream.str(); 
    vector<string> data = split(content_str,'\n');
    
    
    int file_counter = 0;
    int graph_counter = 0;
    int temp_var;
    int max_graph_size = inp_db_graphs.size();

    while(file_counter < data.size()){
        string line = data[file_counter];
        if (line.size() > 0 && line[0] == 't'){
            graph_adjacency_list graph_;
            int gid_ , support_count;
            string str_temp;
            string gid_sub, support_count_sub;
            istringstream line_stream(line);
            line_stream >> str_temp >> str_temp >> gid_sub >> str_temp >> support_count_sub;
            gid_ = stoi(gid_sub);
            support_count = stoi(support_count_sub);

            file_counter++;
            int temp1,temp2;
            int temp3;
            while(data[file_counter][0]=='v'){
                istringstream line_stream(data[file_counter].substr(1));
                line_stream >> temp1 >> temp2;
                add_vertex(vertex_char(temp2), graph_);
                file_counter ++;
            }

            while(data[file_counter][0] =='e'){
                istringstream line_stream(data[file_counter].substr(1));
                line_stream >> temp1 >> temp2 >> temp3;
                if(temp1 > temp2){
                    int temp_var = temp1;temp1 = temp2;temp2=temp_var;
                }
                add_edge(temp1, temp2, edge_char(temp3), graph_); 
                file_counter++;
            }

            std::unordered_set<int> gids;
            if(data[file_counter][0] =='x'){
                istringstream line_stream(data[file_counter].substr(1));
                while(line_stream >> temp1){
                    gids.insert(temp1);
                }
            }

            int edge_count = num_edges(graph_);
            if (edge_count < max_graph_size){
                inp_db_graphs[edge_count].push_back(graph_);
                graphs_ids[edge_count].push_back(gids);
            }
            graph_counter++;
        }
        file_counter++;   
    }
}


void intersection_set(std::unordered_set<int> &set_1,std::unordered_set<int> &set_2){
    /*
    --> Returns intersection of 2 unordered_set type sets
    */
    vector<int> diff_;
    for(auto it: set_1){
        if(set_2.find(it) == set_2.end())
            diff_.emplace_back(it);
    }
    for(auto it:diff_)
        set_1.erase(it);
}


float get_discriminative_ratio(graph_adjacency_list &g,std::unordered_set<int> &graph_ids,vector< vector< graph_adjacency_list> > &feature_graphs,vector< vector< std::unordered_set<int>>> &feature_graph_ids){
  /*
  --> Computing discriminative ratio of the graph, which is equal to the ratio of the
      set of the graphs containing subgraphs of x to that of the set of the graphs containing x.
  */
  int total_edges = num_edges(g);
  std::unordered_set<int> cand_set;
  for(int i = 1; i <=total_edges;i++){
    for(int j = 0; j< feature_graphs[i].size();j++)
    {
      if (is_subgraph_isomorphic(feature_graphs[i][j],g)){
        if(cand_set.size() == 0)
          cand_set = feature_graph_ids[i][j];
        else
          intersection_set(cand_set,feature_graph_ids[i][j]);
      }
    }
  }
  return cand_set.size() * 1.0 / graph_ids.size();
}


string get_vectorString(vector<int> &vector_ids,string prefix_str){
    /*
    --> Creates concatenated string of integers seperated by tab delimiter and 
        each integer is prefixed by prefix_str.
    */
    std::stringstream string_stream;
    for(size_t i = 0; i < vector_ids.size(); ++i){
        if(i != 0)
            string_stream << "\t";
        string_stream << prefix_str << vector_ids[i];
    }
    std::string concat_string = string_stream.str();
    return concat_string;
}


int get_exec_time_in_ms(high_resolution_clock::time_point start){
    /*
    --> Returns the delta time from start till now in milliseconds.
    */
    auto stop = high_resolution_clock::now(); 
    auto duration = duration_cast<milliseconds>(stop - start); 
    return duration.count();
}


#endif

