graphs=$(python3.6 ./q1_convert.py $1 gspan)
graphs=$(python3.6 ./q1_convert.py $1 fsg)
graphs=$(python3.6 ./q1_convert.py $1 gaston)
python3.6 ./q1_plot.py ./output/data-gspan ./output/data-fsg ./output/data-gaston $graphs $2
