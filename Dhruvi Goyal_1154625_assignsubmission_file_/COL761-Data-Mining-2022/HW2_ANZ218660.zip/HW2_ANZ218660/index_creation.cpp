/*
--> This file contains the code to create the index structure from input graph database.
--> Note: For boost-graph, few code blocks are taken from its official 
    documentation - https://www.boost.org/doc/libs/1_63_0/libs/graph/doc/
*/

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath> 
#include <vector> 
#include <list>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <chrono>
#include <bits/stdc++.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <boost/graph/graphviz.hpp>
// #include <boost/filesystem.hpp> 
#include "utilities.h"

using namespace std::chrono; 
using namespace boost;
using namespace std;


int main(int argc, char** argv){
  /*
  --> Creating feature index of the given input graphs database, such that the querying
      database takes less time to find all the graphs that contains any query graphs.
  --> The current approach is inspired by the research paper entitled 
      "Graph Indexing: A Frequent Structure-based Approach" by Xifeng Yan, Philip S. Yu & Jiawei Han.
  */

  auto start = high_resolution_clock::now(); 

  // Parsing the arguments
  string input_db_file = argv[1];
  string frequent_subgraph_file = argv[2];

  // Declaring all the variables
  int graph_index= 0;
  int max_subgraph_size = 15;
  int total_indexed_subgraphs= 0;
  int max_subgraphs_threshold = 500;
  float min_discriminative_ratio = 1.25;
  int counter_ = 0;
  std::unordered_map<int,int> map_index_to_graph_id; // Mapping graph indices to their IDs
  std::unordered_map<string,int> graph_char_label_to_index; // Mapping vertiex/edges labels to indices
  vector<graph_adjacency_list> inp_db_graphs; // Vector of graphs (adjacency_list form)
  std::unordered_map<string, std::unordered_set<int> > graph_feature_index; // Creating a graph feature index map
  graph_adjacency_list::edge_iterator edge_index, edge_end; // Edge iterator
  vector<vector<graph_adjacency_list>> feature_subgraphs(max_subgraph_size); // Vector to store subgraphs of different sizes
  vector<vector<std::unordered_set<int>>> feature_graph_ids(max_subgraph_size); // Vector to store graph IDs containing feature subgraphs
  vector<vector<graph_adjacency_list>> frequent_feature_subgraphs(max_subgraph_size); // Vector that has all the frequent subgraphs of different sizes
  vector<vector<std::unordered_set<int>>> frequent_subgraph_ids(max_subgraph_size); // Vector that stores all graph IDs containing the corresponding frequent subgraphs
  vector<vector<int>> feature_vector; // Feature vector matrix that stores the presence of a feature in the input graph in binary form
  

  // Loading graphs from input graph database.
  load_graphs_from_db(input_db_file, inp_db_graphs, graph_char_label_to_index, map_index_to_graph_id);

  /* Creating feature subgraphs from the database for index. */
  // Save all the 1-edge subgraphs as feature subgraphs
  for(auto &g : inp_db_graphs){
      for(tie(edge_index, edge_end) = edges(g); edge_index != edge_end; ++edge_index){
        string source_vertex_ = std::to_string(get(vertex_name, g)[source(*edge_index, g)]);
        string dest_vertex_ = std::to_string(get(vertex_name, g)[target(*edge_index, g)]);
        string edge_label_ =  std::to_string(get(edge_name,g)[*edge_index]);
        string index_key  = get_unique_edge_name(source_vertex_,dest_vertex_,edge_label_);
        if(graph_feature_index.find(index_key)!= graph_feature_index.end())
          graph_feature_index[index_key].insert(graph_index);
        else{
          graph_feature_index[index_key] = std::unordered_set<int>({graph_index});
          graph_adjacency_list g;
          add_vertex(vertex_char(stoi(source_vertex_)), g);
          add_vertex(vertex_char(stoi(dest_vertex_)),g);
          add_edge(0, 1, edge_char(stoi(edge_label_)), g);
          feature_subgraphs[1].push_back(g);
        }

      }
    graph_index += 1;
  }

  // Saving all the graph IDs containing that feature subgraph of 1-edge graphs
  for(int i = 0 ; i < feature_subgraphs[1].size();i++){
    graph_adjacency_list g = feature_subgraphs[1][i];
    for(tie(edge_index, edge_end) = edges(g); edge_index != edge_end; ++edge_index){
      string source_vertex_ = std::to_string(get(vertex_name, g)[source(*edge_index, g)]);
      string dest_vertex_ = std::to_string(get(vertex_name, g)[target(*edge_index, g)]);
      string edge_label_ =  std::to_string(get(edge_name,g)[*edge_index]);
      string index_key  = get_unique_edge_name(source_vertex_,dest_vertex_,edge_label_);
      feature_graph_ids[1].push_back(graph_feature_index[index_key]);
    }
  }

  // Load all the frequent subgraphs that were mined by gSpan algorithm in the file.
  load_sorted_frequent_subgraphs(frequent_subgraph_file,frequent_feature_subgraphs,frequent_subgraph_ids);

  // Shortlist the subgraphs that will be part of the index, based on the discriminative ratio of size>=2.
  if(inp_db_graphs.size() > 50000)
    min_discriminative_ratio = 1.1;
  for(int graph_size_ =2; graph_size_<max_subgraph_size; graph_size_++){
    for(int j=0; j<frequent_feature_subgraphs[graph_size_].size(); j++){
      graph_adjacency_list g = frequent_feature_subgraphs[graph_size_][j];
      if(total_indexed_subgraphs <= max_subgraphs_threshold){
      float discriminative_val = get_discriminative_ratio(g,frequent_subgraph_ids[graph_size_][j],feature_subgraphs,feature_graph_ids);

      if( discriminative_val >= min_discriminative_ratio){
        total_indexed_subgraphs++;
        feature_subgraphs[graph_size_].push_back(g);
        feature_graph_ids[graph_size_].push_back(frequent_subgraph_ids[graph_size_][j]);
      }
      }
    }
  }

  // Creating feature vectors from the selected feature graphs for all the input DB graphs. 
  for(int p = 0; p < inp_db_graphs.size();p++){
    vector< int> temp;
    for(int i = 0; i < feature_subgraphs.size();i++){ // Looping over all the feature graphs of any size
      for(int j = 0; j< feature_subgraphs[i].size();j++) // Looping over all the size "i" feature graphs
      {
        temp.push_back(0);
      }
    }
    feature_vector.push_back(temp);
  }
  for(int i = 0; i < feature_subgraphs.size();i++){ // looping across sizes ///

    for(int j = 0; j< feature_subgraphs[i].size();j++) // looping across all graphs of size i
    {
      for (auto itr = feature_graph_ids[i][j].begin(); itr != feature_graph_ids[i][j].end(); ++itr) {
        feature_vector[*itr][counter_] = 1;
        }
        counter_ ++;
    }
  }

  /* 
    Index Created!!
    Saving all the things!!
  */
 
  // Saving the create graph feature vectors in a text file.
  ofstream feature_vector_file;
  feature_vector_file.open("feature_vectors.txt", std::ofstream::trunc);
  stringstream tmp_str;
  for(int i=0; i<feature_vector.size(); i++){
    for(int j=0; j<feature_vector[i].size(); j++){
        feature_vector_file<<to_string(feature_vector[i][j]);
    }
    feature_vector_file<<"\n";
  }
  feature_vector_file.close();

  // Creating directory to save all the feature subgraphs in it
  // bool status = boost::filesystem::create_directory("feature_graphs");
  // fs::create_directory("feature_graphs");
  int status = mkdir("feature_graphs",0777);

  // if(!status){
  //   int files_removed = boost::filesystem::remove_all("feature_graphs");
  //   // int status = mkdir("feature_graphs",0777);
  //   status = boost::filesystem::create_directory("feature_graphs");
  // }

  // Saving all the feature subgraphs in the created folder.
  for(int i=2; i<max_subgraph_size; i++){
    for(int j=0; j<feature_subgraphs[i].size(); j++){
      string fname = to_string(i) + "_" + to_string(j);
      ofstream feature_graph_file;
      feature_graph_file.open("feature_graphs/feature_graph_" + fname + ".dot", std::ofstream::trunc);
      boost::write_graphviz(feature_graph_file, feature_subgraphs[i][j]);
      feature_graph_file.close();
    }
  }

  // ifstream inp_file(input_db_file);
  // ofstream out_file;
  // out_file.open("input_graph_database.txt", std::ofstream::trunc);
  // string line_data;
  // while (getline(inp_file,line_data)){
  //   out_file << line_data << '\n';
  // }
  // out_file.close();

  cout <<"Feature vectors & index created and saved in "<<get_exec_time_in_ms(start)/6000<<" minutes"<<endl;

  return 0;

}