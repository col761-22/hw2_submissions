import os
import sys

next = 0

file_ = sys.argv[1]
algo = sys.argv[2]


temp = file_.split('.')[0]
output_name = "data-" + algo


f = open(file_, "r")
file1 = open("./output/"+output_name, "w")
refresh = 0
node = 0
last_line = ""
nodes_start = False
edges_start = False
total_nodes = 0
total_edges = 0
edge = 0
total = 0
nodes = []

if algo in ['fsg', 'gspan', 'gaston']:
    for x in f:
        if x.isspace():
            next += 1
            continue

        if edges_start is True:
            if algo == 'fsg':
                file1.write("u " + str(x))
            else:
                file1.write("e " + str(x))
            edge += 1
            if edge == total_edges:
                edge = 0
                edges_start = False

        if last_line == "writing_edges":
            total_edges = int(x)
            edges_start = True
            last_line = "no"

        if nodes_start is True:
            if str(x) not in nodes:
                nodes.append(str(x))
            file1.write("v " + str(node) + " " + str(nodes.index(str(x))) + "\n")
            node += 1
            if node == total_nodes:
                nodes_start = False
                node = 0
                last_line = "writing_edges"

        if last_line == "new_graph":
            total_nodes = int(x)
            nodes_start = True
            last_line = "writing_nodes"

        if x[0] == '#':
            last_line = "new_graph"
            if algo == 'fsg':
                file1.write("t\n")
            else:
                file1.write("t # " + str(x[1:]))
            # file1.write("t # " + str(total) + "\n")
            total += 1


file1.close()

print(str(next))


