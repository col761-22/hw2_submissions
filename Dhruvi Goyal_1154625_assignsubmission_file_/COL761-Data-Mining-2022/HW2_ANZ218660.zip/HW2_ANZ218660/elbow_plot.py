import sys
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

def get_kmeans_inertias(data, k_range):
    """
    --> Takes the n-dimensional data as input and for a range of K (number of clusters) values, 
        it performs K-Means clustering, and returns the corresponding intertia of the resultant
        clusters.
    --> Inertia in K-means clustering is computed as the sum of the squared distances between
        each data point with its corresponding cluster's centroid.
    """
    kmeans_inertias = []

    #Fitting K-Means Iteratively for Different Number of Clusters
    for num_cluster in range(k_range[0], k_range[1]+1):
        kmeans = KMeans(
            init = "k-means++",
            n_clusters = num_cluster,
            random_state = 42
        )

        cluster_labels = kmeans.fit_predict(data)
        kmeans_inertias.append(kmeans.inertia_)    #Getting Inertias of Clusters
    
    return kmeans_inertias

def save_elbow_plot(data, dimension, output_file, k_range=(1,15)):
    """
    --> It saves the elbow graph for the given range of K (Number of clusters).
    --> Default range for K values is taken as 1 to 15.
    """
    kmeans_inertias = get_kmeans_inertias(data, k_range)
    plt.plot(range(k_range[0], k_range[1]+1), kmeans_inertias, 'bx-')
    plt.xlabel('Number of Clusters')
    plt.ylabel('Intra-Cluster Variation')
    plt.title('The Elbow Method for ' + str(dimension) + 'D data using Inertia')
    plt.savefig(output_file)
    plt.close()
    
def get_file_data(file_name):
    """
    --> Reads the file data line by line and converts into nested list, 
        where each sub-list represent 1 instance and has 'n' elements for
        n-dimensional dataset.
    """
    data = []
    with open(file_name, "r") as f:
        for line in f:
            data.append([float(i) for i in line.split()])
    return data


if __name__ == '__main__':
    """
    --> Creates K-means clusters on a set of K values (1 to 15), and computes the mean intra-cluster
        distance in each of the case to plot & decide optimal K value using elbow method.
    """
    # Parsing the input arguments
    args = sys.argv[1:]
    dataset_file = args[0]
    dimension = args[1]
    output_file = args[2]
    
    # Loading the dataset
    data_ = get_file_data(dataset_file)
    
    # Saving the elbow plot of the given dataset.
    save_elbow_plot(data_,  dimension,output_file)
