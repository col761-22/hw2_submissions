python3.6 elbow_plot.py $1 $2 $3
