import matplotlib.pyplot as plt
import os, sys, time
print(sys.argv)
path = os.path.dirname(sys.argv[0])
supports = [5, 10, 25, 50, 95]
gspan = []
fsg = []
gaston = []

for support in supports:
    
    t = time.time()
    os.system(f"timeout 2h {path}/binaries/gSpan-64 -s {support/100} -f {sys.argv[1]} -o -i")
    gspan.append((time.time()-t)/60)
    
    t = time.time()
    os.system(f"timeout 2h {path}/binaries/fsg -s {support} {sys.argv[2]}")
    fsg.append((time.time()-t)/60)
    t = time.time()
    os.system(f"timeout 1h {path}/binaries/gaston {(int(sys.argv[4])*support)/100} {sys.argv[3]} {sys.argv[3]}.fp")
    gaston.append((time.time()-t)/60)

fig = plt.subplots(figsize =(10, 8))


plt.plot(supports, gspan, color = 'green',marker='o', label = 'gSpan')
plt.plot(supports, fsg, color = 'yellow',marker='o',label = 'FSG')
plt.plot(supports, gaston, color = 'red', marker='o',label = 'Gaston')

plt.title('Performance Graph')
plt.ylabel('Running Time (Minutes)')
plt.xlabel('Minimum Support')
plt.xticks([x for x in supports], [str(support) + "%" for support in supports])

plt.legend()
plt.savefig(f"{sys.argv[5]}.png")
