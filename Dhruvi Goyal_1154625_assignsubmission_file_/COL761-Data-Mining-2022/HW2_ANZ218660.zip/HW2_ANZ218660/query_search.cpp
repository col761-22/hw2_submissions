/*
--> This file contains the code to load the index structure and perform the
    query search operation.
--> Note: For boost-graph, few code blocks are taken from its official 
    documentation - https://www.boost.org/doc/libs/1_63_0/libs/graph/doc/
*/

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath> 
#include <vector> 
#include <list>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <chrono>
#include <bits/stdc++.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <boost/graph/graphviz.hpp>
// #include <boost/filesystem.hpp> 
#include "utilities.h"

using namespace std::chrono; 
using namespace boost;
using namespace std;


void load_feature_vectors(string fv_filename, vector<vector<int>> &feature_vectors){
    /*
        Loading feature vectors of the created index from the file passed
        to the variable "feature_vectors" passed as the reference parameter.
    */
    ifstream feature_vector_file;
    feature_vector_file.open(fv_filename);
    string line_data;
    int i = 0;
    while (getline(feature_vector_file,line_data)){
        vector<int> temp_vec;
        for(size_t j=0; j<line_data.length(); j++){
            temp_vec.push_back(line_data[j] - '0');
        }
        feature_vectors.push_back(temp_vec);
    }
}


void load_feature_graphs(vector<graph_adjacency_list> &inp_db_graphs, 
vector<vector<graph_adjacency_list>> &feature_subgraphs, 
string frequent_subgraph_file, int max_subgraph_size=15){
  /*
  --> Loading feature inp_db_graphs of the graph database into the "feature_graphs" variable
      that is passed as refernce parameter.
  --> Note: We tried loading back graphs using read_graphviz function, but that was resulting into errors,
      as that seemed to have various dependencies, and we tried to even build the boost library from git source
      directly and use them, but still it was resulting into multiple errors. Also, saving and retrieving graphs
      in text file using fstream had some discrepencies wrt vertex label & index. Hence, we had to lastly
      adapt the strategy of recreating feature graphs from all the other saved files required for its generation.
  --> This step just takes 1 second on Yeast dataset.
  */
  int graph_index= 0;
  int total_indexed_subgraphs= 0;
  int max_subgraphs_threshold = 500;
  float min_discriminative_ratio = 1.25;
  graph_adjacency_list::edge_iterator edge_index, edge_end;
  std::unordered_map<string, std::unordered_set<int>> graph_feature_index;
  vector<vector<std::unordered_set<int>>> feature_graph_ids(max_subgraph_size);
  vector<vector<graph_adjacency_list>> frequent_feature_subgraphs(max_subgraph_size);
  vector<vector<std::unordered_set<int>>> frequent_subgraph_ids(max_subgraph_size);
  
  // Save all the 1-edge subgraphs as feature subgraphs
  for(auto &g : inp_db_graphs){
      for(tie(edge_index, edge_end) = edges(g); edge_index != edge_end; ++edge_index){
        string source_vertex_ = std::to_string(get(vertex_name, g)[source(*edge_index, g)]);
        string dest_vertex_ = std::to_string(get(vertex_name, g)[target(*edge_index, g)]);
        string edge_label_ =  std::to_string(get(edge_name,g)[*edge_index]);
        string index_key  = get_unique_edge_name(source_vertex_,dest_vertex_,edge_label_);
        if(graph_feature_index.find(index_key)!= graph_feature_index.end())
          graph_feature_index[index_key].insert(graph_index);
        else{
          graph_feature_index[index_key] = std::unordered_set<int>({graph_index});
          graph_adjacency_list g;
          add_vertex(vertex_char(stoi(source_vertex_)), g);
          add_vertex(vertex_char(stoi(dest_vertex_)),g);
          add_edge(0, 1, edge_char(stoi(edge_label_)), g);
          feature_subgraphs[1].push_back(g);
        }

      }
    graph_index += 1;
  }

  // Saving all the graph IDs containing that feature subgraph of 1-edge graphs
  for(int i = 0 ; i < feature_subgraphs[1].size();i++){
    graph_adjacency_list g = feature_subgraphs[1][i];
    for(tie(edge_index, edge_end) = edges(g); edge_index != edge_end; ++edge_index){
      string source_vertex_ = std::to_string(get(vertex_name, g)[source(*edge_index, g)]);
      string dest_vertex_ = std::to_string(get(vertex_name, g)[target(*edge_index, g)]);
      string edge_label_ =  std::to_string(get(edge_name,g)[*edge_index]);
      string index_key  = get_unique_edge_name(source_vertex_,dest_vertex_,edge_label_);
      feature_graph_ids[1].push_back(graph_feature_index[index_key]);
    }
  }

  // Load all the frequent subgraphs that were mined by gSpan algorithm in the file.
  load_sorted_frequent_subgraphs(frequent_subgraph_file,frequent_feature_subgraphs,frequent_subgraph_ids);

  // Shortlist the subgraphs that will be part of the index, based on the discriminative ratio of size>=2.
  if(inp_db_graphs.size() > 50000)
    min_discriminative_ratio = 1.1;
  for(int graph_size_ =2; graph_size_<max_subgraph_size; graph_size_++){
    for(int j=0; j<frequent_feature_subgraphs[graph_size_].size(); j++){
      graph_adjacency_list g = frequent_feature_subgraphs[graph_size_][j];
      if(total_indexed_subgraphs <= max_subgraphs_threshold){
      float discriminative_val = get_discriminative_ratio(g,frequent_subgraph_ids[graph_size_][j],feature_subgraphs,feature_graph_ids);

      if( discriminative_val >= min_discriminative_ratio){
        total_indexed_subgraphs++;
        feature_subgraphs[graph_size_].push_back(g);
        feature_graph_ids[graph_size_].push_back(frequent_subgraph_ids[graph_size_][j]);
      }
      }
    }
  }
}


int main(int argc, char** argv){
    /*
    --> This file loads the already created feature index on graph database, and also the input graph database,
        and then saves the graphs containing the query graphs in the output file (output_anz218660.txt).
    --> For searching the query graph efficiently, it creates the feature vector for each query graph,
        and then compares the values where there are 1s in the query with that of the exiting feature vectors
        of the database, and then performs the subgraph isomorphsim test on the shortlisted candidate sets. 
    */

    // Parsing all the arguments
    string input_db_file = argv[1];
    string feature_vector_file = argv[2];
    string frequent_subgraph_file = argv[3];
    string results_filename = argv[4];
    
    // Declaring all the variables
    int max_subgraph_size = 15;
    string query_file;
    std::unordered_map<int,int> map_index_to_graph_id; // Mapping graph indices to their IDs
    std::unordered_map<string,int> graph_char_label_to_index; // Mapping vertiex/edges labels to indices
    vector<graph_adjacency_list> inp_db_graphs; // Vector of graphs (adjacency_list form)
    vector<vector<int>> feature_vectors;
    vector<vector<graph_adjacency_list>> feature_graphs(max_subgraph_size);
    std::unordered_map<int,int> query_graph_index_to_id;
    vector<graph_adjacency_list> qgraphs;
    
    // Loading the graph input database, that'll be required for finding the exact match from the candidates.
    load_graphs_from_db(input_db_file, inp_db_graphs, graph_char_label_to_index, map_index_to_graph_id);

    // Loading feature vectors of database
    load_feature_vectors(feature_vector_file, feature_vectors);
    
    // Loading feature inp_db_graphs of database
    load_feature_graphs(inp_db_graphs, feature_graphs, frequent_subgraph_file, max_subgraph_size);

    // Asking for query file and setting the timer for checking the search time
    cout << "Index Loaded! Please enter the query file: ";
    cin >> query_file;
    load_graphs_from_db(query_file, qgraphs,graph_char_label_to_index,query_graph_index_to_id);
    auto start = high_resolution_clock::now();
    
    // For each query graph, saving the graphs that contain it.
    ofstream ofout(results_filename);
    for(int i = 0; i < qgraphs.size();i++){
        // Setting timer for this query
        auto query_start = high_resolution_clock::now();

        // Creating the feature vector for this query
        graph_adjacency_list g = qgraphs[i];
        vector<int> query_feature_vector;
        
        for(int l=0; l<feature_graphs.size(); l++){
            int value_;
            for(int m=0; m<feature_graphs[l].size(); m++){
                value_=0;
                if(l <= num_edges(g)){
                    if (is_subgraph_isomorphic(feature_graphs[l][m],g)){
                        value_ = 1;
                    }
                }
                query_feature_vector.push_back(value_);
            }
        }

        // Storing the list of graphs that surely doesn't contain the query vector
        vector<int> non_candidate_graphs;
        for(int n=0; n<query_feature_vector.size(); n++){
            if (query_feature_vector[n] == 1){
                for (int r=0; r<feature_vectors.size(); r++){
                    if (feature_vectors[r][n] != 1){
                        std::vector<int>::iterator it;
                        it = std::find (non_candidate_graphs.begin(), non_candidate_graphs.end(), r);
                        if (it == non_candidate_graphs.end()){
                            non_candidate_graphs.push_back(r);
                        }
                    }

                }
            }
        }

        // Checking the subgraph-isomorphism with the graphs that are not in the non-candidate graphs list.
        vector<int> found_in_vector;
        for (int u = 0; u < inp_db_graphs.size();u++){
            std::vector<int>::iterator it;
            it = std::find (non_candidate_graphs.begin(), non_candidate_graphs.end(), u);
            if (it == non_candidate_graphs.end()){
                if (is_subgraph_isomorphic(g,inp_db_graphs[u])){
                    found_in_vector.push_back(map_index_to_graph_id[u]);
            }
            }

        }

        // Saving the graph IDs of the graphs that contains the query
        if (found_in_vector.size() > 0)
            ofout << get_vectorString(found_in_vector,"#") << endl;
        else
            ofout << endl;
        cout << "Query #" << query_graph_index_to_id[i] << " found in " << found_in_vector.size() << " graphs, and took " << get_exec_time_in_ms(query_start) << " ms." << endl;
  }
  cout << "Total time taken to search all the query graphs - " << get_exec_time_in_ms(start) << "ms." << endl;
  ofout.close();

  return 0;

}



