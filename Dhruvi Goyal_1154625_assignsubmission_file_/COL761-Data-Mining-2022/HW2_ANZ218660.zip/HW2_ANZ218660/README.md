# File Details
1) **compile.sh** - It is the file containing the commands to compile and create the binaries of all the C++ files, that is with respect to question 2. It'll be executed within the ANZ218660_install.sh file.
```
./compile.sh
```

2) **q1.sh** - It is the file with respect to running the frequent subgraph mining algorithms running time comparison of 3 algorithms - FSG, gSpan, Gaston. It takes 2 inputs, viz., as the graph dataset and the output plot file name (without extension), and runs the 3 algorithms to mine frequent subgraphs based on 5 support threshold values (5, 10, 25, 50, 95), and plots them. It calls q1_convert.py for converting dataset to the algorithm specific input formats, and then calls q1_plot.py for running all the 3 algorithms and plotting them.
```
./q1.sh graph_db.txt output_plot
```

3) **q1_convert.py** - It is the python script containing code to convert the given graph dataset (in Yeast dataset format) into the different algorithm's (FSG, gSpan, Gaston) input structure.

4) **q1_plot.py** - It is the python script containing the code to run the 3 algorithms for frequent subgraph mining and plot their time taken to run on different support thresholds.

5) **index.sh** - It is the shell script that creates the index structure from the give graph database and saves it, so as to query efficiently during search time. It calls the transform_to_gspan_format.cpp file to convert the input graph database into the gspan format, and then based on support threshold, it creates the frequent subgraphs using gSpan algorithm. Further, it calls the index_creation binary file, that creates and saved the index structure. It also saves the input graph database, that'll be required during the query time.
```
./index.sh graph_db.txt
```

6) **query,sh** - It is the shell script that calls the query_search binary file along with the inputs of index files that were created and are to be loaded, and then asks for the query graph file and saves the results (all graphs containing the given query graph) into a file.
```
./query.sh
```

7) **transform_to_gspan_format.cpp** - It is the C++ script file containing code for converting the input data into the gSpan frequent subgraph mining input format.

8) **index_creation.cpp** - It is the C++ script file containing the code to load the database and create the index, and save it. The details of the algorithm implemented in this part is provided in the report submitted.

9) **query_creation.cpp** - It is the C++ script file containing code for loading the index and database, and then asks for a query graph file, that contains all the query graphs for which the graph IDs of the graphs containing the query graphs are to be found. The detailed algorithm that is used during this phase is given in the report. It writes the output in the required format in the file - output_anz218660.txt.

10) **utilities.h** - It is the C++ script that contains all the common utility functions that are used in both index_creation.cpp and query_creation.cpp files at different places.

11) **elbow_plot.sh** - It is the shell script file that invokes elbow_plot.py code, which generates elbow plot for the given input dataset for a range of K values.
```
./elbow_plot.sh dataset.dat 3 q3_3_anz218660.png
```

12) **elbow_plot.py** - It is the python script file containing code to run the K-Means for a range of K values (1 to 15), and plots the intra-cluster intertia for varied K values (elbow plot). The results for different datasets provided with optimal K values and other details are present in the report.

13) **binaries** - It is the folder that contains the binary files of gspan, fsg & gaston algorithms that are used in question 1 and 2.

14) **output** - It is an empty folder that is used in question 1, for saving the outputs and converted structures in it.

15) **ANZ218660.pdf** - It is the report that contains the explanation for all the 3 questions.


# Team Members & Contributions
- Dhruvi Goyal - 2021ANZ8660
- Hargun Singh Grover - 2021AIZ8326
- Kirtika Sharma - 2022SRZ8379


# Contributions
- Dhruvi Goyal (33.3%) - Worked on Q3, Q2

- Hargun Singh Grover (33.3%) - Worked on Q1, Q2

- Kirtika Sharma (33.3%) - Worked on Q1, Q2
