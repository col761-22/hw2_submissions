./transform_gspan $1 "transformed_input_db.gspan"
db_size=`grep -o t transformed_input_db.gspan | wc -l`
support_threshold="0.3"
if [ $db_size -lt 25000 ]
then
        support_threshold="0.1"
elif [ $db_size -lt 50000 ]
then
         support_threshold="0.15"
elif [ $db_size -lt 75000 ]
then
         support_threshold="0.2"
fi

./binaries/gSpan-64 -f "transformed_input_db.gspan" -s $support_threshold -o -i
./index_creation $1 "transformed_input_db.gspan.fp"
cp $1 "input_graph_database.txt"
