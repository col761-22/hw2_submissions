./query_search "input_graph_database.txt" "feature_vectors.txt" "frequent_subgraphs.gspan.fp" "output_anz218660.txt"
