g++ transform_to_gspan_format.cpp -o transform_gspan -O3
g++ index_creation.cpp -I /home/apps/LIBBOOST/1.64.0/gnu_ucs71/include/ -o index_creation -O3 -lstdc++fs -lboost_filesystem -lboost_system
g++ query_search.cpp -I /home/apps/LIBBOOST/1.64.0/gnu_ucs71/include/ -o query_search -O3 -lstdc++fs -lboost_filesystem -lboost_system