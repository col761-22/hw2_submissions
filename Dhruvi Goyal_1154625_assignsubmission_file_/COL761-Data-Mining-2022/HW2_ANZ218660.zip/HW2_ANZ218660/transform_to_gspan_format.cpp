#include <fstream>
#include <string>  
#include <vector> 
#include <list>
#include <unordered_map>
#include <unordered_set>
#include <set>
#include<cmath>
#include<string>
#include<sstream>
#include<iostream>
using namespace std;

//splitting the strings 

vector<std::string> splitString(std::string &strToSplit, char delimeter)
{
    std::stringstream ss(strToSplit);
    std::string item;
    std::vector<std::string> stringSplitted;
    while (std::getline(ss, item, delimeter))
    {
       stringSplitted.push_back(item);
    }
    return stringSplitted;
}
int main(int argc, char** argv){

        ios_base::sync_with_stdio(false);
        string input_File = argv[1];
        string output_File = argv[2];
        ifstream inFile;
        inFile.open(input_File); 
        stringstream strStream;
        strStream << inFile.rdbuf(); 
        string str = strStream.str(); 

        vector<string> input_data = splitString(str,'\n');

        ofstream ofile(output_File);  
        unordered_map<string, int> label_to_count;
        int label_count  = 1;
        int file_count  = 0;

        while(file_count < input_data.size()){

                string line = input_data[file_count];
                if (line.size() > 0 && line[0] == '#'){
                        string graphID = line.substr(1);
                        int num_of_nodes = 0;
                        int num_of_edges = 0;
                        
                        ofile << "t # " << graphID << "\n";
                        file_count++;
                        num_of_nodes = stoi(input_data[file_count]);

                        for(int i =0;i < num_of_nodes;i++){
                                file_count++;
                                string label = input_data[file_count];
                                if(label_to_count.find(label) == label_to_count.end()){
                                label_to_count[label] = label_count;
                                label_count++;
                                }
                                ofile << "v " << i << " "  << label_to_count[label] << "\n";
                        }

                        file_count++;
                        num_of_edges = stoi(input_data[file_count]);
                        for(int i = 0;i < num_of_edges;i++){
                                int starting_node;
                                int ending_node;
                                string label_of_edge;
                                file_count ++;
                                istringstream line_stream(input_data[file_count]);
                                line_stream >> starting_node >> ending_node >> label_of_edge;
                                if (starting_node > ending_node){
                                int tmp = starting_node;
								starting_node = ending_node; 
								ending_node =tmp;
                                }

                                if(label_to_count.find(label_of_edge) == label_to_count.end()){
                                label_to_count[label_of_edge] = label_count;
                                label_count += 1;
                                }
                                ofile << "e " << starting_node <<" " << ending_node << " " << label_to_count[label_of_edge] << "\n";
                        }
                }
                file_count += 1;
        }
}