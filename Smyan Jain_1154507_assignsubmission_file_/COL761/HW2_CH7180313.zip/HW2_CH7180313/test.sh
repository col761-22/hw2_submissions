#!/bin/sh

cd /home/dbeb/btech/bb1180031

./gSpan-64.dms -f yeast_gspan.txt -s 0.05 > q1/output_gSpan.txt
./gSpan-64.dms -f yeast_gspan.txt -s 0.1 >> q1/output_gSpan.txt
./gSpan-64.dms -f yeast_gspan.txt -s 0.25 >> q1/output_gSpan.txt
./gSpan-64.dms -f yeast_gspan.txt -s 0.5 >> q1/output_gSpan.txt
./gSpan-64.dms -f yeast_gspan.txt -s 0.95 >> q1/output_gSpan.txt

./pafi-1.0.1/Linux/fsg -s 5 yeast_gspan.txt > q1/output_fsg.txt
./pafi-1.0.1/Linux/fsg -s 10 yeast_gspan.txt >> q1/output_fsg.txt
./pafi-1.0.1/Linux/fsg -s 25 yeast_gspan.txt >> q1/output_fsg.txt
./pafi-1.0.1/Linux/fsg -s 50 yeast_gspan.txt >> q1/output_fsg.txt
./pafi-1.0.1/Linux/fsg -s 95 yeast_gspan.txt >> q1/output_fsg.txt

./gaston 3206 yeast_gspan.txt > q1/output_gaston.txt
./gaston 6411 yeast_gspan.txt >> q1/output_gaston.txt
./gaston 16028 yeast_gspan.txt >> q1/output_gaston.txt
./gaston 32055 yeast_gspan.txt >> q1/output_gaston.txt
./gaston 60905 yeast_gspan.txt >> q1/output_gaston.txt





# printf "Type three numbers separated by 'q'. -> "
# IFS="q"
# read NUMBER1 NUMBER2 NUMBER3
# echo "You said: $NUMBER1, $NUMBER2, $NUMBER3"
