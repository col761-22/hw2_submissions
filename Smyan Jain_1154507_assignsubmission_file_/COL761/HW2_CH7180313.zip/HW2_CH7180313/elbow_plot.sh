module load apps/pytorch/1.6.0/gpu/anaconda3
python kmeans.py $1 $3
module unload apps/pytorch/1.6.0/gpu/anaconda3