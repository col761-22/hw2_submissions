# -*- coding: utf-8 -*-
"""
Created on Fri May 13 14:48:07 2022

@author: smyan
"""
import sys
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

data_file = sys.argv[1]
X = []
inert = []

with open(data_file, 'r') as f:
    X = [list(map(float, temp.split())) for temp in f.readlines()]
    f.close()

for i in range(1, 16):
    model = KMeans(init = "random", n_clusters = i)
    model.fit(X)
    inert.append(model.inertia_)

plt.plot(range(1, 16), inert, 'bo-')
plt.xlabel('Number of clusters')
plt.ylabel('Sum of squared distances')
plt.title("For %iD dataset"% len(X[0]))
plt.savefig(sys.argv[2])
