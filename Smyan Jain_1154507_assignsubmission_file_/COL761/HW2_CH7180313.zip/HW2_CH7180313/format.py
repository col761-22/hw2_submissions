filename = "167.txt_graph"

F = open(r"167.txt_graph", 'r')
F_write = open(r"yeast_formatted.txt", 'w+')

t = F.readline()

while(t):

	if (t[0] == '#'):

		F_write.write('t # ' + t[1:])

		v = int(F.readline())

		Nodes = set()

		for i in range (0, v):
			node_label = F.readline()
			Nodes.add(node_label)

			F_write.write("v " + str(i) + " " + str(ord(node_label[0])) + '\n')

		e = int(F.readline())

		for i in range (0, e):
			edge = F.readline()
			F_write.write("e " + edge)

	# print(t)
	t = F.readline()

print(t)
print ("End")
