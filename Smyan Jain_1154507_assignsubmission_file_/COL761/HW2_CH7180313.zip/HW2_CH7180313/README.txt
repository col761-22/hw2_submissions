Entry numbers -

Smyan Jain - 2018CH7180313
Pushpit Srivastava - 2018BB10031

Contribution -

Smyan Jain - 50%
Pushpit Srivastava - 50%

File Description - 

format.py - used to format yeast dataset
gSpan-64.dms - binary file to execute gSpan
fsg - unix executable to run FSG on datasets
gaston-1.1 - Folder which contains source code for Gaston. 
gaston-1.1/gaston - compiled code for Gaston
167.txt_graph - Yeast dataset (unformatted)
yeast_formatted.txt - Yeast dataset (formatted)
test.sh - shell script used to run gSpan, FSG and Gaston on HPC
CH71***2D.dat
CH71***3D.dat
CH71***4D.dat - generated data sets for Q3
kmeans.py - takes iput from data file, performs kmeans clustering and plots elbow plot in the target file.
elbow_plot.sh - file as mentioned in the hw description
