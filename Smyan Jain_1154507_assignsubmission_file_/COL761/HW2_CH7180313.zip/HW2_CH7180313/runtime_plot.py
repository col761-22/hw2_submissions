import matplotlib.pyplot as plt

gspan = [4019, 1144.4, 281.9, 103.6, 5.3]
fsg = [3692.4, 1215, 331, 105.5, 2.0]
gaston = [257.28, 84.14, 25.26, 10.84, 1.16]
sups = [5, 10, 25, 50, 95]
f = lambda x: str(x) + '%'
sups = list(map(f, sups))

g_st = [i for i in range(1, 6)]
f_st = [i + 0.25 for i in g_st]
gast = [i + 0.5 for i in g_st]

kargs = {'width': 0.25, 'edgecolor': 'k'}

plt.bar(g_st, gspan, color='r', label='gSpan', **kargs)
plt.bar(f_st, fsg, color='g', label='FSG', **kargs)
plt.bar(gast, gaston, color='b', label='gaston', **kargs)

plt.title('Runtime graph')
plt.ylabel('Running time (secs)')
plt.xlabel('Min support')

plt.xticks(f_st, sups)

plt.legend()
plt.savefig('runtimes.png')