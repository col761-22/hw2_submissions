#!/bin/bash

echo "Sorry, we could not complete this question because we could not get VFI to run with edge labels."

