#importing the necessary libraries
import pandas as pd
import numpy as np
from collections import Counter
import networkx as nx
import time
import sys
import pickle

#Reading the data set from command line
my_file = open(sys.argv[1], 'r')

content = my_file.read()

#splitting the data set into list as per new lines
data = content.split('\n')
my_file.close()

print("Building Indexes....")

#Initiallising feature vector
feature=[]
for i in range(len(data)):
  f=[]
  if '#' in data[i]: #Identifying tids
    G = nx.DiGraph() #Initializing Graph DS
    v =Counter() #Initializing Counter
    e=Counter()
    f.append(data[i])
    c=int(data[i+1])
    
    v.update(data[i+2:i+2+c]) 
  
    f.append(c)
    
    cc=data[i+2:i+2+c]
    for j in range(len(cc)):
      G.add_node(j,label=cc[j]) #Adding Nodes to graph
    
    i+=c+2


    c=int(data[i])
    cc=data[i+1:i+1+c]
    for j in cc:
      l=[]
      for k in j:
        if(k!=' '):
          l.append(k)   
      e.update(l[2])
    f.append(int(data[i]))

    for j in cc:
      j=j.split()
      G.add_edge(int(j[0]),int(j[1]),label=j[2]) #Adding edges to graph

    
   
    f.append(v)
    f.append(e)
    f.append(G)
    i+=c+2
    feature.append(f) #Adding feature to the feature vector
  

feature=np.array(feature) 


with open("index", "wb") as fp:pickle.dump(feature, fp) #Storing index into pickle file

print("Index build successfully")