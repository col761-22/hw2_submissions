g++ -o q1/FSG/script_fsg q1/FSG/script_fsg.cpp
g++ -o q1/Gaston/script_gaston q1/Gaston/script_gaston.cpp
g++ -o q1/gSpan/script_gspan q1/gSpan/script_gspan.cpp

python3 q1/plot.py $1 $2
