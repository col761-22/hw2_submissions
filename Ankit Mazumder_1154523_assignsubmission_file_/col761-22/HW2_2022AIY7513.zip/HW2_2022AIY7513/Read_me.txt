Steps to run:

1.For Q1 run Q1.sh <datafilename> <o/p plot name>

2.For Q2 run :
a.Q2.sh <datafile name>
b.Query.sh (Wait for loading index & then input Query file name when asked)

3.For Q3 run:
elbow.sh <datafile name> <dimention> <o/p plot name>

Note:All inputs of file names must include the file formats along with filename.

Ankit Mazumder {2022AIY7513}  47.5 % contribution
Chintapalli Sachin {2022AIB2672}  5% contribution
Aman Pawar {Project Associate} 47.5 % contribution

