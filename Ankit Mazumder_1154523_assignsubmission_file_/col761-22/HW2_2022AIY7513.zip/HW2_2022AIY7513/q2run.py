import pandas as pd
import numpy as np
from collections import Counter
import networkx as nx
import time
import sys
import pickle

def compare(f1,f2): #Compare function pruning according to feature vector
  if f1[1]<f2[1]:return 0
  if f1[2]<f2[2]:return 0
  for i in f2[3]:
    if f2[3][i]>f1[3][i]:return 0
  for i in f2[4]:
    if f2[4][i]>f1[4][i]:return 0
  return 1    

print("Retriving index")
with open("index", "rb") as fp:feature = pickle.load(fp)
print("Index retrived successfully")
x = str(input('Enter the query file:'))

my_file = open(x, 'r') #Read Query file 

content = my_file.read()

data = content.split('\n')
my_file.close()

feature2=[] 
for i in range(len(data)): #Converting query file into feature vector 
  f=[]
  if '#' in data[i]:
    G = nx.DiGraph() #Identifying tids
    v =Counter()  #Initializing Graph DS
    e=Counter() #Initializing Counter
    f.append(data[i])
    c=int(data[i+1])
    
    v.update(data[i+2:i+2+c])
    
    # print(data[i+2:i+2+c])
    # print(len(data[i+2:i+2+c]))
    # print(c)
    
    f.append(c)
    
    cc=data[i+2:i+2+c]
    for j in range(len(cc)):
      G.add_node(j,label=cc[j]) #Adding Nodes to graph
    
    i+=c+2


    c=int(data[i])
    cc=data[i+1:i+1+c]
    for j in cc:
      l=[]
      for k in j:
        if(k!=' '):
          l.append(k)   
      e.update(l[2])
    f.append(int(data[i]))

    for j in cc:
      j=j.split()
      G.add_edge(int(j[0]),int(j[1]),label=j[2]) #Adding edges to graph

    
    # print(data[i+1:i+1+c])
    # print(len(data[i+1:i+1+c]))
    # print(c)
    
    f.append(v)
    f.append(e)
    f.append(G)
    i+=c+2
    feature2.append(f) #Adding feature to the feature vector

f = open("output_2022AIY7513.txt", "w") #Creating Output File
final=[]  
timer=[]
a=0
for i in feature2:
  print("Query {} is under process...".format(a+1)) 
  cr=time.time()
  gid=[]
  for j in feature:
    if(compare(j,i)):
      GM = nx.isomorphism.GraphMatcher(j[5],i[5])
      if GM.subgraph_is_isomorphic():gid.append(j[0])  #Checking subgraph isomorphism using VF2 algorithm
  cr=time.time()-cr #Storing time  
  final.append(gid) 
  timer.append(cr)
  for items in gid:f.write('%s' %items)
  f.write("\nQuery took:"+str(timer[a])+'s') #Printing query time
  a+=1
f.write('\nTotal time:'+str(sum(timer))+'s') #Total query time
f.close()