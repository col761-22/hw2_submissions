#include<bits/stdc++.h>
using namespace std; 
 //converting the given graph file into desired format for input in fsg
int main(int argc, char **argv)
{
	string graph_id;
	int tid = 0,vertice,edge;
	int vert1,vert2,labele;
	char ch;
	string label;
	freopen(argv[1], "r", stdin);
	freopen(argv[2], "w", stdout);
	while(cin>>graph_id)
	{

		cout<<"t # "<<tid<<endl; //Storing tid of every graph
		tid ++;
		cin>>vertice; 
		for(int i=0;i<vertice;i++)
		{
			cin>>label; 
			cout<<"v "<<i<<" "<<label<<endl; //Storing vertex as well as vextex labels in the file
		}
		cin>>edge;
		while(edge--)
		{
			cin>>vert1>>vert2>>labele;
			cout<<"u "<<vert1<<" "<<vert2<<" "<<labele<<endl; //Storing edges as well as edge labels in the file
		}
	}
	return 0;
}
