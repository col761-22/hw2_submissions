import matplotlib.pyplot as plt
import subprocess
import time
import sys
import os

# Thresholds in %
threshold = [5,10,25,50,95]

# Start time for each Threshold
start_time_fsg = []
start_time_gaston = []
start_time_gspan = []

# End time for each Threshold
end_time_fsg = []
end_time_gaston = []
end_time_gspan = []

# Preprocessing of the data file for FSG, Gaston & Gspan
print("Processing the file for FSG")
subprocess.run([".FSG/script_fsg",sys.argv[1],"FSG/data_file.txt"])
print("Processing the file for Gaston")
subprocess.run([".Gaston/script_gaston",sys.argv[1],"Gaston/data_file.txt"])
print("Processing the file for gSpan")
subprocess.run([".gSpan/script_gspan",sys.argv[1],"gSpan/data_file.txt"])
print("Processing of the file completed")

for i in threshold:
        start_time_gspan.append(time.time())
        subprocess.run([".gSpan/gSpan-64","-s",str(i/100),"-f","gSpan/data_file.txt"])  #Calculating the time on the given thresholds
        end_time_gspan.append(time.time())

for i in threshold:
	start_time_fsg.append(time.time())
	subprocess.run([".FSG/fsg","-s",str(i),"FSG/data_file.txt"]) #Calculating the time on the given thresholds
	end_time_fsg.append(time.time())

for i in threshold:
        start_time_gaston.append(time.time())
        subprocess.run([".Gaston/gaston",str(i),"Gaston/data_file.txt"]) #Calculating the time on the given thresholds
        end_time_gaston.append(time.time())


time_gspan=[]

for i in range(len(threshold)):
        time_gspan.append(end_time_gspan[i] - start_time_gspan[i])

print(time_gspan)        

time_fsg=[]

for i in range(len(threshold)):
	time_fsg.append(end_time_fsg[i] - start_time_fsg[i])
 
print(time_fsg) 

time_gaston=[]

for i in range(len(threshold)):
        time_gaston.append(end_time_gaston[i] - start_time_gaston[i])       

#ploting
plt.figure(figsize=(10,7))
plt.plot(threshold,time_gspan,lw=2, color='b', linestyle='dashdot',  marker='o',label = '$GSPAN$')
plt.plot(threshold,time_fsg,lw=2, color='g', linestyle='dashdot',  marker='o',label = '$FSG$')
plt.plot(threshold,time_gaston,lw=2, color='r', linestyle='dashdot',  marker='o',label = '$GASTON$')

plt.xlabel('Support threshold %',fontweight='bold')
plt.ylabel('Running time (sec)',fontweight='bold')

plt.legend(loc='upper right')
plt.title('Support threshold vs running time',fontweight='bold')
plt.tight_layout()
plt.savefig(f"{sys.argv[2]}.png")
