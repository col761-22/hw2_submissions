python q3/q3.py $1 $2 $3
