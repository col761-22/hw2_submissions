#!/bin/bash
g++ apriori.cpp -O3 -o apriori -std=c++11
g++ fptree.cpp -O3 -o fptree -std=c++11
echo "Enter i/p & o/p filenames only, without the file extension name."
