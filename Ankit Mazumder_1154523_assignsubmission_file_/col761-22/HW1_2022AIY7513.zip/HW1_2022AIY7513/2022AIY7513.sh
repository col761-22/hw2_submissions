#!/bin/bash
if [ $1 == "-apriori" ]
 then
	./apriori $2 $3 $4
elif [ $1 == "-fptree" ]
 then
 	./fptree $2 $3 $4
elif [ $1 == "-plot" ]
 then
	python3 plot.py $2
else
	echo "Invalid input"
fi