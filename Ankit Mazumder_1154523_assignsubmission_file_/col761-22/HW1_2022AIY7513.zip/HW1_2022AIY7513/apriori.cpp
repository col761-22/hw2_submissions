#pragma warn -rvl
#include<bits/stdc++.h>
using namespace std;
struct candidate {
    set<int> itemset;
    long double frequency;
    long  int count;
};
bool subset_check(set<int>,int, vector<candidate>);
vector<candidate> candidate_gen(vector<candidate>);
bool not_in(vector<candidate>, candidate);
void apriori(string,string,double);

bool subset_check(set<int> itemset, int excluded, vector<candidate> frequent_set) {
    itemset.erase(excluded);
    bool result = false;
    for(auto candidate: frequent_set) {
        if (candidate.itemset == itemset) {
            result = true;
            break;
        }
    }
    return result;
}

vector<candidate> candidate_gen(vector<candidate> frequent_set){
    vector<candidate> ck;
    for(auto f1 = frequent_set.begin(); f1 != frequent_set.end(); f1++){
        for (auto f2 = f1 + 1; f2 != frequent_set.end(); f2++) {
            set<int> diff;
            set_difference(f2->itemset.begin(), f2->itemset.end(), f1->itemset.begin(), f1->itemset.end(), inserter(diff, diff.end()));
            if (diff.size() == 1) {
                candidate c;
                c.count = 0;
                c.frequency = 0.0;
                set_union(f1->itemset.begin(), f1->itemset.end(), diff.begin(), diff.end(), inserter(c.itemset, c.itemset.end()));
                bool result = true;
                for(auto &excluded : c.itemset) {
                    result = subset_check(c.itemset, excluded, frequent_set);
                    if (result == false) {
                        break;
                    }
                }
                if(result == true) {
                    if (not_in(ck, c))
                        ck.push_back(c);
                }
            }
        }
    }
    return ck;
}

bool not_in(vector<candidate> ck, candidate c) {
    bool result = true;
    for(auto &elem : ck) {
        if (elem.itemset == c.itemset){
            result = false;
            break;
        }
    }
    return result;
}
typedef std::vector<vector<candidate>> vec_vec_cand;
typedef std::unordered_map<int, long double> umap_int_ld;
typedef std::vector<candidate> vec_cand;
typedef std::set<int> s_int;
void apriori(string infilename,string outfilename, long double support_threshold){
//support_threshold=0.7;
//infilename="test2.dat";
    umap_int_ld C1;
    ifstream inputFile;
    inputFile.open(infilename);
    if (!inputFile) {
        printf("Unable to open the file");
        exit(0);
    }
    
    long absolute_count = 0;
    string str;
    int item;
    while(getline(inputFile, str)) {
        absolute_count++;
        istringstream integers(str);
        while(integers >> item) {
            if(C1[item] > 0) {
                ++C1[item];
            }
            else{
                C1[item] = 1;
            }
        }
    }
    vec_vec_cand frequent_sets;
    vec_cand F1;
    for(auto it = C1.begin(); it != C1.end(); it++) {
        double frequency = it->second * 1.0 / absolute_count;
        if (support_threshold <= frequency) {
            candidate c;
            c.itemset.insert(it->first);
            c.count = it->second;
            c.frequency = frequency;
            F1.emplace_back(c);
        }
    }
    frequent_sets.push_back(F1);
    while(1){
        vec_cand ck= candidate_gen(frequent_sets[frequent_sets.size() -1]);
        inputFile.clear();
        inputFile.seekg(0, inputFile.beg);

        while(getline(inputFile, str)) {
            istringstream integers(str);
            s_int transaction;
            int x;
            while(integers >> x) {
                transaction.insert(x);
            }
           // sort(transaction.begin(), transaction.end(), &newSortFunction);
            for(auto &cand : ck) {
                if(includes(transaction.begin(), transaction.end(), cand.itemset.begin(), cand.itemset.end())) {
                    cand.count++;
                }
            }
        }
        vec_cand frequent_set;

        for(auto &cand: ck) {
            cand.frequency = cand.count * 1.0 / absolute_count;
            if (support_threshold<=cand.frequency) {
                frequent_set.push_back(cand);
            }
        }

        if(frequent_set.size() == 0)break;
        else
        frequent_sets.push_back(frequent_set);

    }
    //outfilename="output2.txt";
    ofstream outputFile;
    outputFile.open(outfilename);
   // sort(frequent_sets.begin(),frequent_sets.end());
    for(auto &frequent_set : frequent_sets) {
        for(auto &cand : frequent_set) {
            for(auto &item : cand.itemset) {
                outputFile << item << " ";
            }
            outputFile << "\n";
        }
    }
    outputFile.close();
    inputFile.close();

}
main(int argc, char* argv[]) {
    long double threshold = stoi(argv[2]) * 1.0 / 100;
    string in = string(argv[1]);
    string out = string(argv[3]);
    apriori(in+".dat", out + ".dat", threshold);
    return 0;
}


