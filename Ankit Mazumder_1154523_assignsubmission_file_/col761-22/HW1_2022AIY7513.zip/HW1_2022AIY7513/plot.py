from matplotlib import pyplot as plt
import timeit
import sys
import subprocess


inputfile = sys.argv[1]
thresholds_in_percent = [1,5,10,25,50,90]



time_apriori, time_fptree =[], []


for i in thresholds_in_percent:
    time_apriori.append(timeit.timeit("subprocess.run(\"./apriori "+ inputfile +" "+ str(i) + " op1\", shell=True)", setup = "import subprocess", number=1))
    time_fptree.append(timeit.timeit("subprocess.run(\"./fptree " + inputfile +" "+ str(i)  + " op2\", shell=True)", setup = "import subprocess", number=1))

plt.figure(figsize=(14,7))
plt.title('Apriori vs FP-Tree Execution time comparison', fontweight='bold')
plt.xlabel('Support threshold', fontweight='bold')
plt.ylabel('Execution Time (s)', fontweight='bold')
plt.plot(thresholds_in_percent, time_apriori, label='Apriori', lw=2, color='r', linestyle='dashdot',  marker='o', markerfacecolor='green', markersize=12)
plt.plot(thresholds_in_percent, time_fptree, label='FP-Tree', lw =2, color = 'b', linestyle='dashdot',  marker='o', markerfacecolor='green', markersize=12)

plt.tight_layout()
plt.legend()
plt.show()
plt.savefig('Comparision_FPtree_vs_Apriori.png', dpi=900, bbox_inches='tight')