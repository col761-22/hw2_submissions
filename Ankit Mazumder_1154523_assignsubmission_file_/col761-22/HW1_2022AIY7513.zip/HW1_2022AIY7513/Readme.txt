# COL 761 Data Mining HomeWork -I
Team : Outliers

Members and their Contributions:
1. Aman Pawar <Project Associate> <33.5%> <Fp_tree implementation>
2. Ankit Mazumder <2022AIY7513> <33.5%> <Apriori implementation>
3. Chintapalli Sachin <2022AIB2672> <33%> <Comparison Plot, Bash Scripting>

## The repository contains the following files:

### (1) compile.sh:
Upon execution it compiles the code and forms 2 files:
 a.apriori
 b.fptree

### (2) 2022AIY7513.sh:

As per the instructions:
Executing the command “./<RollNo>.sh -apriori <dataset_name> X <outputFilename>” should
generate an output text file containing the frequent itemset at >=X% support threshold with the
Apriori algorithm. Similarly “./<RollNo>.sh -fptree <dataset_name> X <output filename>”
should use FP- Tree. Notice that X is in percentage and not the absolute count.

output.dat follows the following format: 
1. Each frequent item set is on a new line.
2. The items in each item set are space-separated.
3. Items are sorted lexicographically.


### (3) Apriori.cpp:
Here code for Apriori algorithm is written.The main() takes 3 command line arguments(i/p file name, threshold & output file name).Only i/p and o/p file names only without any extension name.Ex:If i/p filename is test2.dat only enter the i/p file name i.e test2 as an argument.Threshold is in % example:If threshold=60% then enter 60 as an argument.

### (4) FP_Tree.cpp
Here code for Fp tree algorithm is written.The main() takes 3 command line arguments(i/p file name, threshold & output file name).Only i/p and o/p file names only without any extension name.Ex:If i/p filename is test2.dat only enter the i/p file name i.e test2 as an argument.Threshold is in % example:If threshold=60% then enter 60 as an argument.

### (5) Comparision_of_algo.py

Executing the command “./<RollNo>.sh -plot webdocs.dat <output_filename>” should generate
an output ".png" file with the name as specified in the command line argument. Output file contains a
plot using matplotlib where the x axis varies the support threshold, and the y-axis contains the
corresponding running times. It should plot the running times of FP-tree and Apriori algorithms
at support thresholds of 5%, 10%, 25%, 50%, and 90%

### Performance of FP-growth v/s Apriori

1. We note that FP-growth takes less time to run than the Apriori method. 
2. Additionally, the running times of both Apriori and FP-growth decrease with an increase in the support threshold. 
3. FP-decline growth is less pronounced than Apriori's.
4. Due to the growing number of candidate sets in Apriori, the pattern matching process of comparing candidate sets with transactions becomes costly. 
5. As more candidates are created, more memory space is needed for them. As it needs always keeping all k and k 1 item sets in memory (for k > 1), the breadth first search method can be rather memory-intensive.
6. However, there is no candidate generation in the fp-tree, therefore it uses less memory. It eliminates the requirement to figure out the pairs to be tallied (which requires expensive computation). 
7. The database is compressed and kept in memory via the FP-Growth method.
8. The fact that the fp-growth algorithm only investigates the frequent itemsets in the search space avoids taking into account numerous itemsets that do not occur in the database, or uncommon itemsets.
9. More search space is required as the number of things rises, and Apriori's I/O will likewise go up. When compared to fp-growth, apriori necessitates more database scans since new candidates are created more often. But FP- tree just needs 2 DB scans. Therefore, fp-growth is significantly more efficient computationally.
10. The temporal complexity of Apriori, where m is the number of unique items and n is the number of transactions, is another drawback. It is O(m2 * n). As opposed to Apriori, the fp-growth method is O(n), which is substantially quicker.
