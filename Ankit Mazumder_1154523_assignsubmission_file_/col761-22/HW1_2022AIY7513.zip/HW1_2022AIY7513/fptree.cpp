#include<bits/stdc++.h>

using namespace std;
map<int, int> global_order;
map<int, int>* global_count_map;
int num_transactions;
float minsup;
ofstream ofile;
class Node
{
public:
	int item;
	int count;
	Node* parent;
	vector<Node*> children;
 
	Node()
	{
		item = -1;
	}
	Node(int id, int c, Node* par)
	{
		item = id;
		count = c;
		parent = par;
	}

};
bool sortFunction(const pair<int,int> second,const pair<int,int> first)
{
	if(first.second > second.second)
  return 1;
  return 0;
}

bool newSortFunction(const pair<int,int> second,const pair<int,int> first)
{
	if((*global_count_map)[first.first] > (*global_count_map)[second.first])
		return 1;
	else if((*global_count_map)[first.first] == (*global_count_map)[second.first])
	{
		if(global_order[first.first] < global_order[second.first])
			return 1;
	}
	return 0;
}

bool filterFunction(const pair<int, int> elem)
{
	return ( ((elem.second * 1.0)/ num_transactions)< minsup);
}

bool filterByMap(const pair<int, int> elem)
{
	return ( ((*global_count_map)[elem.first]*1.0)/num_transactions < minsup);
}

/*void printItem(vector<int> items)
{
int i=0;
	for(; i < items.size(); i++)
		ofile << items[i] << " ";
	ofile << endl;
}*/

void createFPTree(vector<pair<int, int> > transactions, Node* tree, map<int, vector<Node*> >* headerTable)
{
	Node* curNode = tree;
	//vector<pair<int,int> >::iterator it;
	auto it = transactions.begin();
  for(; it != transactions.end(); it++)
	{
	//	vector<Node*>::iterator it1;
		bool found = 0;
   auto it1 = (*curNode).children.begin();
		for(; it1 != (*curNode).children.end(); it1++)
		{
			if((**it1).item == (*it).first)
			{
				found = 1;
				break;
			}
		}

		if(found) 
		{
			(**it1).count += (*it).second;
			curNode = *it1;
		}

		if(!found)
		{
			Node* new_node = new Node( (*it).first, (*it).second, curNode );
			(*curNode).children.push_back(new_node);
			(*headerTable)[(*it).first].push_back(new_node);
			curNode = new_node;
		}
	}
}
void FPGrowth(vector<Node*> node_list, vector<int> candidate_set )
{
	int count = 0;
  int i;
	for(i = 0; i < node_list.size(); i++)
		count += node_list[i]->count;
   bool ys=minsup<=(count*1.0/num_transactions);
	if(ys)
	{
    map<int, int> item_count;
		candidate_set.push_back(node_list[0]->item);
   
   int i=0;
	for(; i < candidate_set.size(); i++)
		ofile << candidate_set[i] << " ";
	ofile << endl;
   
		//printItem(candidate_set);
		for(i = 0; i < node_list.size(); i++)
		{
			Node* next_item = node_list[i]->parent;
			while(next_item->item != (-1))
			{
				item_count[next_item->item]=node_list[i]->count+item_count[next_item->item];
				next_item = next_item->parent;
			}
		}

		global_count_map = &item_count;

		vector<pair<int,int> > new_flist(item_count.begin(), item_count.end());
		new_flist.erase(remove_if(new_flist.begin(), new_flist.end(), &filterFunction ) , new_flist.end());
		sort(new_flist.begin(),new_flist.end(), &newSortFunction);
		Node new_tree;
		map<int, vector<Node*> > new_headerTable;
   // int i;
		for(i = 0; i < node_list.size(); ++i)
		{
			vector<pair<int, int> > transactions;
			Node* next_item = node_list[i]->parent;
			while(next_item->item != -1)
			{
				if(minsup<=(item_count[next_item->item]*1.0/num_transactions) )
				{
					transactions.push_back( make_pair(next_item->item, node_list[i]->count));
				}
				next_item = next_item->parent;
			}
			sort(transactions.begin(), transactions.end(), &newSortFunction);
			createFPTree(transactions, &new_tree, &new_headerTable);
		}

		for(i = new_flist.size()-1 ; i >= 0; --i)
		{
			FPGrowth(new_headerTable[new_flist[i].first],candidate_set);
		}

	}
}

int main(int argc, char* argv[])
{	
	if(argc !=4)
	{
		printf("Please enter 3 arguments\n");
		exit(0);
	}

	string input_file, output_file;
	ifstream inFile;
	map<int,int> count_map;

	input_file = string(argv[1])+".dat";
	minsup = (stoi(argv[2])*1.0) / 100;
	output_file = string(argv[3]) + ".dat";

	inFile.open(input_file);
	if(!inFile)
	{
		printf("File Doesn't exists\n");
		exit(1);
	}
	
	num_transactions = 0;
	string line;
	while(getline(inFile, line))
	{
		num_transactions++;
		istringstream iss(line);
		for(string s; iss >> s; )
			count_map[stoi(s)]++;
	}
	inFile.close();

	vector<pair<int,int> > flist(count_map.begin(), count_map.end());
	flist.erase(remove_if(flist.begin(), flist.end(), &filterFunction ) , flist.end());
	sort(flist.begin(),flist.end(),&sortFunction);
	int i = 0;
  for(; i < flist.size(); i++)
		global_order[flist[i].first] = i;

	global_count_map = &count_map;

	map<int,vector<Node*> > headerTable;
	Node tree;
 int check = 1;
	inFile.open(input_file);
	while(getline(inFile, line))
	{
    
		vector<pair<int,int> > transaction_items;
   istringstream iss(line);
   string s;
		for(; iss >> s; )
		{
			int item = stoi(s);
			if( (count_map[item]*1.0 / num_transactions) >= minsup)
				transaction_items.push_back( make_pair(item, 1));
		}
		sort(transaction_items.begin(), transaction_items.end(), &newSortFunction);
		createFPTree(transaction_items, &tree, &headerTable);
		check++;
	}
 i = flist.size()-1;
	ofile.open(output_file);
 
	for(; i >= 0; i--)
		FPGrowth(headerTable[flist[i].first], vector<int>());
	ofile.close();

}