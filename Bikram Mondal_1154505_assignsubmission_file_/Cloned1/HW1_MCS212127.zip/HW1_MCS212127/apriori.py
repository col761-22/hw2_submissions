# from collections import OrderedDict
import sys, time
from sortedcontainers import SortedList, SortedSet, SortedDict
st=time.time()
def apriori(T,minsup):
    C1=SortedDict() #Candidate set of size 1
    n=0
    for x in T:
        op=[]
        n+=1
        # for i in x:
        l=list(x.split())
        for j in l:
            if j in C1:
                C1[j]+=1
            else:
                C1[j]=1
    F1=SortedSet()
    for f in C1:
        if (C1[f]/n)*100 >= minsup:
            F1.add(f)
    # print(C1)
    k=2
    # candidate_gen(F1,3)
    F=SortedList()
    # print(F1)
    Fi=F1
    for y in Fi:
        F.add(y)
    while len(Fi)!=0:
        curr=time.time()
        if(curr-st>3400):
            break
        Ck=candidate_gen(Fi,k)
        # print(Ck,'KK')
        DC=SortedDict()
        f = open(inputFile, "r")
        for x in f:
            l=list(x.split())
            for c in Ck:
                no=0
                s=c.split(",")
                for t in s:
                    if t not in l:
                        no=1
                        break
                if no==0:
                    if c in DC:
                        DC[c]+=1
                    else:
                        DC[c]=1
        Fi=SortedSet()
        # print(DC,"M")
        for f in DC:
            if (DC[f]/n)*100 >= minsup:
                Fi.add(f) 
        # print(Fi,"FF")    
        k+=1
        for y in Fi:
            F.add(y)

    return F
def find_subsets(c,s,start,currlen,used,ans):
    
    if currlen==s:
        new=''
        for i in range(len(used)):
            if used[i]==True:
                new+=','
                new+=c[i]
        if new not in ans:
            ans.append(new[1:])
    if start == len(used):
        return
    used[start]=True
    find_subsets(c,s,start+1,currlen+1,used,ans)
    used[start]=False
    find_subsets(c,s,start+1,currlen,used,ans)
    
    
def candidate_gen(F,k):
    C=[]
    for i in range(len(F)-1):
        for j in range(i+1,len(F)):
            if k==2:
                if F[i]<F[j]:
                    c=F[i]+','+F[j]
                    if c not in C:
                        C.append(c)
            else:
                f1=F[i].split(',')
                f2=F[j].split(',')
                # print(f1,f2,"F12")
                flag=0
                for a in range(len(f1)-1):
                    if f1[a]!=f2[a]:
                        flag=1
                        break
                if flag:
                    continue
                else:
                    if f1[-1]<f2[-1]:
                        c=''
                        for it in f1:
                            c+=it
                            c+=','
                        c+=f2[-1]
                        cl=f1.append(f2[-1])
                        # print(f1)
                        # print(c,"CC")
                    else:
                        continue
                used=[False]*len(f1)
                ans=[]
                # print(c)
                subsets=find_subsets(f1,k-1,0,0,used,ans)
                # print(ans,"AA")
                prune =1
                for s in ans:
                    if s not in F:
                        prune=0
                        break
                if prune:
                    if c not in C:
                        C.append(c)
    return C
    
inputFile=sys.argv[1]
if __name__=="__main__":
    f = open(inputFile, "r")
    minsup =int(sys.argv[2])
    res=apriori(f,minsup)
    #print(res)
    f.close()
    f=open(sys.argv[3],'w')
    for k in res:
        l=k.split(",")
        for i in l:
            f.write(i+" ")
        f.write("\n")

    
    
