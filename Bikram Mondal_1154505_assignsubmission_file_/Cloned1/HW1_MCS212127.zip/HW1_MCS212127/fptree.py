import sys,time
sys.setrecursionlimit(100000000)

class TreeNode: 
    def __init__(self,val): 
        self.val = val
        self.children = {}
        self.freq = 1
        self.parent = None
        self.next = None
  
class Tree: 
    def __init__(self): 
        self.root =TreeNode(-1)

headerTable = {}
freqItemsets=[]
global noTransactions
noTransactions=0
freq={}
st_time=time.time()

def getFlistOrder(inputfile,support):
    inputfile=open(inputfile,"r")
    flistOrder_dict={}
    global noTransactions
    for line in inputfile:
        noTransactions+=1
        itemsets=line.split()
        for item in itemsets:
            if(item in flistOrder_dict):
                flistOrder_dict[item]+=1
            else:
                flistOrder_dict[item]=1
    flistOrder_dict = {key: value for key, value in sorted(flistOrder_dict.items(), key=lambda item: item[1], reverse=True)}
    flistOrder=[]
    for i in flistOrder_dict:
        if((flistOrder_dict[i]/noTransactions)*100>=support):  
            freq[i]=1
            flistOrder.append(i)
    inputfile.close()
    return flistOrder

def printTree(root):
    if root==None:
        return 
    for i in root.children:
        print(root.children[i].val,root.children[i].freq,root.children[i].parent.val)
        printTree(root.children[i])

def insertTree(root,itemsets):
    if(len(itemsets)==0):
        return
    if(itemsets[0] in root.children):
        child=root.children[itemsets[0]]
        child.freq+=1
    else:
        child=TreeNode(itemsets[0])
        child.parent=root
        root.children[itemsets[0]]=child
        if(itemsets[0] in headerTable):
            headerTable[itemsets[0]][1].next=child
            headerTable[itemsets[0]][1]=child
        else:
            headerTable[itemsets[0]]=[child,child]
    insertTree(child,itemsets[1:])

def constructTree(inputfile,flistOrder):
    inputfile=open(inputfile,"r")
    #print("length is " + len(inputfile))
    t = Tree()
    for line in inputfile:
        itemsets=line.split()
        itemsets = [item for item in itemsets if item in freq]
        itemsets = sorted(itemsets, key = flistOrder.index)
        insertTree(t.root, itemsets)
    inputfile.close()
    return t.root

def fpGrowth(conditionalTreeNodes,support,items):
    global noTransactions
    freqCount=0
    for node in conditionalTreeNodes:
        freqCount+=conditionalTreeNodes[node]
    if ((freqCount/noTransactions)*100>=support):
        sortedItems=sorted(items)
        freqItemsets.append(sortedItems)
        itemDict={}
        for node in conditionalTreeNodes:
            temp=node.parent
            while(temp.val!=-1):
                if(temp.val not in itemDict):
                    itemDict[temp.val]={temp:conditionalTreeNodes[node]}
                else:
                    if(temp in itemDict[temp.val]):
                        itemDict[temp.val][temp]+=conditionalTreeNodes[node]
                    else:
                        itemDict[temp.val][temp]=conditionalTreeNodes[node]
                temp=temp.parent
        for item in itemDict:
            items.insert(0,item)
            fpGrowth(itemDict[item],support,items)
            items.pop(0)

    else:
        return

def fptree(inputfile,support,outputfile):
    flistOrder=getFlistOrder(inputfile,support)
    #print("flist orderdone")
    constructTree(inputfile,flistOrder)

    flistOrder=flistOrder[::-1]
    for item in flistOrder:
        if(item not in freq):
            continue
        conditionalTreeNodes={}
        startNode=headerTable[item][0]
        while(startNode!=None):
            conditionalTreeNodes[startNode]=startNode.freq
            startNode=startNode.next
        fpGrowth(conditionalTreeNodes,support,[item])
        if(time.time()-st_time>3400):
            break
    freqItemsets.sort()
    out=open(outputfile,"w")
    for items in freqItemsets:
        for item in items:
            out.write(item+" ".rstrip('\n'))
        out.write("\n")
    out.close()


if __name__=="__main__":
    inputfile=sys.argv[1]
    X=int(sys.argv[2])
    outputfile=sys.argv[3]
    fptree(inputfile,X,outputfile)

