#!/bin/bash

if [ $1 = "-apriori" ]
then
	python3 apriori.py $2 $3 $4
	
elif [ $1 = "-plot" ];
then
	python3 plot.py $2 $3
	rm *.txt
elif [ $1 = "-fptree" ];
then
	python3 fptree.py $2 $3 $4
fi
