README for Assignment 1 : COL761 (Data Mining)
Prof. Sayan Ranu, Semester 1, 2022-23

Team:                              Contribution:-
Bikram Mondal(2021MCS2127)             33%
Harshit Verma(2021MCS2133)             33%
Kritika Gupta(2021MCS2136)             33%


Github Repository: https://github.com/bikram947/Data-Mining-COL761-.git


FILES PRESENT IN ZIP

1. sortedcontainers-2.4.0 
    Folder  which contains sortedcontainers library of the python because in hpc sometimes it throws Permission Denied while installing using pip.

2.  MCS212127.sh
	a. ./MCS212127.sh -apriori <inputfile> X <outputfile>
		=> This runs the apriori.py with <inputfile>, X, <outputfile> as the argument.
	
	b. ./MCS212127.sh -plot <inputfile> <outputfile>
		=> This runs the plot.py which runs the fptree and apriori for the given <inputfile> and plots the data.
		=> The program is terminated within 1 hours for each support threshold.

	c. ./MCS212127.sh -fptree <inputfile> X <outputfile>
		=> This runs the fptree.py with <inputfile>, X, <outputfile> as the argument.
		
3. apriori.py
	=> runs the python file, which uses apriori algorithms, to generate frequent itemsets.
	=> reads the data from the inputfile, uses X% as support and outputs a file with the name same as provided through the command line.
	=> each line of the output contains a frequent item set (space separate), sorted in ascending order of ASCII.

4. fptree.py
	=> runs the python file, which uses fptree algorithms, to generate frequent itemsets.
	=> reads the data from the inputfile, uses X% as support and outputs a file with the name same as provided through the command line.
	=> each line of the output contains a frequent item set (space separate), sorted in ascending order of ASCII.
	
5. plot.py 
	=> It runs apriori algorithm and fptree algorithm implemented in 2nd part for 5 different values of X(5,10,25,50,90), and plot it with the time taken by both apriori and fptree implementation . 
	



Explanation of Q3

The time required for the apriori approach is much longer than the time required by the FP-tree algorithm. For small values ​​of X (support), the difference in running time is quite noticeable.

Using the apriori approach, candidates of size k are generated from a repeated item set of size k-1. The candidates are then cut off to remove the non-repeated set. We access the dataset saved on disk in this pruning step. As a result, the apriori algorithm becomes severely slow.

In FP-tree algorithm, all transactions are kept in memory in the form of FP-tree. As a result, because it is a compressed form of storage, it fits into memory. (The FPtree approach assumes that the tree will fit in memory; if it does not, the code will fail.) As a result, the FP-tree approach is faster than the apriori algorithm because it only reads the disk once to generate the FP- tree.

Unlike the FP-Tree algorithm, which employs a DFS approach, the Apriori algorithm uses a BFS approach.

With increase in suppport the time for both algorithm decreases.

Statistically, for a very big X, say 50% or 90%, the frequent data sets are often tiny in quantity and size, allowing the algorithms to run faster. However, when we reduce the amount of support, the number and size of frequent data sets grows. As a result, for modest levels of support, such as 20%, 10%, or 5%, the execution time of algorithms increases drastically.

