import os, time ,sys, matplotlib.pyplot as p

ap = []
fp = []
thres_val = ['90','50','25','10','5']
#thres_val = thres_val[::-1]

for i in thres_val:
    start = time.time()
    os.system(f"bash 2021MCS2127.sh -apriori {sys.argv[1]} {t} tempAP"+i+".txt")
    end = time.time()
    ap.append(end-start)
    start = time.time()
    os.system(f"bash 2021MCS2127.sh -fptree {sys.argv[1]} {t} tempfP"+i+".txt")
    end = time.time()
    fp.append(end-start)

no = [1, 2, 3, 4, 5]
graph = p.subplots(figsize =(8, 8))
n = [x + 0.3 for x in no]

thres_val=thres_val[::-1]
ap=ap[::-1]
fp=fp[::-1]

p.bar(no, Apriori, color ='b', width = 0.3, edgecolor ='black', label ='Apriori')
p.bar(n, FPTree, color ='g', width = 0.3, edgecolor ='black', label ='FP Tree')

p.ylabel('Running Time', fontweight ='bold', fontsize = 16)
p.xlabel('Support Threshold', fontweight ='bold', fontsize = 16)
p.xticks([i + 0.15 for i in no], ['5%', '10%', '25%', '50%', '90%'])
p.title('Apriori vs FPtree')

p.legend()
p.savefig( sys.argv[1] + ".png")
