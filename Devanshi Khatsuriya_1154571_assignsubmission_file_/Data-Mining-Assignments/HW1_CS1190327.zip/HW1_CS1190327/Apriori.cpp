#include <bits/stdc++.h>
#include <ctime>
using namespace std;

time_t start_time;
double interval = 900;
string OUTPUT_FILE;

void write_to_file(vector<vector<int>> &frequent_itemset){
  ofstream output(OUTPUT_FILE);

  vector<string> outvec;
  for(int i = 0; i<(int)frequent_itemset.size(); i++){
    vector<string> temp;
    for(int j = 0; j<frequent_itemset[i].size(); j++)
      temp.push_back(to_string(frequent_itemset[i][j]));
    sort(begin(temp), end(temp));
    string tout = temp[0];
    for(int j = 1; j < (int)temp.size(); j++)
      tout += " " + temp[j];
    outvec.push_back(tout);
  }
  sort(begin(outvec), end(outvec));

  for(string &ss : outvec) output << ss << endl;
  output.close();
}

bool cmp(const vector<int>& a, const vector<int>& b) {
    for (int i = 0; i < min(a.size(), b.size()); i++) {
        if (a[i] < b[i]) return true;
        if (a[i] > b[i]) return false;
    }
    if(a.size() < b.size()) return true;
    return false;
}


// check if a is subset of b
bool is_subset(vector<int>& a, vector<int>& b) {
    int i = 0, j = 0;
    while (i < a.size() && j < b.size()) {
        if (a[i] < b[j]) {
            return false;
        } else if (a[i] > b[j]) {
            j++;
        } else {
            i++;
            j++;
        }
    }
    if(i == a.size()) return true;
    else return false;
}

bool search(vector<vector<int>> &F, vector<int> &v){
    int n = (int)v.size();
    int m = (int)F.size();
    int l = 0, r = m-1;
    while(l <= r){
        int mid = (l + r) / 2;
        bool flag = true;
        for(int i = 0; i < n; i++){
            if(F[mid][i] < v[i]){
                l = mid + 1;
                flag = false;
                break;
            }
            else if(F[mid][i] > v[i]){
                r = mid - 1; 
                flag = false;
                break;
            }
        }
        if(flag) return true;
    }
    return false;
}

vector<vector<int>> candidate_gen(vector<vector<int>> &F_prev)
{
    vector<vector<int>> F = {};
    int n = (int)F_prev.size();
    int k = (int)F_prev[0].size();
    int i = 0;
    while (i < n) {
        vector<int> v = F_prev[i];
        int j = i + 1;
        while(j < n){
            bool flag = true;
            for (int l = 0; l < k - 1; l++) {
                if(v[l] != F_prev[j][l]) {
                    flag = false;
                    break;
                }
            }
            if(!flag) break;
            j++;
        }
        // i...j-1
        if(j == i + 1){
            i++;
            continue;
        }

        for(int i1 = i; i1 < j; i1++){
            for(int j1 = i1 + 1; j1 < j; j1++){
                vector<int> candidate = F_prev[i1];
                candidate.push_back(F_prev[j1][k-1]);

                bool flag = true;
                for(int k1 = 0; k1 < k+1; k1++){
                    vector<int> tmp = {};
                    for(int l = 0; l < k1; l++) tmp.push_back(candidate[l]);
                    for(int l = k1 + 1; l < k+1; l++) tmp.push_back(candidate[l]);
                    if(!search(F_prev, tmp)){
                        flag = false;
                        break;
                    }
                }
                if(flag) F.push_back(candidate);
            }
        }
        // cout << i << " " << j << endl;
        i = j;
    }
    return F;
}

void apriori(string filename, int min_support_percent){

    vector<vector<int>> frequent_itemsets;
    vector<vector<int>> candidates;
    vector<vector<int>> freq_itemsets_k_minus_1;
    vector<vector<int>> freq_itemsets_k;
    map<int, int> candidate_count;
    int k = 1;

    // open file
    ifstream file(filename);
    set<int> c1;
    
    // read file line by line
    string line, item;
    int item_int;
    int num_transactions = 0;
    while(getline(file, line)){
        // split line by space
        stringstream ss(line);
        while(getline(ss, item, ' ')){
            item_int = stoi(item); // convert string to int
            c1.insert(item_int); // add item to c1
            candidate_count[item_int]++; // add item to candidate_count
        }
        num_transactions++;
    }
    // close file
    file.close();
    int min_support = (int)ceil((min_support_percent * num_transactions) / 100.0);
    for(auto item: c1){
        if(candidate_count[item]>=min_support){
            vector<int> temp;
            temp.push_back(item);
            freq_itemsets_k.push_back(temp);
            frequent_itemsets.push_back(temp);
        }
    }

    while(true){

        // write to file
        time_t cur_time = time(NULL);
        double diff  = difftime(cur_time, start_time);
        if(diff >= interval){
            start_time = cur_time;
            write_to_file(frequent_itemsets);
        }

        freq_itemsets_k_minus_1 = freq_itemsets_k;
        freq_itemsets_k.clear();
        candidates.clear();
        candidate_count.clear();

        // generate candidates
        if(freq_itemsets_k_minus_1.size()==0){
          break;
        }

        candidates = candidate_gen(freq_itemsets_k_minus_1);
        // read file line by line
        file.open(filename);
        while(getline(file, line)){
            stringstream ss(line); // split line by space
            vector<int> transaction;
            while(getline(ss, item, ' ')){
                item_int = stoi(item); // convert string to int
                transaction.push_back(item_int);
            }
            sort(transaction.begin(), transaction.end());
            // count candidates
            for(int i = 0; i<candidates.size(); i++){
                if(is_subset(candidates[i], transaction)){
                    candidate_count[i]++;
                }
          }
      }
      // close file
      file.close();

      // generate frequent itemsets
      for(int i = 0; i<candidates.size(); i++){
          if(candidate_count[i]>=min_support){
              freq_itemsets_k.push_back(candidates[i]);
              frequent_itemsets.push_back(candidates[i]);
          }
      }

      if(freq_itemsets_k.size()==0){
          break;
      }
    }
    
    write_to_file(frequent_itemsets);
}


int main(int argc, char* argv[]){
  // read arguments
  if(argc != 4){
    cout << "Usage: ./Apriori <input_file> <output_file> <support_threshold>" << endl;
    return 0;
  }
  string input_file = argv[1];
  OUTPUT_FILE = argv[2];
  int min_support_percent = atoi(argv[3]);

  // run apriori algorithm
  cout << "Calling Apriori Algorithm" << endl;
  apriori(input_file, min_support_percent);
}