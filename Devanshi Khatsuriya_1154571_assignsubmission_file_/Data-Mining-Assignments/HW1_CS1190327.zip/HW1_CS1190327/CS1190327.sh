#!/usr/bin/bash

# Executing the command "./<RollNo>.sh -apriori <dataset_name> X <outputFilename>" generates
# an output text file containing the frequent itemset at >=X% support threshold with the
# Apriori algorithm. X is  provided in percentage and not the absolute count.

# Similarly "./<RollNo>.sh -fptree <dataset_name> X <output filename>" uses FP-Tree.

# Executing the command "./<RollNo>.sh -plot webdocs.dat <output_filename>" generates
# an output ".png" file with name as specified in command line argument. Output file contains a
# plot using matplotlib where the x axis varies the support threshold, and the y-axis contains the
# corresponding running times. It plots the running times of FP-tree and Apriori algorithms
# at support thresholds of 5%, 10%, 25%, 50%, and 90%. 
# There is a timeout if an algorithm at an threshold fails to finish after 1 hour.

if [[ "$#" -ne 3 && "$#" -ne 4 ]]; then
	echo "Error: Incorrect no. of arguments. Expected 3 or 4 arguments."
elif [[ "$1" = "-apriori" ]]; then
    if [[ "$#" -ne 4 ]]; then
        echo "Error: Invalid arguments."
    else
        ./Apriori "$2" "$4" $3
    fi
elif [[ "$1" = "-fptree" ]]; then
    if [[ "$#" -ne 4 ]]; then
        echo "Error: Invalid arguments."
    else
        ./FP_Tree "$2" "$4" $3
    fi
elif [[ "$1" = "-plot" ]]; then
    if [[ "$#" -ne 3 ]]; then
        echo "Error: Invalid arguments."
    else
        # clear previously generated logs from the timing files
        echo -n "" > "fptree_timings.txt"
        echo -n "" > "apriori_timings.txt"
        # run apriori and fptree algorithms for various thresholds
        for d in {90,50,25,10,5}; do # {90,50,25,10,5}
            echo "Support Threshold $d" >> "fptree_timings.txt"
            timeout 1h /usr/bin/time -v ./FP_Tree "$2" "fptree_output_$2_$d" $d 2>> "fptree_timings.txt" # 2>> redirects error stream to appends to file
            echo "Support Threshold $d" >> "apriori_timings.txt"
            timeout 1h /usr/bin/time -v ./Apriori "$2" "apriori_output_$2_$d" $d 2>> "apriori_timings.txt"
            # generate the plot
            python3 plot_script.py "$3"
        done
    fi
else
    echo "Error: Invalid arguments."
fi
