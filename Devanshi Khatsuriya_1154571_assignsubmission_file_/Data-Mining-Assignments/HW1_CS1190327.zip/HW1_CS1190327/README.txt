Github Repo Link - https://github.com/guptaaniket261/Data-Mining-Assignments

Team name - Outliers

Member 1 name - Aniket Gupta
Member 1 entry no. - 2019CS10327
Contribution - 33%

Member 2 name - Devanshi Khatsuriya
Member 2 entry no. - 2019CS10344
Contribution - 33%

Member 3 name - Prabhakar Chaudhary
Member 3 entry no. - 2019CS10381
Contribution - 33%

Explanation for Q3:

Timings on webdocs.dat dataset 
Threshold | Apriori (HH:MM:SS)      | FP_Tree (HH:MM:SS)
90        |     00:02:12            |    00:00:49
50        |     00:03:22            |    00:00:56
25        |     00:05:43            |    00:01:06
10        |     10:43:12            |    00:17:41
5         |        _                |    09:12:43


Observations:
From the above table we can clearly see that:
1. The Apriori algorithm is much slower than the FP_Tree algorithm, taking upto 5x time for support threshold 25.
2. The difference between Apriori and FP_Tree grows wider as the support threshold decreases as expected because of the increase in candidate set size which affects obly the Apriori algorithm.
3. The growth in the runtime of the FP_Tree algorithm as support threshold decreases is exponential.

Conclusion:
The main reason why Apriori is taking so much time on lower thresholds is because of huge candidate set generation. We can also see that even on smaller 
thresholds FP_Tree runs in reasonable time. We can also see that FP_Tree scales well with the support threshold. The FP_Tree algorithm scans the database only twice whereas Apriori algorithm scans the database multiple times depending on the size of largest frequent itemset. This makes FP_Tree much faster as compared to Apriori. FP_Tree also stores the dataset in compact data-structure, thus even making it space efficient.