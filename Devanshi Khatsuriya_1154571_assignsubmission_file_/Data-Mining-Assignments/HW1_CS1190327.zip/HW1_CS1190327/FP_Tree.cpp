#include <bits/stdc++.h>
#include <ctime>
using namespace std;

time_t start_time;
double interval = 900;
string OUTPUT_FILE;

// #include "debug.h"

unordered_map<int, int> item_count;

void write_to_file(vector<vector<int>> &frequent_itemset){
  ofstream output(OUTPUT_FILE);

  vector<string> outvec;
  for(int i = 0; i<(int)frequent_itemset.size(); i++){
    vector<string> temp;
    for(int j = 0; j<frequent_itemset[i].size(); j++)
      temp.push_back(to_string(frequent_itemset[i][j]));
    sort(begin(temp), end(temp));
    string tout = temp[0];
    for(int j = 1; j < (int)temp.size(); j++)
      tout += " " + temp[j];
    outvec.push_back(tout);
  }
  sort(begin(outvec), end(outvec));

  for(string &ss : outvec) output << ss << endl;
  output.close();
}

class Node{
public:
    int item;
    Node *node_link, *parent;
    int cnt = 0;
    unordered_map<int, Node *> children;
};

class Tree{
public:
  Node* root;
  unordered_map<int,Node*> header, curHeader;
  // vector<int> frequent_items_vec;

  Tree(vector<int>& frequent_items){
    root = new Node();
    // frequent_items_vec = frequent_items;
    for(int i : frequent_items) header[i] = nullptr;
  }

  // create a destructor to delete the tree
  ~Tree(){
    deleteTree(root);
  }

  void deleteTree(Node* root){
    if(root == nullptr) return;
    for(auto it : root->children){
      deleteTree(it.second);
    }
    delete root;
  }

  pair<vector<int>,bool> has_single_path(){
    vector<int> items;
    Node* cur = root;
    while((int)cur->children.size()){
      if((int)cur->children.size() > 1) return {{}, false};
      items.push_back(cur->children.begin()->first);
      cur = cur->children.begin()->second;
    }
    return {items, true};
  }

  void insert(vector<pair<int,int>> &items){
    Node* cur = root;
    for(auto [val, cnt]: items){
      if(cur->children.find(val) == cur->children.end()){
        cur->children[val] = new Node();
        cur->children[val]->item = val;

        if(header[val] == nullptr){
          header[val] = cur->children[val];
          curHeader[val] = cur->children[val];
        }
        else{
          Node *t = curHeader[val];
          t->node_link = cur->children[val];
          curHeader[val] = cur->children[val];
        }
      }

      Node *tParent = cur;
      cur = cur->children[val];
      cur->parent = tParent;
      cur->cnt += cnt;
    }
  }
};

// FIXME: verify reference
void fpGrowth(vector<vector<pair<int,int>>> &conditional_tree, int min_sup, vector<int>& suffix, vector<vector<int>> &frequent_itemset){

  // check time
  time_t cur_time = time(NULL);
  double diff  = difftime(cur_time, start_time);
  if(diff >= interval){
    start_time = cur_time;
    write_to_file(frequent_itemset);
  }

  // debug(suffix);
  int n = (int)conditional_tree.size();

  if(!n){
    if((int)suffix.size()){
      vector<int> tsuffix(rbegin(suffix), rend(suffix));
      frequent_itemset.push_back(tsuffix);
    }
    return;
  }

  unordered_map<int,int> freq;
  for(int i = 0; i < n; i++){
    for(auto item: conditional_tree[i]){
      freq[item.first] += item.second;
    }
  }
  unordered_map<int,bool> frequent_items;
  vector<int> frequent_items_vec;
  for(auto item: freq){
    if(item.second >= min_sup){
      frequent_items[item.first] = true;
      frequent_items_vec.push_back(item.first);
    }
  }

  sort(frequent_items_vec.begin(), frequent_items_vec.end(), [&](const int a, const int b) {
      return freq[a] > freq[b];
  });

  if(!(int)frequent_items_vec.size()){
    vector<int> tsuffix(rbegin(suffix), rend(suffix));
    frequent_itemset.push_back(tsuffix);
    return;
  }

  Tree tree(frequent_items_vec);

  for(int i = 0; i < n; i++){
    vector<pair<int,int>> items;
    for(auto item: conditional_tree[i]){
      if(frequent_items.find(item.first) != frequent_items.end()){
        items.push_back(item);
      }
    }
    tree.insert(items);
  }


  auto [temp_items, single] = tree.has_single_path();

  if(single){
    vector<int> tsuffix(rbegin(suffix), rend(suffix));
    int m = (int)temp_items.size();
    for(long long i = 0; i < (1ll << m); i++){
      vector<int> itemset;
      for(long long j = 0; j < m; j++){
        if(i & (1ll << j))
          itemset.push_back(temp_items[j]);
      }
      for(int j : tsuffix) itemset.push_back(j);
      frequent_itemset.push_back(itemset);
    }
    return;
  }

  int m = (int)frequent_items_vec.size();
  if(m>0 and (int)suffix.size()){
    vector<int> tsuffix(rbegin(suffix), rend(suffix));
    frequent_itemset.push_back(tsuffix);
  }
  for(int i = m-1; i >= 0; i--){
    int val = frequent_items_vec[i];
    vector<vector<pair<int,int>>> new_conditional_tree;
    Node *cur = tree.header[val];
    Node *root = tree.root;

    while(cur != nullptr){
      vector<pair<int,int>> items;

      Node *cur_node = cur;
      int cnt = cur_node->cnt;
      cur_node = cur_node->parent;
      while(cur_node != root){
        items.push_back({cur_node->item, cnt});
        cur_node = cur_node->parent;
      }

      new_conditional_tree.push_back(items);
      cur = cur->node_link;
    }

    // TODO: make suffix reference
    // vector<int> new_suffix = suffix;
    suffix.push_back(val);
    fpGrowth(new_conditional_tree, min_sup, suffix , frequent_itemset);
    suffix.pop_back();
  }
}


void FPTree(string input_file, int min_support_percent){
  // open input file
  ifstream file(input_file);
  string line, item;
  int total_transactions = 0;
  int item_int;
  // read file line by line
  while(getline(file, line)){
    stringstream ss(line);
    while(getline(ss, item, ' ')){
      item_int = stoi(item);
      if(item_count.find(item_int) == item_count.end()){
        item_count[item_int] = 1;
      }
      else{
        item_count[item_int]++;
      }
    }
    total_transactions++;
  }
  file.close();

  // calculate min_support
  int min_support = (int)ceil((min_support_percent * total_transactions) / 100.0);

  unordered_map<int,bool> frequent_items;
  vector<int> frequent_items_vec;
  for(auto titem: item_count){
    if(titem.second >= min_support){
      frequent_items[titem.first] = true;
      frequent_items_vec.push_back(titem.first);
    }
  }
  sort(frequent_items_vec.begin(), frequent_items_vec.end(), [](int a, int b){
    return item_count[a] > item_count[b];
  });

  // open input file
  file.open(input_file);

  vector<vector<pair<int,int>>> conditional_tree;
  while(getline(file, line)){
    stringstream ss(line);
    vector<pair<int,int>> transaction;
    while(getline(ss, item, ' ')){
      item_int = stoi(item);
      if(frequent_items.find(item_int) != frequent_items.end())
        transaction.push_back({item_int, 1});
    }
    sort(transaction.begin(), transaction.end(), [](auto a, auto b){
      return item_count[a.first] > item_count[b.first];
    });
    if((int)transaction.size())
      conditional_tree.push_back(transaction);
  }
  file.close();

  vector<vector<int>> frequent_itemset;
  vector<int> suffix;

  fpGrowth(conditional_tree, min_support, suffix, frequent_itemset);

  write_to_file(frequent_itemset);
}



int main(int argc, char* argv[]){
  // read arguments
  if(argc != 4){
    cout << "Usage: ./Fp_tree <input_file> <output_file> <support_threshold>" << endl;
    return 0;
  }
  string input_file = argv[1];
  OUTPUT_FILE = argv[2];
  int min_support_percent = atoi(argv[3]);

  start_time = time(NULL);
  // run apriori algorithm
  cout << "Calling FP-Tree Algorithm" << endl;
  FPTree(input_file, min_support_percent);
}

