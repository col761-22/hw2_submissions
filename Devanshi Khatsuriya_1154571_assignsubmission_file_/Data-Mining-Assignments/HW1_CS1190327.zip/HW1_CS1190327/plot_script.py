import matplotlib.pyplot as plt
import sys

if len(sys.argv) != 2:
	print("Plot script did not get name of plot as argument.")
	sys.exit()

fig_name = sys.argv[1] + ".png"

thresholds_apriori = []
timings_apriori = []

thresholds_fptree = []
timings_fptree = []

# read timing file for apriori
try:
    with open("apriori_timings.txt", "r") as f:
        while True:
            values = f.readline().split()
            if not values:
                break
            if values[0] == "Support": # matches the line of the form "Support Threshold d"
                support_threshold = values[2]
                while True:
                    values = f.readline().split()
                    if not values:
                        break
                    if values[0] == "Elapsed": # matches the line of the form "Elapsed (wall clock) time (h:mm:ss or m:ss): 0:00.ss"
                        denotations = values[-1].split(":")
                        if len(denotations) == 2: # means time was in h:mm:ss format
                            time_in_seconds = int(denotations[0]) * 60 + float(denotations[1])
                        elif len(denotations) == 3: # means time was in m:ss format
                            time_in_seconds = int(denotations[0]) * 3600 + int(denotations[1]) * 60 + float(denotations[2])
                        thresholds_apriori.append(support_threshold)
                        timings_apriori.append(time_in_seconds)
                        break
            if not values:
                break
except Exception as e:
    print(f"{e}. Skipping file 'apriori_timings.txt'...")

# read timing file for fptree
try:
    with open("fptree_timings.txt", "r") as f:
        while True:
            values = f.readline().split()
            if not values:
                break
            if values[0] == "Support": # matches the line of the form "Support Threshold d"
                support_threshold = values[2]
                while True:
                    values = f.readline().split()
                    if not values:
                        break
                    if values[0] == "Elapsed": # matches the line of the form "Elapsed (wall clock) time (h:mm:ss or m:ss): 0:00.ss"
                        denotations = values[-1].split(":")
                        if len(denotations) == 2: # means time was in h:mm:ss format
                            time_in_seconds = int(denotations[0]) * 60 + float(denotations[1])
                        elif len(denotations) == 3: # means time was in m:ss format
                            time_in_seconds = int(denotations[0]) * 3600 + int(denotations[1]) * 60 + float(denotations[2])
                        thresholds_fptree.append(support_threshold)
                        timings_fptree.append(time_in_seconds)
                        break
except Exception as e:
    print(f"{e}. Skipping file 'fptree_timings.txt'...")

thresholds_apriori.reverse()
timings_apriori.reverse()
thresholds_fptree.reverse()
timings_fptree.reverse()

fig = plt.gcf()
fig.set_size_inches(8, 6)

if len(thresholds_apriori) > len(thresholds_fptree):
    plt.plot(thresholds_apriori, timings_apriori, label=f"Apriori Algorithm")
    plt.plot(thresholds_fptree, timings_fptree, label=f"FP-Tree Algorithm")
else:
    plt.plot(thresholds_fptree, timings_fptree, label=f"FP-Tree Algorithm")
    plt.plot(thresholds_apriori, timings_apriori, label=f"Apriori Algorithm")

plt.xlabel("Support Threshold (Percentage)")
plt.ylabel("Time (Seconds)")
plt.legend()
plt.show()

fig.savefig(fig_name, dpi=100)
