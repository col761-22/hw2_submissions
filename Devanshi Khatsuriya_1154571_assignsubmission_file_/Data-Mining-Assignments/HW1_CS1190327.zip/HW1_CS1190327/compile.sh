#!/usr/bin/bash

# Running ./compile.sh in the submission folder creates all the required binaries.

# TODO: add optimization flags like -O2
g++ -O3 Apriori.cpp -o Apriori -std=c++17
g++ -O3 FP_Tree.cpp -o FP_Tree -std=c++17
