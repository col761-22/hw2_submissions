module load apps/anaconda/3
python3 query.py