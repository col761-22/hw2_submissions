module load apps/anaconda/3
python3 kmeans.py $1 $2 $3