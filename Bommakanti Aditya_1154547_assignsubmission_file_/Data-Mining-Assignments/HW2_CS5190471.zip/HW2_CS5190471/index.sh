./create_index $1
