g++ create_index.cpp -o create_index
g++ -std=c++11 -O3 -Wno-deprecated -I./include -o query query.cpp -DVF3
