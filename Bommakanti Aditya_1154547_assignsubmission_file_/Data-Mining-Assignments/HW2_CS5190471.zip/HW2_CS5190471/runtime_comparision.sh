python3 convert_input.py $1 gSpan
python3 convert_input.py $1 fsg
python3 run.py
