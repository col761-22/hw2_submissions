Explanation of Files:

compile.sh: Compiles C++ files and create binaries

Q-1:
convert_input.py: Converts the given graph database to required format
run.py: Runs gaston,gSpan,FSG and saves 'runtimecomparision.png' plot
To run q1: sh runtime_comparision.sh <graph dataset>

Q-2:
create_index.cpp: Create index for the given database
query.cpp: Loads index file, asks for query path and stores result in output_CS5190471.txt
To run index file: sh  index.sh <graph dataset>
To run query file: sh query.sh

Q-3:
clustering.py: Reads the given data and generates elbow plot
To run q-3: sh elbow_plot.sh <dataset> <dimension> q3_<dimension>_CS5190471.png

Team Members:

1)KURISETI RAVI SRI TEJA - 2019CS10369
2)APPAKONDA ABHIJITH REDDY - 2019CS10330
3)BOMMAKANTI VENKATA NAGA SAI ADITYA - 2019CS50471

Contribution: All three of us worked on all parts equally
Contribution Percentage:
1)Ravi : 33
2)Abhijith : 33
3)Aditya : 33
