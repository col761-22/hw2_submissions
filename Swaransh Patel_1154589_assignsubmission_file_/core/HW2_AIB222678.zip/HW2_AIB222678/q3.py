from sklearn.cluster import KMeans
import numpy as np
import matplotlib.pyplot as plt
import sys
path=sys.argv[1]
name=sys.argv[3]
data=np.genfromtxt(path,dtype=float)

li1=[]
li2=[]
for _ in range(1,15):
    kmeans = KMeans(n_clusters=_, random_state=0).fit(data)
    sq_dist=[0]*_
    c_idx=[0]*_
    for i in kmeans.cluster_centers_:
        c_idx[kmeans.predict([i])[0]]=i
    for i in data:
        idx=kmeans.predict([i])
        sq_dist[idx[0]]+=(i-c_idx[idx[0]])**2
    sm=sum(sq_dist)   
    ele=sum(sm)
    print(sum(sm))
    li1.append(ele)
    li2.append(_) 
plt.plot(li2,li1)
# plt.show()
plt.xlabel('Number of clusters(K)')
plt.ylabel("Total within-cluster sum of squares")
plt.title("Optimal numbers of clusters")
#plt.legend()
plt.grid()
plt.savefig(name)

