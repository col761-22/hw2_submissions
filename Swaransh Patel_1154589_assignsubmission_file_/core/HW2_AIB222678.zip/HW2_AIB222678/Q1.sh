if [ True ]; then
	python3 q11.py $1 $2 
else
	echo "Invalid argument"
fi
