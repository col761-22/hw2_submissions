--------------------------------------------COL761 Assignment #2-----------------------------------------
File Submitted:
1. q1.py:This python file Run gSpan, FSG (also known as PAFI), and Gaston against frequency threshold in the dataset and plot the running time of each.
2. Q1.sh:This file contains the script code to run the file of q1.py.
3. q3.py:This python file plot elbow plot to determine the correct value of k in k-means clustering on the dataset.
4. elbow_plot.sh:This file contains the script code to run the file of q3.py.
5. gaston-1.1-re:This directory contains all the required file to excecute gaston.
6. gSpan6:This directory contains all the required file to excecute gSpan6.
7. pafi-1.0.1:This directory contains all the required file to excecute FSG.

Team: CORE

Team Members: Sangam Kumar 2022AIB2671
	      Swaransh Patel 2022AIB2678
		Khushal Shakya 2022AIB2683


Instructions to excecute code:
1. Q1.sh : Takes two argument first dataset and second name of output plot.

Command :  
sh Q1.sh <path to datasets> <output plot name> 
example: sh  Q1.sh molecules/Yeast/167.txt  running_time_plot



2.  elbow_plot.sh : Takes three argument first: datasets, second: dimension, third: name of the elbow plot
command :
sh elbow_plot.sh <path to datasets> <dimension> <name of elbow plot>
example : sh elbow_plot.sh AIB222678_genarated_dataset.dat 4  q3_4_AIB222678.png


----------------------------------------------CONTRIBUTIONS--------------------------------------------------

1.	Sangam Kumar AIB222671 (33.33%)
2.	Swaransh Patel AIB222678 (33.33%)
3.	Khushal Shakya AIB222683 (33.33%)
Each Team member works in equal proportion.

