import pandas as pd
import os
import timeit
import sys
import matplotlib.pyplot as plt
path=sys.argv[1]
name = sys.argv[2] if len(sys.argv)>=3 else 'running time analysis of gspan fsg ,gaston'
curr_dir=os. getcwd()
print(curr_dir)
# os.chdir('molecules/Yeast')
file=open(path,'r')
os.chdir(curr_dir)
lines=file.readlines()
file.close()
data=[]
total=[]
q=0
for i in enumerate(lines):
    k=len(i[1])
    if k==1:
        total.append(data)
        data=[]
        continue
    data.append(i[1].strip().split())
def createdata(first_data):
    df=pd.DataFrame(first_data)
    column_1=df[0]
    column_2=df[1]
    column_3=df[2]
    # print(column_1)
    l=2+int(column_1[1])
    check=column_1[1]
    # print(check)
    count=-1
    vertex=[]
    index=column_1[0]
    index=index.replace('#','# ')
    index_data=f"t {index}"
    # print(index_data)
    vertex.append(index_data)
    for i in range(2,l):
        j=i-2
        if column_1[i]!=check:
            count+=1
            check=column_1[i]
        k=f"v {j} {count}"
        vertex.append(k)
    # print(vertex)
    len=l+int(column_1[l])+1
    for k in range(l+1,len):
        ie=column_1[k]
        oe=column_2[k]
        w=column_3[k]
        edge=(f"e {column_1[k]} {column_2[k]} {column_3[k]}")
        vertex.append(edge)
    return vertex
f=open("result",'w')
idx=0
for q in total:
    ans=createdata(q)
    for w in ans:
        if w[0]=='t':
            f.write(f't # {idx}'+'\n')
            idx+=1
            if idx>=1000 :
                pass
    			#break
        else:
            f.write(w+'\n')

    	# if w[0]=='t':
    	# 	f.write(f't # {idx}'+'\n')
    	# 	idx+=1
    	# 	if idx>=1000 :
    	# 		pass
    	# 		break
    	# else:
        # 	f.write(w+'\n')
        	
f.close()



re=curr_dir+'/result'
print(re)
li=[95,50,25,10,5]
# li=li.reverse()

os.chdir(curr_dir)
os.system('chmod ug+x gaston')
gstime=[]
for i in li:
    start = timeit.default_timer()
    os.system(f'./gaston {i*idx/100} {re} output_gaston')
    stop = timeit.default_timer()
    gstime.append(stop-start)

gtime=[]
os.chdir('gSpan6')
os.system('chmod ug+x gSpan')
for i in li:
    start = timeit.default_timer()
    os.system(f'./gSpan -f {re} -s {i/100} -o -i')
    stop = timeit.default_timer()
    gtime.append(stop-start)

os.chdir(curr_dir)
os.chdir('pafi-1.0.1/Linux')
os.system('chmod ug+x fsg')
ftime=[]
for i in li:
    start = timeit.default_timer()
    os.system(f'./fsg -s {i} -pt {re}')
    stop = timeit.default_timer()
    ftime.append(stop-start)




print(gtime, ftime,gstime)
os.chdir(curr_dir)
# li=[5,10,25, 50,95]
# gtime=[28.266812836998724, 1.757197302998975, 0.3611309840052854, 0.028996820998145267, 0.018413657002383843]
plt.plot(li,gtime,label='gSpan')
# ftime= [14.560838828998385, 2.7578993049974088, 0.5693353339884197, 0.1309532970044529, 0.11935048599843867]
plt.plot(li,ftime,label='FSG')
plt.plot(li,gstime,label='gaston')
plt.ylabel('time in seconds')
plt.xlabel('Min Support Threshold')
plt.title("running time analysis of gspan fsg ,gaston ")
plt.legend()
plt.grid()
plt.savefig(name)
# plt.show()
