#$1 genrated_data_sets
#$2 dimension
#$3 name_of_plot
if [ True ]; then
	python3 q3.py $1 $2 $3
else
	echo "Invalid argument"
fi
