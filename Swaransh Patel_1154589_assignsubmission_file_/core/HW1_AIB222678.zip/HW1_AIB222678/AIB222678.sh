
if [ "$1" == "-apriori" ]; then
	python3 common.py $1 $2 $3 $4
elif [ "$1" == "-fptree" ]; then
 	python3 common.py $1 $2 $3 $4
elif [ "$1" == "-plot" ]; then
	python3 common.py $1 $2 $3 $4
else
	echo "Invalid argument"
fi
