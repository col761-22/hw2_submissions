python3 -mpy_compile common.py
