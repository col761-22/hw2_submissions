# make marger
from itertools import islice
import timeit
from collections import Counter
import math
def apriori(file_name,x,out_name):
    def merge(dict):#make freq table of prev+1 elements all values is zero
        new_dict={}
        # print('   in marge')
        ks=list(dict)
        for i in range(len(ks)):
            for j in range(i+1,len(ks)):
                tmx=[]
                tmn=[]
                if ks[i][:-1]==ks[j][:-1]:
                    tmx.append(max(ks[i][-1],ks[j][-1]))
                    tmn.append(min(ks[i][-1],ks[j][-1]))
                    item=ks[i][:-1]+tuple(tmn)+tuple(tmx)
                    # print(item)
                    if len(item)==len(ks[i])+1:
                        new_dict[item]=0
        # print(new_dict)
        return new_dict
    def frq_count(dict):
        # print('fre')
        f=open(file_name)
        f_milion=list(islice(f,1))
        # f_milion=f.readline()
        while f_milion:
            # start = timeit.default_timer()
            for fl in f_milion:
                fl=set(map(int, fl.split()))
                for d in dict:
                    if check(d, fl):
                        dict[d]+=1
            f_milion=list(islice(f,1))
            # f_milion=f.readline()
            # end = timeit.default_timer()
            # print('time for freq cnt of 100000 ele  :  ',end-start)
        f.close()
        return dict

    def check(d,fl):
        for i in d:
            if i in fl :
                continue
            else:
                return 0
        return 1

    def filter(dict,sprt): #prune which not support thersold
        # print('   in filter')
        for i in list(dict):
            if dict[i]<sprt:
                del dict[i]
        
        return dict

    def cnt_elements(f):
        new_dict={}
        # print('in cnt_new')
        FL=list(islice(f, 1))
        # FL=f.readlines()
        # print('f')
        while FL:
            # start = timeit.default_timer()
            for fl in FL:
                fl=set(map(int,fl.split()))
                for i in fl:
                    if i in new_dict:
                        new_dict[i]+=1
                    else:
                        new_dict[i]=1
            FL=list(islice(f, 1))
            # FL=f.readline()
            # print('f')
            # stop = timeit.default_timer()
            # print(stop-start)
        f.close()
        dic={}
        for i in new_dict:
            dic[tuple([i])]=new_dict[i]
        # print(dic.keys())
        return dic
    def apriori(file,support):
        levels=[]
        # print('   in apriori')
        levels.append(filter(cnt_elements(file),support))
        while len(levels[-1]):
            # start = timeit.default_timer()
            temp=merge(levels[-1])       
            temp=frq_count(temp)
            temp=filter(temp,support)
            levels.append(temp)
            # stop = timeit.default_timer()
            # print(stop-start)
        # print(levels)
        return levels
    def right(lvs):
        li=[]
        for i in lvs:
            for j in i:
                li2=[]
                for k in j:
                    li2.append(str(k))
                
                li.append(sorted(li2))
                
        li.sort()
        # print(li)
        f=open(out_name,'w')
        for i in li:
            for j in range(len(i)):
                if j==len(i)-1:
                    f.write(i[j])
                else:
                    f.write(i[j]+' ')
                
            f.write('\n')
        f.close()


    f=open(file_name)   
    n=0
    while f.readline():
        n+=1
    f.close()
    support=math.ceil((x*n)/100)
    # start = timeit.default_timer()
    f=open(file_name,'r')
    lvs=apriori(f,support)
    right(lvs)
    # stop = timeit.default_timer()
    print('######################### apriori algo starts ####################################')
    # print( '  total time is  :  ', stop-start)
