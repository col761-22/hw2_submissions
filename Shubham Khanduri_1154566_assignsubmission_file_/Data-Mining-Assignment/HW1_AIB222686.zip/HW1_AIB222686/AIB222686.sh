case $1 in
	"-apriori")
		#start=$(date +%N)
		timeout 60m python3 apriori.py $2 $3 $4
		#seconds=$(($(date +%N) - $start))
		#echo $seconds
		exit;;
	"-fptree")
		#start=$(date +%N)
		timeout 60m python3 fptree.py $2 $3 $4
		#seconds=$(($(date +%N) - $start))
		#echo $seconds
		exit;;
	"-plot")
		python3 plot.py $2 $3
		exit;;
	*)
		echo "wrong input"
	 ;;
esac