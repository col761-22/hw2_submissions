import sys
import itertools
from collections import OrderedDict

count = 0
output = []

class Children:
    """use this to 
    keep all the paths of an item"""
    def __init__(self):
        self.children = {}

class TrieNode:
    """used to generate node in Trie data structure"""
    def __init__(self, item):
        self.children = {} 
        self.parent = None
        self.adjacent = None
        self.item = item
        self.isLeaf = False
        self.frequency = 0

class Trie:
    def __init__(self):
        self.root = TrieNode("")
    
    def insert(self, transaction, header):
        """insert the transaction items in the
        Trie """
        #print(transaction)
        node = self.root
        for item in transaction:
            if item in node.children:
                node = node.children[item]
                node.frequency += 1
            else:
                node.isLeaf = False
                newNode = TrieNode(item)
                newNode.parent = node
                newNode.frequency = 1
                node.children[item] = newNode
                if(item in header):
                    temp = header[item]
                    while(temp.adjacent != None):
                        temp = temp.adjacent
                    temp.adjacent = newNode
                else:
                    header[item] = newNode  
                node = newNode
        if(len(node.children) == 0):       
            node.isLeaf = True

def initialize(fileName, candidateSet):
    """only generate 1 size candidate set"""
    file1 = open(fileName, 'r')
    while True:
        global count
        #count += 1
        line = file1.readline()
    
        # if line is empty
        # end of file is reached
        if not line:
            break
        count += 1
        line = line.strip()
        line = line.strip("\n").split(" ")
        for item in line:
            #print(item)
            if(item == '\n' or item == ' ' or item == ''):
                #print(item)
                continue
            #print(item)
            #item = (item,)
            candidateSet[item] = candidateSet.get(item, 0) + 1
    file1.close()

def addInOutput(freqSet):
    for item in freqSet:
        output.append((item,))

def findFreq(freqSet, X, candidateSet):
    global count
    freqSet.clear()
    for item in candidateSet.keys():
        if candidateSet[item]/count >= X/100:
            freqSet[item] = candidateSet[item]
    if(len(freqSet) > 0):
        addInOutput(freqSet)

def buildTrie(freqSet, fileName, headerTable):
    file1 = open(fileName, 'r')
    trie = Trie()
    while True:
        line = file1.readline()
    
        # if line is empty
        # end of file is reached
        if not line:
            break
        line = line.strip()
        line = line.strip("\n").split(" ")
        transaction = []
        for itemSet in freqSet.keys():
            if(itemSet in line):
                transaction.append(itemSet)
        trie.insert(transaction, headerTable)
    file1.close()
    return trie

def getPathToRoot(node):
    temp = node.parent
    li = []
    while(temp.parent != None):
        li.append(temp.item)
        temp = temp.parent
    li.reverse()
    return tuple(li)

def bulidConditionalPattern(item, headerTable, patternBase):
    node = headerTable[item]
    patternBase[item] = Children()
    while(node != None):
        path = getPathToRoot(node)
        if len(path)>0:
            patternBase[item].children[path] = node.frequency
        node = node.adjacent



def printTrie(trie):
    if(trie == None):
        return
    for item in trie.children:
        print(item)
        printTrie(trie.children[item])
    #print()

def traverse(node):
    while(node != None):
        print(str(node.item)+"   "+str(node.frequency)+"  "+str(node.isLeaf))
        node = node.adjacent

def printHeaderTable(headerTable):
    for item in headerTable.keys():
        traverse(headerTable[item])   

def printConditionalPattern(patternBase):
    for item in patternBase:
        for path in patternBase[item].children:
            print(str(item)+"    "+str(path)+"  "+str(patternBase[item].children[path]))

def buildConditionalFPTree(item, node, conditionalFPTree, X):
    li = set()
    #print(item)

    for path in node.children:
        for val in path:
            freq = 0
            for itemSet in node.children:
                if(val in li):
                    break
                if val in itemSet:
                    freq += node.children[itemSet]
            if(val not in li and (freq/count) >= (X/100)):
                li.add(val)
    
    length = len(li)
    freqSubset = []
    locFrequent = []
    allSubset = []
    for i in range(1, length+1):
        #print(li)
        for x in list(itertools.combinations(set(li), i)):
            allSubset.append(x)
            #print(x)
        if(len(allSubset) <= 0):
            continue
        for itemVal in allSubset:
            freq = 0
            for path in node.children:
                if(itemVal in locFrequent):
                    break
                if(set(itemVal).issubset(path)):
                    freq += node.children[path]
            if(itemVal not in locFrequent and (freq/count) >= (X/100)):
                    locFrequent.append(itemVal)
        
        if(len(locFrequent)>0):
            freqSubset.extend(locFrequent)
        li.clear()
        allSubset.clear()
        for row in locFrequent:
            for element in row:
                li.add(element)
        locFrequent.clear()
    """for value in li:
        print(value)"""

    if(len(freqSubset)>0):            
        conditionalFPTree[item] = tuple(freqSubset) 
        for tup in freqSubset:
            lis = list(tup)
            lis.append(item)
            lis.sort()
            output.append(tuple(lis))

def printConditionalFPTree(conditionalFPTree):
    for item in conditionalFPTree:
        print(str(item)+"   "+str(conditionalFPTree[item]))

def printAllOutput():
    global output
    output.sort()
    for item in output:
        print(item)

def saveOutputInFile(outputFileName):
    global output
    output.sort()
    outputFile = open(outputFileName, 'w')
    for itemset in output:
        lastIndex = len(itemset)-1
        for item in itemset:
            #item = item.strip("'")
            outputFile.write(str(item))
            if(item == itemset[lastIndex]):
                continue
            outputFile.write(" ")
        outputFile.write("\n")

def main():
    fileName = sys.argv[1]
    X = int(sys.argv[2])
    outputFileName = sys.argv[3]  
    candidateSet = {}
    freqSet = OrderedDict({})
    headerTable = OrderedDict({})
    patternBase = OrderedDict({})
    conditionalFPTree = OrderedDict({})

    initialize(fileName, candidateSet)
    candidateSet = OrderedDict(sorted(candidateSet.items()))
    candidateSet = OrderedDict(sorted(candidateSet.items(), key = lambda x: x[1], reverse=True))

    #print(candidateSet)
    findFreq(freqSet, X, candidateSet)
    trie = buildTrie(freqSet, fileName, headerTable)

    for item in reversed(freqSet):
        bulidConditionalPattern(item, headerTable, patternBase)
    
    for item in patternBase:
        buildConditionalFPTree(item, patternBase[item], conditionalFPTree, X)
    
    saveOutputInFile(outputFileName)

    #printTrie(trie.root)
    #printHeaderTable(headerTable)
    #print(freqSet)
    #printConditionalPattern(patternBase)
    #print()
    #printConditionalFPTree(conditionalFPTree)
    #printAllOutput()
    #print(len(output))

if __name__ == "__main__":
    main()


