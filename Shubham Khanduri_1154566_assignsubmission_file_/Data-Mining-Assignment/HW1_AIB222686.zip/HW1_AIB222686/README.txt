Team Name: TripleS

Github repository link: https://github.com/KhanduriShubham/Data-Mining-Assignment

Members: 1) Shubham Khanduri, aib222686@scai.iitd.ac.in
2) Sahil Jain, aib222677@scai.iitd.ac.in
3) Shivam Agrahari, aib222680@scai.iitd.ac.in 

CONTRIBUTION OF EACH GROUP MEMBER
All members contributed equally in the assignment that is 33% each.

FP-GROWTH VS APRIORI ALGORITHM FOR FREQUENT ITEMSET DATA MINING

For the smaller dataset we saw that sometimes apriori was outperforming fp-growth for certain threshold. But as the dataset size increased fp-growth regained the time difference and satrted to show
better running time results. As an overall conclusion we observed that FP-Growth algorithm is more optimal than Apriori because it takes less running time as comapred to Apriori as the dataset increases.
The difference between fp-growth and apriori run time starts getting less with the decrease in support threshold value even for large number of transactions(this is observed from the sample dataset 
that we had). We have used 0 second run time for support thresholds where our code is timed out due to 60 minute.

