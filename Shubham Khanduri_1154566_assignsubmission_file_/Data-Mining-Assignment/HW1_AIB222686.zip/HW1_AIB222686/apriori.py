import sys
import itertools
from collections import OrderedDict


#dict = {(1,4): '10', (1, 3): '9'}
#dict1 = OrderedDict(sorted(dict.items()))
#print(dict1)

fileName = sys.argv[1]  #contains the input test filename
X = int(sys.argv[2])    #support threshold
outputFileName = sys.argv[3]   #output file name

file1 = open(fileName, 'r') 
count = 0  #no of transactions

candidateSet = {} 
freqSet = OrderedDict({})
output = []  #store all frequent set
#K = 0

def findFreq():  
    """to check the eligible frequent set
    in the candidate set k"""
    global count, X
    freqSet.clear()
    for item in candidateSet.keys():
        if candidateSet[item]/count >= X/100:
            freqSet[item] = candidateSet[item]
    if(len(freqSet) > 0):
        addInOutput()
        return True
    else:
        return False

def addInOutput():
    """to store the frequent set"""
    for item in freqSet:
        output.append(item)

def findCandidateSet(k):
    #print(k)
    """generate candidate set k"""
    global candidateSet
    candidateSet.clear()
    for item1 in freqSet.keys():
        for item2 in freqSet.keys():
            if(item1 >= item2):
                #print(str(item1)+"  "+str(item2))
                continue
            i = 0
            #print()
            while i<k-2:
                if(item1[i] != item2[i]):
                    break
                i += 1
            else:
                #set1 = set()
                set1 = []
                for item in item1:
                    #print(item)
                    #set1.add(item)
                    set1.append(item)
                #for item in item2:
                    #set1.add(item)
                #set1.add(item2[k-2])
                set1.append(item2[k-2])
                #print(set1)
                if(allSubsetPresent(set1, k-1)):
                    #li = list(set1)
                    #li.sort()
                    #print("allSubsetPresent"+" "+str(li))
                    #print(tuple(li))
                    #candidateSet[tuple(li)] = 0
                    candidateSet[tuple(set1)] = 0

def findCandidateSetFreq():
    """check the frequency for generated k size itemset"""
    global fileName
    file2 = open(fileName, 'r')
    while True:
        line = file2.readline()
    
        # if line is empty
        # end of file is reached
        if not line:
            break
        line = line.strip("\n").split(" ")
        #print(line)
        for candidate in candidateSet.keys():
            #index = 0
            #print(candidate)
            for element in candidate:
                if(str(element) not in line):
                    #print(str(element)+"  "+"freq")
                    break
            else:
                candidateSet[candidate] = candidateSet.get(candidate, 0) + 1
    file2.close()



def allSubsetPresent(set1, n):
    """pruning of itemset of k size if its all subset
     of size k-1 are not present in the frequency set"""
    #print(set1)
    #print()
    #subset = list(itertools.combinations(set1, n))
    subset = list(itertools.combinations(set(set1), n))
    if(len(subset)<=0):
        return False
    for item in subset:
        item = list(item)
        item.sort()
        #print("S"+" "+str(item))
        if(tuple(item) not in freqSet.keys()):
            """print()
            print(item)
            print()"""
            return False
    return True

def initialize():
    """it will only run for one time to generate the
    1 size itemset directly from the database"""
    while True:
        global count
        #count += 1
        line = file1.readline()
    
        # if line is empty
        # end of file is reached
        if not line:
            break
        count += 1
        line = line.strip()
        line = line.strip("\n").split(" ")
        for item in line:
            #print(item)
            if(item == '\n' or item == ' ' or item == ''):
                #print(item)
                continue
            #print(item)
            item = (item,)
            candidateSet[tuple(item)] = candidateSet.get(tuple(item), 0) + 1

initialize()
file1.close()

#print("hello")
#count -= 1
candidateSet = OrderedDict(sorted(candidateSet.items()))

findFreq()

"""#print(str(len(candidateSet))+"  "+str(count))

for item in candidateSet.keys():
    print(str(item)+"  "+str(candidateSet[item]))

print()

for item in freqSet.keys():
    print(str(item)+"  "+str(freqSet[item]))

print()

for item in output:
    print(item)"""

"""for item in freqSet.keys():
    print(str(item)+"  "+str(freqSet[item]))"""

def printFreqSet():
    for item in freqSet.keys():
        print(str(item)+"  "+str(freqSet[item]))

def printAllOutput():
    global output
    output.sort()
    for item in output:
        print(item)

def saveOutputInFile():
    """save the output in file"""
    global output
    output.sort()
    outputFile = open(outputFileName, 'w')
    for itemset in output:
        lastIndex = len(itemset)-1
        for item in itemset:
            #item = item.strip("'")
            outputFile.write(str(item))
            if(item == itemset[lastIndex]):
                continue
            outputFile.write(" ")
        outputFile.write("\n")

def main():
    K = 2
    global candidateSet
    while True:  
        #print(K)
        findCandidateSet(K);
        #print(candidateSet)
        candidateSet = OrderedDict(sorted(candidateSet.items()))
        findCandidateSetFreq()
        if not findFreq():
            break
        #printFreqSet()
        K += 1
    saveOutputInFile()
    #printAllOutput()
    #print(len(output))

if __name__ == "__main__":
    main()

  
