import sys
import os
import time
import numpy as np
import matplotlib.pyplot as plt

def main():
    fileName = sys.argv[1]
    outName = sys.argv[2]
    outName = outName.replace(".png", '')
    thres = [5, 10, 25, 50, 90]
    aprioriTimeArray = [0, 0, 0, 0, 0]
    FPTimeArray = [0, 0, 0, 0, 0]
    x=np.array([5, 10, 25, 50, 90])
    for i in range(4, -1, -1):
        start_time = time.time()
        command = "timeout 15m python3 fptree.py "+fileName+" "+str(thres[i])+" "+"fp"+outName+".dat"
        os.system(command)
        FPTimeArray[i] = (time.time() - start_time)/60
        start_time = time.time()
        command = "timeout 45m python3 apriori.py "+fileName+" "+str(thres[i])+" "+"ap"+outName+".dat"
        os.system(command)
        aprioriTimeArray[i]=(time.time() - start_time)/60
        y1=np.array(aprioriTimeArray)
        #x1=np.array([6,8,10,12,14])
        y2=np.array(FPTimeArray)
        plt.scatter(x,y1, color='blue', label='apriori ')
        plt.title('apriori vs fp growth running time \n 0 seconds run time represents timeout for that threshold')
        plt.xlabel('support treshold (%)')
        plt.ylabel('running time (minutes)')
        #x=np.array([6,8,10,12,14])
        #y=np.array([8,9,10,11,12])
        plt.scatter(x,y2, color='red', label='fp growth')
        plt.legend()
        #plt.show()
        plt.savefig(outName+".png", bbox_inches='tight')
        plt.clf()

    """for i in range(0, 5):
        print(str(aprioriTimeArray[i])+" "+str(FPTimeArray))"""
                
if __name__ == "__main__":
    main()