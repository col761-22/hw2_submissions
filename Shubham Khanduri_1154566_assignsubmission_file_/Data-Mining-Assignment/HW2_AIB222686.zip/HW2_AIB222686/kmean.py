

## Importing the libraries

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sys
import os

## Importing the dataset

file = sys.argv[1]
dataset = pd.read_csv(file,sep='\s+',header=None)
#display(dataset)
x = dataset.iloc[:,:].values
#print(x)

"""## Using the elbow method to find the optimal number of clusters"""

from sklearn.cluster import KMeans
WCSS = []

for i in range(1, 16):
    kmeans = KMeans(n_clusters = i, init = 'k-means++', random_state = 42)
    kmeans.fit(x)
    WCSS.append(kmeans.inertia_)

plt.plot(range(1, 16), WCSS, marker='+')
plt.title('The Elbow Method')
plt.xlabel('Number of clusters')
plt.ylabel('WCSS')
plt.savefig(sys.argv[3])