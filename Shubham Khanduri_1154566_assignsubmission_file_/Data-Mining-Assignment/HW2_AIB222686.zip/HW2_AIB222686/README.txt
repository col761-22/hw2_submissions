git clone https://github.com/KhanduriShubham/Data-Mining-Assignment
Team Name: TripleS

i) All Files:
	a) PlotTimeVsFreq.py (This file is used to generate plot for the first question)
	b) kmean.py (This File is used to generate plots for K-means clustering)
	c) elbow_plot.sh (This is created for 3rd question as asked in the assignment)
	d) fsg, gaston, gspan (Executables required for 1st question)
	e) 167.txt_graph (dataset required for 1st question)

ii) Details of Team Members
	Shubham Khanduri 2022AIB2686
	Shivam Agrahari 2022AIB2680
	Sahil Jain 2022AIB2677

iii) To execute First Question we are required to execute PlotTimeVsFreq.py and provide path for the dataset as the argument and the three executables (fsg, gaston, gspan)
 should also be present in the folder.
To execute the Third Question we are required to run the elbow_plot.sh and provide 3 arguments with same order as mentioned in the Assignment question.