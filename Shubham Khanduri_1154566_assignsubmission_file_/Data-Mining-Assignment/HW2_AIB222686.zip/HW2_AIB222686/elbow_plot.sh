#!/bin/bash
python3 kmean.py $1 $2 $3