import sys
import os
import time
import matplotlib.pyplot as plt

def covertInputToGspanFormat(lines, filePath):
    head = os.path.split(filePath)[0]
    fileName1 = "GspanFormat1.txt"
    # fileName2 = "MapGraphId.txt"
    file1 = open(os.path.join(head, fileName1), 'w')
    # file2 = open(os.path.join(head, fileName2), 'w')
    vertexLabel = {}
    edgeLabel = {}
    # realGraphId = {}
    graphId = 1
    vertexLabelNo = 0
    edgeLabelNo = 0
    for fileNo in range(len(lines)):
        if(lines[fileNo].startswith('#')):
            vertexNo = 0
            # realGraphId[graphId] = lines[fileNo][1]
            # file2.write(str(graphId)+" "+str(lines[fileNo].replace('#',""))+"\n")
            file1.write("t # "+str(graphId)+"\n")
            graphId += 1
            fileNo += 1
            numNodes = int(lines[fileNo])
            fileNo += 1
            for i in range(numNodes):
                vLabel = lines[fileNo]
                if vLabel not in vertexLabel.keys():
                    vertexLabel[vLabel] = vertexLabelNo
                    vertexLabelNo += 1
                file1.write("v "+str(vertexNo)+" "+str(vertexLabel[vLabel])+"\n")
                vertexNo += 1
                fileNo += 1
            numEdges = int(lines[fileNo])
            fileNo += 1
            for i in range(numEdges):
                temp = lines[fileNo].split(" ")
                startNode = int(temp[0])
                endNode = int(temp[1])
                eLabel = temp[2]
                if startNode>endNode:
                    t = startNode
                    startNode = endNode
                    endNode = t
                if eLabel not in edgeLabel.keys():
                    edgeLabel[eLabel] = edgeLabelNo
                    edgeLabelNo += 1
                file1.write("e "+str(startNode)+" "+str(endNode)+" "+str(edgeLabel[eLabel])+"\n")
                fileNo += 1
    
    file1.close()
    # file2.close()
    return os.path.join(head, fileName1), graphId-1

def covertInputToFSGFormat(lines, filePath):
    head = os.path.split(filePath)[0]
    fileName1 = "FSGFormat1.txt"
    # fileName2 = "MapGraphId.txt"
    file1 = open(os.path.join(head, fileName1), 'w')
    # file2 = open(os.path.join(head, fileName2), 'w')
    # vertexLabel = {}
    # edgeLabel = {}
    # realGraphId = {}
    graphId = 1
    vertexLabelNo = 0
    edgeLabelNo = 0
    for fileNo in range(len(lines)):
        if(lines[fileNo].startswith('#')):
            vertexNo = 0
            # realGraphId[graphId] = lines[fileNo][1]
            # file2.write(str(graphId)+" "+str(lines[fileNo].replace('#',""))+"\n")
            file1.write("t # "+str(graphId)+"\n")
            graphId += 1
            fileNo += 1
            numNodes = int(lines[fileNo])
            fileNo += 1
            for i in range(numNodes):
                vLabel = lines[fileNo]
                # if vLabel not in vertexLabel.keys():
                #     vertexLabel[vLabel] = vertexLabelNo
                #     vertexLabelNo += 1
                file1.write("v "+str(vertexNo)+" "+str(vLabel)+"\n")
                vertexNo += 1
                fileNo += 1
            numEdges = int(lines[fileNo])
            fileNo += 1
            for i in range(numEdges):
                temp = lines[fileNo].split(" ")
                startNode = int(temp[0])
                endNode = int(temp[1])
                eLabel = temp[2]
                if startNode>endNode:
                    t = startNode
                    startNode = endNode
                    endNode = t
                # if eLabel not in edgeLabel.keys():
                #     edgeLabel[eLabel] = edgeLabelNo
                #     edgeLabelNo += 1
                file1.write("u "+str(startNode)+" "+str(endNode)+" "+eLabel+"\n")
                fileNo += 1
    
    file1.close()
    # file2.close()
    return os.path.join(head, fileName1)
    

def main():
    filePath = sys.argv[1]
    file1 = open(filePath, 'r')
    lines = file1.read().split("\n")
    file1.close()
    inputPathToGspan, totalGraph = covertInputToGspanFormat(lines, filePath)
    inputPathToFSG = covertInputToFSGFormat(lines, filePath)
    minsup_list = [95.0, 50.0, 25.0, 10.0, 5.0]
    outputGspan = []
    outputFSG = []
    outputGaston = []
    for i in range(len(minsup_list)):
        cmd = './gspan -f '+inputPathToGspan+" -s "+str(minsup_list[i]/100)
        begin = time.time()
        os.system(cmd)
        outputGspan.append(abs(time.time()-begin))
        print(time.time()-begin)
        cmd = './gaston '+str((minsup_list[i]/100)*totalGraph)+" "+inputPathToGspan
        begin = time.time()
        os.system(cmd)
        outputGaston.append(abs(time.time()-begin))
        print(time.time()-begin)
        cmd = './fsg -s '+str(minsup_list[i])+" "+inputPathToFSG
        begin = time.time()
        os.system(cmd)
        outputFSG.append(abs(time.time()-begin))
        print(time.time()-begin)

    minsup_list.reverse()
    outputGspan.reverse()
    outputFSG.reverse()
    outputGaston.reverse()
    plt.plot(minsup_list, outputGspan, color = 'r', label = 'gSpan')
    plt.plot(minsup_list, outputFSG, color = 'g', label = 'FSG')
    plt.plot(minsup_list, outputGaston, color = 'b', label = 'Gaston')
    plt.title('Running time VS Support Frequency')
    plt.xlabel('Support Thresholds (in percentage)')
    plt.ylabel('Running time (in seconds)')
    plt.legend()
    plt.savefig('plot.png')
    # plt.show()

        

if __name__ == "__main__":
    main()