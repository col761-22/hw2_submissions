#! /bin/bash

g++ -std=c++11 apriori.cpp -o apriori
g++ -std=c++11 fptree.cpp -o fptree
