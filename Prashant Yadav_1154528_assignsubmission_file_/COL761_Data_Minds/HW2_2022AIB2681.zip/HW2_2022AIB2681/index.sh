#! /bin/bash

python3 indexing.py $1