#! /bin/bash

python3 query.py
