#! /bin/bash

python3 plot.py $1

