#! /bin/bash

python3 elbow_plot.py $1 $2 $3