Github Repo:-
https://github.com/prashantyadav777/COL761_Data_Minds

Team members:-
Anwoy Chatterjee 2022AIB2675
Prashant Yadav 2022AIB2681
Apoorv Poswal 2022AIB2674

Contribution of each member:
Anwoy Chatterjee -> Implimentation of Q2, Q1
Prashant Yadav -> Implimentation of Q3
Apoorv Poswal -> Plotting and compilation of report

Percentage Contributions:-
Anwoy Chatterjee -> 33%
Prashant Yadav -> 33%
Apoorv Poswal -> 33%

Files bundled:-

1) plot.py 	(Implementation for Q1)
2) indexing.py (Implementation of building index structure for Q2)
3) query.py (Implementation for query processing for Q2)
4) elbow_plot.py	(Implementation for Q3)
5) plot.sh		(bash file for running Q1)
6) index.sh		(bash file for building index structure in Q2)
7) query.sh		(bash file for query processing in Q2)
8) elbow_plot.sh	(bash file for running Q3)
9) 2022AIB2681.pdf  (Report)
10) README.txt
