#!/bin/sh
python kmeans_plot.py $1 $2 $3
