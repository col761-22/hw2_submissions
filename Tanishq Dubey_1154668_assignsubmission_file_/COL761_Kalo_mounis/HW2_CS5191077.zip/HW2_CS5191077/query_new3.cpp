#include<bits/stdc++.h>
#include <boost/unordered_map.hpp>
#include <boost/graph/vf2_sub_graph_iso.hpp>
#include <boost/graph/adjacency_list.hpp>

using namespace std;
using namespace std::chrono;
using namespace boost;

typedef property< edge_name_t, int > edge_prop;
typedef property< vertex_name_t, int, property< vertex_index_t, int > > vertex_prop;
typedef adjacency_list< setS, vecS, undirectedS, vertex_prop, edge_prop > graph_typ;
typedef property_map< graph_typ, vertex_name_t >::type vertex_name_map_t;
typedef property_map_equivalent< vertex_name_map_t, vertex_name_map_t > vertex_comp_t;
typedef property_map< graph_typ, edge_name_t >::type edge_name_map_t;
typedef property_map_equivalent< edge_name_map_t, edge_name_map_t > edge_comp_t;


vector<string> data_labels;
vector<graph_typ> data_graphs;

vector<string> fsg_labels;
vector<graph_typ> fsg_graphs;

vector<string> query_labels;
vector<graph_typ> query_graphs;

vector<string> data_feature_vectors;
vector< vector<string> > query_outputs; 

std::unordered_map<string,int> feature_label_to_index;

vector<int> SelectedFeatureIndices;


void convertDatasetToBoost(string filename) {
    cout << "in dataToBoost, file name: " << filename << endl;
    ifstream file(filename);
    string line;

    string next_label;
    string label;
    getline(file, line);
    next_label = line.substr(line.find("#")+1);
    int c=0;
    // while (getline(file, line)) {
    while (file.peek() != EOF) {
        string label = next_label;
        // data_index_ID[c] = label; //qqqqqqqqq
        // data_ID_index[label] = c; //qqqqqqqqq
        c++; 
        // cout << label << endl;
        // labelMap_Data[label] = graph();
        graph_typ g1;

        while(getline(file, line)) {
            if(line[0] == 't') {
                next_label = line.substr(line.find("#")+1);
		//cout << endl;
                break;
            }
            if(line[0] == 'v') {
                line = line.substr(2);
                string vertex = line.substr(0, line.find(" "));
                string vertex_label = line.substr(line.find(" ")+1);
                int int_vertex = stoi(vertex);
                int int_vertex_label = stoi(vertex_label);
                add_vertex(vertex_prop(int_vertex_label), g1);
              //  cout << vertex <<  " " << vertex_label << endl;
            }
            if(line[0] == 'u') {
                line = line.substr(2);
                int v1 = stoi(line.substr(0, line.find(" ")));
                line = line.substr(line.find(" ")+1);
                int v2 = stoi(line.substr(0, line.find(" ")));
                line = line.substr(line.find(" ")+1);
                int edge_label = stoi(line);
                add_edge(v1, v2, edge_prop(edge_label), g1);
             //   cout << v1 << " " << v2 <<  " " << edge_label << endl;
            }
        }
        data_labels.push_back(label);
        data_graphs.push_back(g1); // qqqqqqqqqqqqq
    }
    file.close();
    // cout << labelMap_Data.size() << endl;
}

void convertFsgToBoost(string filename) {
    ifstream file(filename);
    string line;

    string next_label;
    string label;
    while(getline(file, line)) {
        if(line[0] != '#') {
            break;
        }
    }
    int hash_pos = line.find('#');
    int comma_pos = line.find(',');
    next_label = line.substr(hash_pos+2, comma_pos-hash_pos-2);

    // next_label = line.substr(line.find(',')+1);
    // while (getline(file, line)) {
    int idx = 0;
    while (file.peek() != EOF) {        
        string label = next_label;
        //cout << label << endl;
        graph_typ g1;

        while(getline(file, line)) {
            if(line[0] == 't') {
                int hash_pos = line.find('#');
                int comma_pos = line.find(',');
                next_label = line.substr(hash_pos+2, comma_pos-hash_pos-2);
                //    next_label = line.substr(line.find(',')+1);
                //cout << endl;
                break;
            }
            if(line[0] == 'v') {
                line = line.substr(2);
                string vertex = line.substr(0, line.find(" "));
                string vertex_label = line.substr(line.find(" ")+1);
                int int_vertex = stoi(vertex);
                int int_vertex_label = stoi(vertex_label);
                add_vertex(vertex_prop(int_vertex_label), g1);
                // cout << vertex <<  " " << vertex_label << endl;
            }
            if(line[0] == 'u') {
                line = line.substr(2);
                int v1 = stoi(line.substr(0, line.find(" ")));
                line = line.substr(line.find(" ")+1);
                int v2 = stoi(line.substr(0, line.find(" ")));
                line = line.substr(line.find(" ")+1);
                int edge_label = stoi(line);
                add_edge(v1, v2, edge_prop(edge_label), g1);
                
                // cout << v1 << " " << v2 <<  " " << edge_label << endl;
            }
        }
        fsg_labels.push_back(label);
        fsg_graphs.push_back(g1); // qqqqqqqqqqqqqqqqqq
        feature_label_to_index[label] = idx;
        idx++;
        // SelectedFeatureLabels.push_back(label);
    }
    file.close();
    // cout << labelMap_FSG.size() << endl;
}

void readFeatureVectors(string filename) {
    ifstream file(filename);
    string line;
    while(getline(file, line)) {
        data_feature_vectors.push_back(line);
    }
    file.close();
}

void pre_process_queries(string query_file, string map_flag) {
    string cmd1 = "python3 convert_format.py " + query_file + " " + map_flag;
    system(cmd1.c_str());
}


void convertQueryToBoost(string filename) {
    cout << "in dataToBoost, file name: " << filename << endl;
    ifstream file(filename);
    string line;

    string next_label;
    string label;
    getline(file, line);
    next_label = line.substr(line.find("#")+1);
    int c=0;
 
    // while (getline(file, line)) {
    while (file.peek() != EOF) {        
        string label = next_label;
        c++;
        // cout << label << endl;
        // labelMap_Data[label] = graph();
        graph_typ g1;

        while(getline(file, line)) {
            if(line[0] == 't') {
                next_label = line.substr(line.find("#")+1);
                break;
            }
            if(line[0] == 'v') {
                line = line.substr(2);
                string vertex = line.substr(0, line.find(" "));
                string vertex_label = line.substr(line.find(" ")+1);
                int int_vertex = stoi(vertex);
                int int_vertex_label = stoi(vertex_label);
                add_vertex(vertex_prop(int_vertex_label), g1);
                // cout << vertex <<  " " << vertex_label << endl;
            }
            if(line[0] == 'u') {
                line = line.substr(2);
                int v1 = stoi(line.substr(0, line.find(" ")));
                line = line.substr(line.find(" ")+1);
                int v2 = stoi(line.substr(0, line.find(" ")));
                line = line.substr(line.find(" ")+1);
                int edge_label = stoi(line);
                add_edge(v1, v2, edge_prop(edge_label), g1);
               // cout << v1 << " " << v2 <<  " " << edge_label << endl;
            }
        }
        
       
        query_labels.push_back(label);
        query_graphs.push_back(g1); // qqqqqqqqqqqqqqqqqq
  
     
    }
    file.close();
    // cou << labelMap_Data.size() << endl;
}

template <typename Graph1,
            typename Graph2>
class my_call_back {

public:
    my_call_back(const Graph1& graph1, const Graph2& graph2) : graph1_(graph1), graph2_(graph2) {}

    template <typename CorrespondenceMap1To2, typename CorrespondenceMap2To1>
    bool operator()(CorrespondenceMap1To2 f, CorrespondenceMap2To1) {
        return true;
    }
    std::vector <std::vector <std::pair<int, int>>> get_setvmap() { return set_of_vertex_iso_map; }

private:
    const Graph1& graph1_;
    const Graph2& graph2_;
    std::vector <std::vector <std::pair<int, int>>> set_of_vertex_iso_map;
    std::vector <std::pair<int, int>> vertex_iso_map;   
};



bool test_isomorphism(graph_typ &small, graph_typ &large) {
    vertex_comp_t vertex_comp = make_property_map_equivalent(get(vertex_name, small), get(vertex_name, large));
    edge_comp_t edge_comp = make_property_map_equivalent(get(edge_name, small), get(edge_name, large));
    my_call_back<graph_typ, graph_typ> callback(small, large);
    return vf2_subgraph_iso(small, large, callback, vertex_order_by_mult(small),edges_equivalent(edge_comp).vertices_equivalent(vertex_comp));
}

string createFeatureVector(graph_typ &g1) {
    string feature_vec = "";
    for(int i=0; i<SelectedFeatureIndices.size(); i++) {
        int idx = SelectedFeatureIndices[i];
        graph_typ g2 = fsg_graphs[idx];
        if(test_isomorphism(g2, g1)) {
            feature_vec += "1";
        }
        else {
            feature_vec += "0";
        }
    }
    return feature_vec;
}

bool compare_fv(string &query_fv, string &data_fv) {
    // compare two feature vectors
    int n = query_fv.size();
    for(int i=0; i<n; i++) {
        if(query_fv[i] == '1') {
            if(data_fv[i] == '0') {
                return false;
            }
        }
    }
    return true;
}

void process_query() {
    // create FV for every query
    // then iterate over all graphs
    // if fv of query in fv of graph, then do isomorphism test
 
    for(int i=0; i<query_labels.size();i++) {
       
        string query_label = query_labels[i];
        cout << "Processing, query label: " << query_label << endl;
        graph_typ query_graph = query_graphs[i];
	
	int unpruned_count = 0;
        
	string query_fv = createFeatureVector(query_graph);
        
	//cout << "fv: " << query_fv << endl;
	vector<string> temp;
	query_outputs.push_back(temp);
	
	
        for(int j=0; j<data_labels.size();j++) {
	    //cout << "11111" << endl;
            string data_label = data_labels[j];
            // cout << "Processing, data label: " << data_label << endl;
            graph_typ data_graph = data_graphs[j];
            string data_fv = data_feature_vectors[j];
	    //cout << data_label << endl;
	    //cout << "222" << endl;
            if(compare_fv(query_fv, data_fv)) {
            //if (true) {
            //cout << "333" << endl;
                // cout << "fv match" << endl;
                //cout << "did not prune: " + data_label << "\n"; 
                unpruned_count++;
		//cout << test_isomorphism(query_graph, data_graph);
                if(test_isomorphism(query_graph, data_graph)) {
                    // cout << "match found" << endl;
                    // cout << query_label << " " << data_label << endl;
                    // cout << test_isomorphism(query_graph, data_graph);
                   //cout << "5555" << endl;
                   query_outputs[i].push_back(data_label);
                }
            }
            //cout << "444"<< endl;
   
        }
	cout << "total iso tests: " << unpruned_count << endl;
        
    }
}

void write_output() {
    ofstream file("output_CS5191077.txt");
    for(int i=0; i<query_labels.size();i++) {  
        
        vector<string> data_labels = query_outputs[i];
        // file << query_label << " ";
        for(int j=0; j<data_labels.size(); j++) {
            file << data_labels[j] << "\t";
        }
        file << endl;
    }
}

int main(int argc, char *argv[]) {
    // read feature vectors
    // create boost graphs for all (in map)

    // ask for query file
    // read query file
    // start time
    // for each query graph, do tests, and output
    // stop time
    //
    
    //test_iso_stuff();
   string dataset_file;
   ifstream filee("data_path.txt");
   getline(filee,dataset_file);
   filee.close();
    

    string infile_converted = dataset_file.substr(0, dataset_file.find_last_of('.'));

    convertDatasetToBoost(infile_converted + "_fsg.txt");
    // as I read from fsg input file, and not original input file

    // read selected features
    ifstream file("features_all.txt");
    string line;
    
     
    convertFsgToBoost(infile_converted + "_fsg.fp");
    readFeatureVectors("feature_vectors.txt");

    while(getline(file, line)) {
        SelectedFeatureIndices.push_back(feature_label_to_index[line]);
        //cout << feature_label_to_index[line] << endl;
      }
        
    // now ask for query file
    string query_file;
    cout << "Please enter path to query file: ";
    cin >> query_file;

    pre_process_queries(query_file,"use_map");
    
    string query_root = query_file.substr(0, query_file.find_last_of('.'));

    auto begin = high_resolution_clock::now();
    convertQueryToBoost(query_root + "_fsg.txt");

    process_query();

    write_output();
    auto end = high_resolution_clock::now();
    auto duration = duration_cast<milliseconds>(end - begin);
    cout << "Queries processed in: " << duration.count() << " milliseconds" << endl;
}
