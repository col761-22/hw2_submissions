#!/bin/sh
chmod +x pafi-1.0.1/Linux/fsg
g++ -O3 index_new.cpp -o index_new
./index_new $1 25 1.5
