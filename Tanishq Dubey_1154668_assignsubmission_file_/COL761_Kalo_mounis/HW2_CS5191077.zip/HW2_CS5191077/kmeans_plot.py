# %%
from sklearn.cluster import KMeans
from scipy.spatial.distance import cdist
import numpy as np
import matplotlib.pyplot as plt
import sys

# %%
# Creating the data
X = np.loadtxt(sys.argv[1])

# %%
distortions = []
inertias = []
mapping1 = {}
mapping2 = {}
K = range(1, 16)

for k in K:
    # Building and fitting the model
    kmeanModel = KMeans(n_clusters=k).fit(X)
    kmeanModel.fit(X)

    distortions.append(sum(np.min(cdist(X, kmeanModel.cluster_centers_,
                                        'euclidean'), axis=1)) / X.shape[0])
    inertias.append(kmeanModel.inertia_)


# %%
plt.figure(figsize=(10, 10))
plt.plot(K, distortions, 'bx-')
plt.xlabel('Values of K')
plt.ylabel('Distortion (Euclidean Distance)')
plt.title('The Elbow Method using Distortion (Euclidean Distance)')
plt.savefig(sys.argv[3])
print("Saved figure")
