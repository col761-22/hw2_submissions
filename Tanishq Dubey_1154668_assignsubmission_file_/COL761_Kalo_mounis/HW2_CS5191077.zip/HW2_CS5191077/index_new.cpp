#include<bits/stdc++.h>

using namespace std;

void mineFrequentSubgraphs(int support, string dataset_file) {

    float supp = support * 1.0;

    string infile_converted = dataset_file.substr(0, dataset_file.find_last_of('.'));
    string cmd1 = "python3 convert_format.py " + dataset_file;
    string cmd2 = "./pafi-1.0.1/Linux/fsg -s " + to_string(supp) + " " + infile_converted + "_fsg.txt -p -t";
    string cmd3 = "python3 fsg_out_to_req_file.py " + infile_converted + "_fsg.fp " + infile_converted + "_fsg.pc";
    system(cmd1.c_str());
    system(cmd2.c_str());
    system(cmd3.c_str());

    // int dataset_size = 64110; 
}

void selectFeatures(string infile, float gamma, int graphSize) {
    string cmd = "python select_features.py " + infile + " " + to_string(gamma) + " " + to_string(graphSize);
    cout << cmd << endl;
    system(cmd.c_str());    
}

void makeFeatureVectors(string tid_file, int dataset_size) {
    string cmd = "python make_feature_vectors.py " + tid_file + " " + to_string(dataset_size);
    cout << cmd << endl;
    system(cmd.c_str());
    return;
}

int main(int argc, char *argv[]) {
    string dataset_file = argv[1];
    int support = stoi(argv[2]);
    float gamma = stof(argv[3]);

    ofstream f1("data_path.txt");
    f1 << dataset_file;
    f1.close();

    string infile_root = dataset_file.substr(0, dataset_file.find_last_of('.'));

    cout << "mining subgraphs...........\n";
    mineFrequentSubgraphs(support, dataset_file);

    int dataset_size = 64110;
    ifstream file("number.txt");
    string line;
    getline(file, line);
    dataset_size = stoi(line);
    selectFeatures(infile_root + "_fsg_index.txt", gamma, dataset_size);

    makeFeatureVectors(infile_root + "_fsg.tid", dataset_size);
    
}

