import os
import re
import sys

"""
#graphID
# of nodes
Series of Node Labels
# of edges
Series of “Source node, Destination Node, Edge label”
"""

def convert_fsg_map_not_exist(input_lines, output_file_fsg):
    number_graphs = open("number.txt", 'w')
    output_fsg = open(output_file_fsg, 'w')
    v_flag = 0
    e_flag = 0
    count = 0
    gcount = 0

    word_to_int = dict()
    vcount = 1
    
    for line in input_lines:
        line = line.lstrip().rstrip()
        if line == '':
            continue
        if line[0] == '#':
            # contains trans number
            gcount += 1
            count = 0
            v_flag = 0
            e_flag = 1
            write_line = 't ' + line + '\n'
            output_fsg.write(write_line)
        elif line.isdigit():
            # vertices or edges desc start here
            # invert flags
            v_flag = 1 - v_flag
            e_flag = 1 - e_flag
        elif e_flag:
            write_line = 'u ' + line + '\n'
            output_fsg.write(write_line)
        elif v_flag:
            count = count+1
            if line not in word_to_int:
                word_to_int[line] = vcount
                vcount = vcount+1 
            write_line = 'v ' + str(count-1) + ' ' + str(word_to_int[line]) + '\n'
            output_fsg.write(write_line)
    
    number_graphs.write(str(gcount))
    number_graphs.close()
    output_fsg.close()

    file = open('atom_to_int.txt','w')
    for data in word_to_int:
        atom = data
        atom_code = word_to_int[atom]
        file.write(str(atom)+ " " + str(atom_code)+"\n")
    file.close()
    return

def convert_fsg_map_exist(input_lines, output_file_fsg):
    number_graphs = open("number.txt", 'w')
    output_fsg = open(output_file_fsg, 'w')
    v_flag = 0
    e_flag = 0
    count = 0
    gcount = 0
    
    word_to_int = dict()

    file = open('atom_to_int.txt','r')
    ls = file.readlines()
    for l in ls:
        data = l.split(' ')
        data[-1] = data[-1].replace("\n","")
        word_to_int[data[0]] = int(data[1])
    file.close()

    vcount = 1
    
    for line in input_lines:
        line = line.lstrip().rstrip()
        if line == '':
            continue
        if line[0] == '#':
            # contains trans number
            gcount += 1
            count = 0
            v_flag = 0
            e_flag = 1
            write_line = 't ' + line + '\n'
            output_fsg.write(write_line)
        elif line.isdigit():
            # vertices or edges desc start here
            # invert flags
            v_flag = 1 - v_flag
            e_flag = 1 - e_flag
        elif e_flag:
            write_line = 'u ' + line + '\n'
            output_fsg.write(write_line)
        elif v_flag:
            count = count+1
            if line not in word_to_int:
                word_to_int[line] = vcount
                vcount = vcount+1 
            write_line = 'v ' + str(count-1) + ' ' + str(word_to_int[line]) + '\n'
            output_fsg.write(write_line)
    
    number_graphs.write(str(gcount))
    number_graphs.close()
    output_fsg.close()
    return

if __name__ == '__main__':
    input_file_name = sys.argv[1]
    map_flag= "create_map" # create_map, use_map
    
    if len(sys.argv) > 2:
        map_flag = sys.argv[2]


    input_file_name_list = input_file_name.split('.')
    output_file_fsg = input_file_name_list[0] + '_fsg.txt'
    output_file_gspan = input_file_name_list[0] + '_gspan.txt'
    output_file_gaston = input_file_name_list[0] + '_gaston.txt'    
    # output_file_fsg = input_file_name[:-4] + '_fsg.txt'
    # output_file_gspan = input_file_name[:-4] + '_gspan.txt'
    # output_file_gaston = input_file_name[:-4] + '_gaston.txt'

    input_object = open(input_file_name, 'r')
    input_lines = input_object.readlines()
    input_object.close()

    # fsg
    if not map_flag == "use_map":
        convert_fsg_map_not_exist(input_lines, output_file_fsg)
    else:
        convert_fsg_map_exist(input_lines, output_file_fsg)

    # gspan/Gaston (both require same format)
    # convert_others(input_lines, output_file_gspan, output_file_gaston)
    
