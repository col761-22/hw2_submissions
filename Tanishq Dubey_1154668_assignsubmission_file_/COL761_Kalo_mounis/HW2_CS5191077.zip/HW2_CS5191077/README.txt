GITHUB REPO
-----------------
https://github.com/tanishq1420/COL761_Kalo_mounis

Contribution
------------------
Goncalo Batalhao Alves, 2022VST9500 - 33.33% - Q2,Q3
Kshitiz Bansal, 2019CS50438 - 33.33% - Q1,Q2
Tanishq Dubey, 2019CS51077 - 33.33% - Q2, Submission


Files
-------------------
index.sh                 
query.sh 
convert_format.py - converts given dataset to format usable by fsg
make_feature_vectors.py - creates feature vectors for dataset
fsg_out_to_req_file.py - converts fsg output to required format for feature selection     
select_features.py - feature selection i.e m
index_new.cpp - indexing main code         
query_new3.cpp - querying main code

Usage:
-----------------
sh index.sh <dataset>
sh query.sh

