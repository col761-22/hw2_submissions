
# Converts fsg output frequent subgraphs to our index file
# run as: python fsg_to_req_file.py {name.fp} {name.pc}
# will generate {name_index.txt}

# slight change in format (for easy readability):
### graph_id
### support
### number_of_parents parent1 parent2 ... parentN

import sys


def convert_to_index_file(infile_fp, infile_pc, outfile):
    input_obj_fp = open(infile_fp, 'r')
    input_lines_fp = input_obj_fp.readlines()
    input_obj_fp.close()

    input_obj_pc = open(infile_pc, 'r')
    input_lines_pc = input_obj_pc.readlines()
    input_obj_pc.close()

    output_object = open(outfile, 'w')

    fsg_support = {}
    # key: graph_id (string), value: support (int)
    for line in input_lines_fp:
        line = line.lstrip().rstrip()
        if line == '' or line[0] == '#':
            continue
        if line[0] == 't':
            word_list = line.split(' ')
            fsg_support[word_list[2][:-1]] = int(word_list[3])
    
    # now the parent child part
    fsg_parents = {}
    for line in input_lines_pc:
        line = line.lstrip().rstrip()
        word_list = line.split(' ')
        n = len(word_list)
        curr_list = []
        for i in range(1, n):
            curr_list.append(word_list[i])
        fsg_parents[word_list[0]] = curr_list
    
    # now write it out to a file
    for key in fsg_support:
        output_object.write(key + '\n')
        output_object.write(str(fsg_support[key]) + '\n')
        if len(fsg_parents[key]) > 0:
            output_object.write(str(len(fsg_parents[key])) + ' ' + ' '.join(fsg_parents[key]) + " null" + '\n')
        else:
            output_object.write(str(len(fsg_parents[key])) + ' ' + ' '.join(fsg_parents[key]) + "null" + '\n')
        # output_object.write(str(len(fsg_parents[key])) + '\n')
        # print(fsg_parents[key])
    
    output_object.close()
    return





if __name__ == "__main__":
    # will need both fp and pc files
    # as fp contains support values, pc contains parent-child info
    input_file_fp = sys.argv[1]
    input_file_fp_list = input_file_fp.split('.')

    input_file_pc = sys.argv[2]

    output_file_name = input_file_fp_list[0] + '_index.txt'
    convert_to_index_file(input_file_fp, input_file_pc, output_file_name)
    
   
