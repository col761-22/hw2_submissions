#!bin/sh
g++ -O3 query_new3.cpp -o query_new
./query_new 
