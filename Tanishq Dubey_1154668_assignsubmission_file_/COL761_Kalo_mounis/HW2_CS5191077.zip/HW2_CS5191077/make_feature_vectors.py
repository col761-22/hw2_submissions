import sys

def make_feature_vectors(tid_file, dataset_size):
    input_obj_tid = open("features_all.txt", 'r')
    input_lines_tid = input_obj_tid.readlines()
    input_obj_tid.close()

    features = [l.lstrip().rstrip() for l in input_lines_tid]
    
    root = []
    for i in range(0, dataset_size):
        root.append("0")
    feature_vectors = []
    for i in range(0, len(features)):
        feature_vectors.append(root.copy())
        # feature_vectors.append(root)
    # feature_vectors = [root]*len(features)

    # print(len(feature_vectors))
    # print(len(feature_vectors[0]))
    input_obj = open(tid_file, 'r')
    while True:
        line = input_obj.readline().replace("\n","")
        if not line:
            break
        line_list = line.split(" ")
        label = line_list[0]
        if label in features:
            for ind in line_list[1:]:
                # print(label, features.index(label), ind)
                feature_vectors[features.index(label)][int(ind)] = "1"
    
    input_obj.close()
    output_obj = open("inverse_feature_vectors.txt", 'w') # in same order as features_all.txt
    for vec in feature_vectors:
        output_obj.write("".join(vec) + "\n")
    output_obj.close()

    output_obj = open("feature_vectors.txt", 'w')
    for j in range(dataset_size):
        inverse_list = []
        for i in range(len(features)):
            inverse_list.append(feature_vectors[i][j])
        output_obj.write("".join(inverse_list) + "\n")
        # output_obj.write(str(j) + " " + "".join(inverse_list) + "\n")
    output_obj.close()



if __name__ == "__main__":
    make_feature_vectors(sys.argv[1], int(sys.argv[2]))