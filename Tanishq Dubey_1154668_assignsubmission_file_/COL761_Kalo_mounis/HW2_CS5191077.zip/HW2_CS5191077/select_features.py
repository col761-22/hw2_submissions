import sys
import math

def phi(numedges):
    alpha = math.log(11)/10
    y = math.exp(alpha * numedges) - 1
    return int(y)

def selectFeatures(infile, gamma, graphSize):
    # infile =  file with each frequent pattern, support and its children
    file = open(infile, 'r')
    features = {"null": graphSize}
    while True:
        gID = file.readline().replace("\n","")
        if not gID: # EOF
            break
        supp = int(file.readline().replace("\n",""))
        numChildren, children = file.readline().split(' ', 1)
        numChildren = int(numChildren)
        children = children.split(' ')
        children[-1] = children[-1].replace("\n","")

        minChildSupp = 1000000000

        edges = int(gID.split('-')[0])
    
        for child in children:
            if child in features.keys():
                minChildSupp = min(minChildSupp, int(features[child]))
        
        if (minChildSupp >= gamma * supp) and (supp >= phi(edges)) : 
            features[gID] = supp
    print("len features:", len(features))

    file = open("features_all.txt",'w')

    for lbl in features.keys():
        if lbl == "null":
            continue
        file.write(lbl + "\n")
    file.close()
    return features

selectFeatures(sys.argv[1], float(sys.argv[2]), sys.argv[3])