#include "fptree.h"
ofstream output;
vector<vector<string> > frequentPatterns;

FPTree::FPTree(string file, int sup, int tot) {

    totalTransactions = tot;
    infile = file;
    support = sup;

    root = new Node(-1,0,NULL);

}

void FPTree::constructTree() {

    ifstream file(infile);
    string line, item;
    
    while(file) {
        getline(file, line);
        if(!line.size()) continue;

        stringstream s(line);

        vector<pair<int,int>> txn;

        while(s >> item) {
            if (frequencyItem[stoi(item)]*100  >= support*totalTransactions) {
				txn.push_back({stoi(item),1});
			} 
        }
	
        sort(txn.begin(), txn.end(), [this](pair<int,int>x, pair<int,int> y){return this->cmpItems(x,y);});
	
        insertTransaction(txn);

    }

    file.close();
}

void FPTree::constructCondTree(vector<Node*> &itemNodes) {

	for (int i=0; i<itemNodes.size(); i++) {
		vector<pair<int,int> > transaction;
		Node* curr = itemNodes[i]->parent;

		while(curr->item != -1) {
			if (frequencyItem[curr->item]*100 >= support*totalTransactions) {
				transaction.push_back({curr->item, itemNodes[i]->value});
			}
			curr = curr->parent;
		}
		
		// delete curr;
        
        	sort(transaction.begin(), transaction.end(), [this](pair<int,int>x, pair<int,int> y){return this->cmpItems(x,y);});
		insertTransaction(transaction);
	}

}

void FPTree::computeFrequency_init() {

    ifstream file(infile);
    string line, item;
    
    while(file){
        getline(file, line);
        if(!line.size()) continue;

        totalTransactions++;

        stringstream s(line);
    
        while(s >> item) {
            frequencyItem[stoi(item)]++;   
            // if(stoi(item)==1) cout << 1 << endl;
        }
    }
    
    // cout << frequencyItem[1] << endl;

    file.close();

}

bool cmpPair(pair<int,int> &A, pair<int,int> &B) {
    return A.second > B.second;
}

void FPTree::populateItemRank() {

    for(auto &entry : frequencyItem) {

        int item = entry.first;
        int count = entry.second;
        
        //cout << item << ":" << count << endl;

        if(count*100 < support*totalTransactions) {
        	// cout << item << ":" << count << endl;
        	continue;
        }

        flist.push_back(entry);
    }

    sort(flist.begin(),flist.end(), &cmpPair);


	for (int i=0; i<flist.size(); i++) {
        	rankItem[flist[i].first] = i;
	}

}

void FPTree::computeFrequency(vector<Node*> &itemNodes) {

	//cout << "x" << endl;
	
	//cout << itemNodes.size()<<endl;
	
	for (int i=0; i<itemNodes.size(); i++) {
		// cout << "y" << endl;
		//if(itemNodes[i]->parent==NULL) cout << "xxxxx" << endl;
		Node* curr = itemNodes[i]->parent;
		//cout << itemNodes[i]->parent->value << endl;
		// cout << "zz" << endl;
		while(curr->item!=-1) {
			// cout << "z" << endl;
			//cout << "C: " << curr->item << endl;
			//if(curr == NULL) cout << "xxxx" << endl;
			frequencyItem[curr->item] += itemNodes[i]->value;
			curr = curr->parent;
			//cout << "x" << endl;
			//cout << curr->item << endl;
			//cout << "y" << endl;
		}
		// cout << "abc" << endl;
		// delete curr;
	}

}

bool FPTree::cmpItems(pair<int,int> &A, pair<int,int> &B) {

    if (frequencyItem[A.first] != frequencyItem[B.first]) {
        return frequencyItem[A.first] > frequencyItem[B.first];
    }
    else {
        return rankItem[A.first] < rankItem[B.first];
    }
}


void FPTree::insertTransaction(vector<pair<int,int> > &txn) {

    Node* curr = root;
 
    for(int j=0; j<txn.size(); j++) {

        int item = txn[j].first;
        int count = txn[j].second;
        bool found = 0;

        for(int i=0; i<curr->children.size(); i++) {

            Node* child = curr->children[i];

            if(child->item == item) {
            
                child->value += count;
                found = 1;
                curr = child;
                break;
                
            }
            
            // delete child;

        }

        if(!found) {
            Node* new_node = new Node(item, count, curr);
            curr->children.push_back(new_node);
            headerTable[item].push_back(new_node);
            curr = new_node;
            // delete new_node;
        }

    }
    
    // delete curr;

}

void FPTree::deallocateTree() {

	
	delete root;
	

	for(auto &entry: headerTable) {
	
		for(int i=entry.second.size()-1;i>=0; i--) {
		
			delete entry.second[i];
			
		}
	
	}

}

void FPTree::FPGrowth(vector<int> &candidates, vector<Node*> &itemNodes) {

    int totalCount=0;

	for (int i=0; i<itemNodes.size(); i++) {
		totalCount+=itemNodes[i]->value;
	}
	//cout << "cands: ";
	/*
	for(int i=0;i<candidates.size();i++) {
		cout << candidates[i] << " ";
	} cout << endl;
	*/
    
    if(totalCount*100 < support*totalTransactions) {
    	//cout << "term" << endl;
    	//deallocateTree();
    	return;
    }
    
    //cout << "d1" << endl;
    //cout << "xxx:" << itemNodes[0]->item << endl;
    vector<int> candidates2 = candidates;
    candidates2.push_back(itemNodes[0]->item);
       
    vector<string> candidates_string;
    for(int i=0;i<candidates2.size();i++) {
    
    	candidates_string.push_back(to_string(candidates2[i]));
    
    }

    sort(candidates_string.begin(), candidates_string.end());
    // cout << candidates_string[0] << endl;
    //cout << "d2" << endl;
    //frequentPatterns.push_back(candidates_string);

    for(int i=0; i<candidates_string.size(); i++) {
	output << candidates_string[i];

	if(i != candidates_string.size()-1) output << " " ;
    } output << endl;

    FPTree cfptree(infile, support, totalTransactions);
    cfptree.computeFrequency(itemNodes);
    //cout << "d3" << endl;
    cfptree.populateItemRank();
    cfptree.constructCondTree(itemNodes);
    //cout << "d4" << endl;
    cfptree.mineFrequentPatterns(candidates2);
    
    //cout << "d5" << endl;

}

void FPTree::mineFrequentPatterns(vector<int> &candidates) {
	
	//cout << "aaa" << endl;
	//cout << "mining with cs: " ;
	/*
	for(int i=0;i<candidates.size();i++) {
	
		cout << candidates[i] << " ";
	} cout << endl;
	*/
	
	for (int i=flist.size()-1; i>=0; i--) {
		FPGrowth(candidates, headerTable[flist[i].first]);
	}
	
	deallocateTree();
	
	
}

void FPTree::initState() {
    computeFrequency_init();
    populateItemRank();
    constructTree();
    
}


int main(int argc, char* argv[]) {
  	
    string infile = argv[1], outfile = argv[3];
    int support = atoi(argv[2]);
    
    auto start = high_resolution_clock::now();

    FPTree fptree(infile, support, 0);
    
    vector<int> empty;

    output.open(outfile);

    fptree.initState();
    fptree.mineFrequentPatterns(empty);
    
    /*
    sort(frequentPatterns.begin(), frequentPatterns.end());
	
    for(int i=0;i<frequentPatterns.size();i++) {
	for(int j=0;j<frequentPatterns[i].size();j++) { 
	
	  output << frequentPatterns[i][j];
	  
	  if(j!=frequentPatterns[i].size()-1) {
	  	output<<" ";
	  }
	}
	output << endl;
    }
    */

    output.close();

    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);
    
    if(argc > 4 && strcmp(argv[4],"-plot")==0) {
	    string time_file = "time_fptree";
	    ofstream time_file_stream;
	    time_file_stream.open(time_file, std::ios_base::app);
	    time_file_stream << duration.count()*(1e-6) << " " << support << endl;
	    time_file_stream.close();
    }
    
    string cmd = "export LC_ALL=C; sort " + outfile + " > temp; mv temp " + outfile;

    //system("export LC_ALL=C");
    //int a = system(cmd1.c_str());
    int a = system(cmd.c_str());
    //a = system(cmd3.c_str());

    return 0;
}




