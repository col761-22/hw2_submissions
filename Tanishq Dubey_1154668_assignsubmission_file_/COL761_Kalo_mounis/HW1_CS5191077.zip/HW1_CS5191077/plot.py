import matplotlib.pyplot as plt
import sys

def plot_from_file(filename):
	f = open(filename, 'r')
	lines = f.readlines()

	ls = []

	for line in lines:
		vals = line.split()
		
		if(len(vals)==0):
			continue
		
		time = float(vals[0])
		supp = int(vals[1])
		ls.append((supp,time))

	ls.sort()

	x = [ l[0] for l in ls ]
	y = [ l[1] for l in ls ]

	plt.plot(x, y, label = filename.split('_')[1])

plot_from_file('time_apriori')
plot_from_file('time_fptree')

plt.xlabel('Supports (in %)')
plt.ylabel('Time taken (in sec)')

plt.legend()

plt.title('Apriori & FP-Growth Comparison')

img_save = sys.argv[1]

plt.savefig(img_save + '.png')


