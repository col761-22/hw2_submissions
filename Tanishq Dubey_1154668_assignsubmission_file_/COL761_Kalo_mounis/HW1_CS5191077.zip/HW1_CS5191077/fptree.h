#include "iostream"
#include "stdio.h"
#include "fstream"
#include "vector"
#include "string"
#include "sstream"
#include "map"
#include "unordered_map"
#include "unordered_set"
#include "limits"
#include "algorithm"
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <set>
#include <cstring>

using namespace std;
using namespace std::chrono;

class Node {

    public:

    int item, value;
    Node* parent;
    vector<Node*> children;

    Node(int item, int value, Node* parent) {
        this->item = item;
        this->value = value;
        this->parent = parent;
    }

};

class FPTree {

    unordered_map<int, vector<Node*> > headerTable;
    Node *root;

    unordered_map<int, int> frequencyItem;
    unordered_map<int,int> rankItem;
   
    vector<pair<int,int> > flist;

    int totalTransactions;
    
    int support;

    string infile;

    public:
    
        FPTree(string, int, int);

        bool cmpItems(pair<int,int>&, pair<int,int>&);

        void writeToFile(vector<int>&);

        void constructTree();
        
        void deallocateTree();

        void constructCondTree(vector<Node*>&);

        void computeFrequency_init(); 

        void populateItemRank();

        void computeFrequency(vector<Node*>&);

        void sortTransaction(vector<pair<int,int> >&);

        void insertTransaction(vector<pair<int,int> >&);

        void FPGrowth(vector<int>&, vector<Node*>&);

        void initState();

        void mineFrequentPatterns(vector<int>&);
        
};


