#include "iostream"
#include "stdio.h"
#include "fstream"
#include "vector"
#include "string"
#include "sstream"
#include "map"
#include "unordered_map"
#include "unordered_set"
#include "limits"
#include "algorithm"
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <chrono>
#include <set>
#include <cstring>

using namespace std;
using namespace std::chrono;

class Apriori {

    // Store union of F_i for all 1 <= i <= k
    vector<vector<string>> allFrequentItemSets;

    // Store F_i and C_i at any 1 <= i <= k
    vector<vector<string>> frequent_sets;
    vector<vector<string>> candidate_sets;

    // Support and Threshold
    float support;
    int threshold, num_transactions;

    // File path for dataset
    string filename;

    public:

        // Constructor
        Apriori(string, float);

        // Initialize Candidate Subset - C_1
        void initCandidate();

        // Generate F_i from C_i
        void findFrequentItemSets();

        // Generate C_i from F_(i-1)
        void generateCandidates();

        // Check if we can prune candidate c in C_i using meta data F_(i-1)
        bool canPruneCandidate(vector<string>&);

        // Check if candidate c is a subset of transaction t
        bool checkSubset(vector<string>&, unordered_set<string>&);

        // Check if an itemset is present in F_i 
        bool foundItemSet(vector<string>&);

        //Display allFrequentItemSets
        void displayFrequentItemSets();
    
        // Driver function
        void mineFrequentItemSets();
        
};

