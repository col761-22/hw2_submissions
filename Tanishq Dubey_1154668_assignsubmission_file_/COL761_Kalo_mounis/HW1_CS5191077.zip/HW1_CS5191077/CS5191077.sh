#! /usr/bin/bash

if [ "$1" = "-apriori" ]; then
    ./apriori $2 $3 $4
elif [ "$1" = "-fptree" ]; then
    ./fptree $2 $3 $4
elif [ "$1" = "-plot" ]; then
	
    [ -f time_apriori ] && rm time_apriori
    [ -f time_fptree ] && rm time_fptree
    
    ./apriori $2 90 out.dat -plot
    ./apriori $2 50 out.dat -plot
    ./apriori $2 25 out.dat -plot
    ./apriori $2 10 out.dat -plot
    ./apriori $2 5 out.dat -plot

    ./fptree $2 90 out.dat -plot
    ./fptree $2 50 out.dat -plot
    ./fptree $2 25 out.dat -plot
    ./fptree $2 10 out.dat -plot
    ./fptree $2 5 out.dat -plot

    python3 plot.py $3
    # plot here | input data = $2, output file = $3
else
	echo "Argument is not valid!"
fi

