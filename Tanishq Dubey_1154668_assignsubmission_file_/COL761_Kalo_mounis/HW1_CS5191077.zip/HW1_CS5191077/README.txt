	REPO 
---------------------------------------------
https://github.com/mjaykgupt/COL761_Kalo_mounis

	TEAM
---------------------------------------------
TANISHQ DUBEY - 2019CS51077 - 33.33% - Apriori, FPT Implementation, Plotting, Testing 
KSHITIZ BANSAL - 2019CS50438 - 33.33% - FPT Implementation and Apriori Debugging
MRITUNJAY GUPTA - 2019CS10496 - 33.33% - Apriori Implementation, Testing, Debugging

	FILES
----------------------------------------------
fptree.h, fptree.cpp, apriori.h, apriori.cpp
compile.sh CS5191077.sh 
(Self-Explanatory Titles of Files)

	Q3 Observations and Explanation
----------------------------------------------
We clearly note that FP-Growth algorithm is significantly faster than Apriori algorithm. 
The time taken to execute the FP-growth algorithm is extremely less compared to Apriori algorithm for any Support level.

The reasons are as follows -
This algorithm needs to scan the database only twice when compared to Apriori which scans the transactions for each iteration.
FP-Growth algorithm also does not require to generate candidates. 
In Apriori execution time is more as time is wasted in producing candidates every time.


