g++ -O3 fptree.cpp -o fptree
g++ -O3 apriori.cpp -o apriori

