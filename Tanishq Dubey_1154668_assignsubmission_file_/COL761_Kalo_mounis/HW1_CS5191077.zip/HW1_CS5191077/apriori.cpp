#include "apriori.h"

ofstream output_file_stream;

Apriori::Apriori(string dataset_name, float support) {

    filename = dataset_name;
    this->support = support;
    num_transactions = 0;

}

void Apriori::initCandidate() {
    ifstream file(filename);
    string line, item;
    set<string> candidates; // set so they are kept sorted
    //cout << "Dataset is  : \n";
    while(file){
        getline(file, line);
        if(!line.size()) continue;

        num_transactions++;
        stringstream s(line);
        while(s >> item)
            candidates.insert(item);
    }
    for(auto& str: candidates){
        candidate_sets.push_back(vector<string>{str}); // sorted order
    }
    
    threshold = ceil(num_transactions * support / 100);
    file.close();
}

void Apriori::findFrequentItemSets() {

    int n = candidate_sets.size();
    vector<int> counter(n, 0);

    ifstream file(filename);
    string line, item;
    while(file){
        getline(file, line);
        if(!line.size()) continue;

        stringstream s(line);
        unordered_set<string> transaction;
        while(s >> item)
            transaction.insert(item);

        for(int i=0; i<n; i++){
            if(checkSubset(candidate_sets[i], transaction))
                counter[i]++;
        }
    }
    file.close();

    for(int i=0; i<n; i++){
        if(counter[i] >= threshold){
            frequent_sets.push_back(candidate_sets[i]);
            // allFrequentItemSets.push_back(candidate_sets[i]);

	    for(int j=0; j< candidate_sets[i].size(); j++) {
		output_file_stream << candidate_sets[i][j];

		if(candidate_sets[i].size()-1 != j) output_file_stream << " ";
	    } output_file_stream << endl;

        }
    }

}

bool isMergeable(vector<string> set1, vector<string> set2) {
    int size = set1.size();
    for(int i=0; i<size-1; i++) {
        if(set1[i] != set2[i]) return false;
    }
    return true;
}

// vector<string> mergeSets(vector<string> set1, vector<string> set2) {

//     int size = set1.size();
//     set1.push_back(set2[size-1]);
//     if(set1[size-1] > set1[size]) swap(set1[size-1], set1[size]);
//     // for(int i=0; i<size-1; i++) {
//     //     mergedSet.push_back(set1[i]);
//     // }
//     // string last1 = set1[size-1], last2 = set2[size-1];
//     // if(last1 > last2) swap(last1, last2);
//     // mergedSet.push_back(last1);
//     // mergedSet.push_back(last2);
//     return set1;
// }

void Apriori::generateCandidates() {
    for(int i=0; i<int(frequent_sets.size()); i++) {
        for(int j=i+1; j<int(frequent_sets.size()); j++) {
            if(isMergeable(frequent_sets[i], frequent_sets[j])) {
                // vector<string> merged_set = mergeSets(frequent_sets[i], frequent_sets[j]); 
                vector<string> merged_set = frequent_sets[i];
                int size = frequent_sets[i].size();
                merged_set.push_back(frequent_sets[j][size-1]);
                if(merged_set[size-1] > merged_set[size]) swap(merged_set[size-1], merged_set[size]);
                // do we need to pass them as arguments
                if(!canPruneCandidate(merged_set)) {
                   candidate_sets.push_back(merged_set);
                }
            }
        }
    }
}

bool Apriori::foundItemSet(vector<string>& itemSet) {
    auto itr = lower_bound(frequent_sets.begin(), frequent_sets.end(), itemSet);
    if(*itr != itemSet)
        return false;
    return true;
}

bool Apriori::canPruneCandidate(vector<string>& candidate) {
    for(int i = 0; i < int(candidate.size()); i++) {
        vector<string> candidate_subset;
        for(int j=0;j<int(candidate.size());j++) {
            if(j==i) continue;
            candidate_subset.push_back(candidate[j]);
        }
        if(!foundItemSet(candidate_subset)) {
            return true;
        }
    }
    return false;
}

bool Apriori::checkSubset(vector<string>& candidate, unordered_set<string>& transaction_set) {
    // O(m1 + m2)
    // unordered_set<string> transaction_set;
    // for(int i=0; i<transaction.size(); i++) {
    //     transaction_set.insert(transaction[i]);
    // }
    for(int i=0; i<int(candidate.size()); i++) {
        if(!transaction_set.count(candidate[i])) {
            return false;
        }
    }
    return true;   
}


void Apriori::mineFrequentItemSets() {

    initCandidate(); // C_1
    findFrequentItemSets(); // F_1
    for(int size=2 ; frequent_sets.size()>0 ; size++) {
        candidate_sets.clear();
        generateCandidates(); // populates candidates with C_size
        frequent_sets.clear();
        findFrequentItemSets(); // populates frequent_sets with F_size
        //cout << "Generated freq. sets of size " << size << " \n";
    }
}

void Apriori::displayFrequentItemSets(){
    sort(allFrequentItemSets.begin(), allFrequentItemSets.end());
    for(auto& itemSet: allFrequentItemSets){
        int n = itemSet.size();
        for(int i=0; i<n; i++)
            // cout << itemSet[i] << " \n"[i==n-1];
            output_file_stream << itemSet[i] << " \n"[i==n-1];
    }
}

int main(int argc, char** argv){

	//cout << argc << endl;
    
    string dataset_name = argv[1];
    float support = stof(argv[2]);
    string outputfile_name = argv[3];

    string outfile = outputfile_name;

    // freopen(outputfile_name.c_str(), "w", stdout);

    output_file_stream.open(outputfile_name);
    
    auto start = high_resolution_clock::now();

    Apriori apriori_obj(dataset_name, support);
    apriori_obj.mineFrequentItemSets();
    // apriori_obj.displayFrequentItemSets();

    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);
    // cout << "Time taken by function: "
    //      << duration.count() << " microseconds" << endl;

    // uncomment above to write out runtime in file
    
    if(argc > 4 && strcmp(argv[4],"-plot")==0) {
 
	    string time_file = "time_apriori";
	    ofstream time_file_stream;
	    time_file_stream.open(time_file, std::ios_base::app);
	    time_file_stream << duration.count()*(1e-6) << " " << support << endl;
	    time_file_stream.close();
    }
    
    output_file_stream.close();

    string cmd = "export LC_ALL=C; sort " + outfile + " > temp; mv temp " + outfile;

    //system("export LC_ALL=C");
    //int a = system(cmd1.c_str());
    int a = system(cmd.c_str());



    return 0;
}

