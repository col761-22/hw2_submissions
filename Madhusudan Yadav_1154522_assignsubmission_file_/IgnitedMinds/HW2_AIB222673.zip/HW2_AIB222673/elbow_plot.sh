#!/bin/bash
dataset='Q3/'$1
dimension=$2
plotname=$3
out_file="$3"

python3 Q3/elbow.py $dataset $dimension $plotname