import sys
import os
import time
import matplotlib.pyplot as plt

outfile=sys.argv[1]

support_values=[5.0, 10.0, 25.0, 50.0, 95.0]


algo = ['gspan', 'fsg', 'gaston']

total_trans = 64110
result_time = {}

for i in algo:
    result_time[i] = []

begin = time.time()
end = time.time()

for method in algo:

    data = method + '.txt'
    
    for support in support_values:
        
        gs = (support*total_trans)/100.0
        
        if(method=='gspan'):
            begin = time.time()
            cmd = 'chmod ug+x ./Q1/gSpan6/gSpan-64'
            cmd = './Q1/gSpan6/gSpan-64 -f ' + data + ' -s ' + str(support/100.0) + ' -o'
            os.system(cmd)
            end = time.time()
            result_time[method].append(end - begin)
        
        if(method=='fsg'):
            begin = time.time()
            cmd = 'chmod ug+x ./Q1/pafi-1.0.1/Linux/fsg'
            cmd = './Q1/pafi-1.0.1/Linux/fsg -s ' + str(support) + ' ' + data
            os.system(cmd)
            end = time.time()
            result_time[method].append(end - begin)
        
        if(method=='gaston'):
            begin = time.time()
            cmd = 'chmod ug+x ./Q1/gaston-1.1-re/gaston'
            cmd = './Q1/gaston-1.1-re/gaston ' + str(gs) + ' ' + data +  ' gaston.out'
            os.system(cmd)
            end = time.time()
            result_time[method].append(end - begin)
        
        

#print(result_time['gspan'])

plt.plot(support_values, result_time['gspan'], label = "gspan")
plt.plot(support_values, result_time['fsg'], label = "fsg")
plt.plot(support_values, result_time['gaston'], label = "gaston")
plt.xlabel("Min Support Value")
plt.ylabel("Time (in seconds)")
plt.legend()
plt.savefig(outfile)
