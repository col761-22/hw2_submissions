import os
import sys

dataset = sys.argv[1]
algo = sys.argv[2]

#newdata = dataset.replace('.txt','')
#print(newdata)
outdata = algo + '.txt'

newdata = open(dataset,'r') 
#datalines=newdata.readlines()
datalines = filter(None, (line.rstrip() for line in newdata))
#newdata.close()

outfile = open(outdata,'w')
gid = 0
temp=1
listofnodes = dict()
noofvertex = 0
vcount=0

for line in datalines:
    #print(line)
    if line[0]=='#':
        outfile.write('t # ' + str(gid) + '\n')
        gid += 1
        temp=1
        noofvertex=0
    
    #print(line.replace('\n',''))
    
    elif line.replace('\n','').isdigit() == True:
        temp = 1-temp
        noofvertex=0
    
    #print(temp)
    
    elif temp==0:
        if algo=='gspan' or algo=='gaston':
            node = line.replace('\n','')
            if node not in listofnodes:
                listofnodes[node] = vcount
                vcount += 1
            
            outfile.write('v ' + str(noofvertex) + ' ' + str(listofnodes[node]) + '\n')
            noofvertex += 1
        elif algo=='fsg':
            #noofvertex = 0
            outfile.write('v ' + str(noofvertex) + ' ' + line.replace('\n','') + '\n')
            noofvertex += 1
        else:
            print('Incorrect algo name provided')
    
    elif temp==1:
        if algo=='gspan' or algo=='gaston':
            outfile.write('e ' + line.replace('\n','') + '\n')
        elif algo=='fsg':
            outfile.write('u ' + line.replace('\n','') + '\n')
        else:
            print('Incorrect algo name provided')
    else:
        break

outfile.close()

   

    
