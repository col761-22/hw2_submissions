i> Explaining all the files we have bundled

Question 1:

Q1.sh : Bash file to execute dataFormat.py for different algorithms(gspan, fsg, gaston) and plot.py
dataFormat.py : Python file to convert the format of input dataset to required format of corrosponding algorithm.
plot.py : python file to plot the runtimes of all algorithms for given threshold values.

Also we bundled the packages of gSpan, fsg and gaston


Question 2:

index.py : Creates the index structure for the dataset and query

function.py : uses the index structure to prune the graphs and do the isomorphism



Question 3:

elbow_plot.sh : Bash file to execute elbow.py
elbow.py : Python file to plot the elbow curve after performing k-means clustering for diffrent k values(1-15) to find the optimal number of cluster(k).

Also bundled all generated datasets from HPC for different dimensions(2D, 3D, 4D).

------------------------------------------------------------------------------------------------------------------------------------------------------------

ii> Team Details and git repo link

Git Repo link : https://github.com/mkmindsiitd/IgnitedMinds.git

Madhusudan Kumar Yadav    	2022AIB2673
Ishan Anchit 		   	2019CS50434
Pallabi Mondal 	   		2022AIB2688


----------------------------------------------------------------------------------------------------------------------------------------------------------------

iii> Instructions to execute our code

Question 1:

Command to execute Q1.sh file -- sh Q1.sh <dataset> <outfilename>

for example, sh Q1.sh Yeast/167_graph.txt runtime

If we want to run the python files separately,
	command for dataFormat.py file -- python3 Q1/dataFormat.py <dataset> <algo_name> 
	
	for example, python3 Q1/dataFormat.py  Yeast/167_graph.txt gspan
	
	command for plot.py file -- python3 Q1/plot.py <outfile_name>
	
	for example, python3 Q1/plot.py timeplot
	


Question 3:

command to run elbow_plot.sh file -- sh elbow_plot.sh <dataset> <dimension> q3_<dimension>_<RollNo>

for example, sh elbow_plot.sh AIB222673_generated_dataset_2D.dat 2 q3_2_AIB222673
	     sh elbow_plot.sh AIB222673_generated_dataset_3D.dat 3 q3_3_AIB222673
	     sh elbow_plot.sh AIB222673_generated_dataset_4D.dat 4 q3_4_AIB222673


For executing elbow.py separately command is -- python3 Q3/elbow.py <dataset> <outfilename>

for example, python3 elbow.py AIB222673_generated_dataset_2D.dat q3_2_AIB222673.png


---------------------------------------------------------------------------------------------------------------------------------------------------------------

iv> Contribution

Madhusudan Kumar Yadav		2022AIB2673	---	33% contribution
Ishan Anchit			2019CS50434	---	33% contribution
Pallabi Mondal			2022AIB2688	---	33% contribution	          


-----------------------------------------------------------------------------------------------------------------------------------------------------------------
