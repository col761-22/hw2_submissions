#!/bin/bash
data=$1
plotname=$2
out_file="$plotname"

python3 Q1/dataFormat.py $data gspan
python3 Q1/dataFormat.py $data fsg
python3 Q1/dataFormat.py $data gaston
python3 Q1/plot.py $plotname 