import sklearn
from sklearn.cluster import KMeans
import numpy as np
from matplotlib import pyplot as plt
import sys
import os

dataset = sys.argv[1]
outplot = sys.argv[3]
X=[]
line_list = []
with open(dataset, 'r') as f:
    for line in f:
        #print('1',line.split())
        line_list.append(line.split())
        #pX.append(list(line))

#print(line_list)
for line in line_list:
    new_list = [float(i) for i in line]
    X.append(new_list)

X=np.array(X)
#print(X)

'''
X = np.array([[10, 2 , 9], [1, 4 , 3], [1, 0 , 3],
                   [4, 2 , 1], [4, 4 , 7], [4, 0 , 5], [4, 6 , 3],[4, 1 , 7],[5, 2 , 3],[6, 3 , 3],[7, 4 , 13],
                   [7, 6 , 10], [7, 9 , 15], [18, 7 , 9], [5, 20 , 16], [54, 6 , 19], [8, 0 , 5], [6, 19 , 25], [8, 7 , 9]])
'''

def calculate_wcss(X, K, labels, centroids):

    wcss = 0

    for i in range(K):
        clusterData = X[np.where(labels==i)]

        for points in clusterData:
            euclidian = np.linalg.norm(points-centroids[i])
            euclidian = euclidian**2
            wcss += euclidian
    
    return wcss

WCSS_list=[]
for K in range(1,16):

    kmeans = KMeans(n_clusters=K)
    kmeans.fit(X)

    labels = kmeans.labels_
    centroids = kmeans.cluster_centers_
    
    #print('FOR NO OF CLUSTER = ',K)
    #print(labels)
    #print(centroids)
    

    WCSS = calculate_wcss(X, K, labels, centroids)
    #print('WCSS FOR NO OF CLUSTER = ',K, WCSS)

    WCSS_list.append(WCSS)

#print(WCSS_list)


plt.figure(figsize=(12,6))
plt.plot(range(1,16), WCSS_list, marker="*", markersize=10)
plt.xlabel('Number of clusters')
plt.ylabel('wcss')
#plt.show()
plt.savefig(outplot)
#plt.legend()


