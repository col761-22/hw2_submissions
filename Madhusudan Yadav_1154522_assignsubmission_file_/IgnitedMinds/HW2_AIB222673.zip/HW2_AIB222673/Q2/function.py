from operator import truediv
import numpy as np
import pandas as pd
import warnings
import os
import sys

Query = sys.argv[1]

def index_checker(givenI, totalI, m, n):
    sorted = []
    for i in range(m):
        correct = True
        for j in range(n):
            if (givenI[j] == 1):
                if (totalI[i][j] == 0):
                    correct = False
        if (correct == True):
            sorted.append(i)
    return sorted


def prune(G, list):
    final = []
    for i in range(list.size()):
        final.append(G[list[i]])
    return final

def subgraph_check(G, query):
    X = []    
    cmd = './bin/vf3 ./test/bvg1.sub.grf ./test/bvg1.grf > x.txt'
    os.system(cmd)
    with open("x.txt",'r+') as f:
        lines=f.read().splitlines()
    for i in range(0, len(lines)):
        X.append(lines[i].split())
    x = int(X[0][0])
    return x

def sub_iso(Gfinal, Q):
    G_finl_final = []
    for i in range(Gfinal.size()):
        if (subgraph_check(Gfinal[i], Q) >= 1):
            G_finl_final.append(Gfinal[i])
    return G_finl_final


sorted2 = index_checker(givenI, totalI, m, n)
final_prune = prune(G, sorted2)
sub_iso(Gfinal, Q)
