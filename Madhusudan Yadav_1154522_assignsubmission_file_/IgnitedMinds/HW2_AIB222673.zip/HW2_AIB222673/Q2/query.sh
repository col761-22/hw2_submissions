#!/bin/bash
data=$1
out_file="$outfile_AIB222673"

python3 index.py $data
python3 function.py $data