from operator import truediv
import numpy as np
import pandas as pd
import warnings
import os
import sys

Graphs = sys.argv[1]

def index(G, m, n):
    ind = np.zeros((m, n))
    for i in range(m):
        for j in range(n):
            if (subgraph_check(G[i], j) >= 1):
                ind[i][j] = 1
    return ind


def subgraph_check(G, i):
    X = []    
    cmd = './bin/vf3 ./test/bvg1.sub.grf ./test/bvg1.grf > x.txt'
    os.system(cmd)
    with open("x.txt",'r+') as f:
        lines=f.read().splitlines()
    for i in range(0, len(lines)):
        X.append(lines[i].split())
    x = int(X[0][0])
    return x


index(Graphs, Graphs.size, 104)