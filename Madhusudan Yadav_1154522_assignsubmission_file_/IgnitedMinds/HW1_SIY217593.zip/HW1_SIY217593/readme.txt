

       Team Name - IgnitedMinds

_______________________________________________
Github Repo Link

https://github.com/mkmindsiitd/IgnitedMinds

_____________________________________________

Team Members Details

[1]
Himali Bajaj
Entry No - 2021SIY7593
Email ID - siy217593@cse.iitd.ac.in

[2]
Madhusudan Kumar Yadav
Entry No - 2022AIB2673
Email Id - aib222673@scai.iitd.ac.in

[3]
Pallabi Mondal
Entry No - 2022AIB2688
Email ID - aib222688@scai.iitd.ac.in

___________________________________________________

Files
-> SIY217593.sh
This file triggers the commands to execute Apriori or FP Tree algorithm on data or plots graph as per arguments provided.
Arguments to be passed-
Name of algorithm to be executed - 
	"-apriori" for Apriori algorithm
	"-fptree" for FP Tree algorithm
	"-plot" to plot runnning time vs support threshhold graph
DataSet Name
	Name of input test file
X
	Support threshhold in percentage
OutputFileName
	The name of file where output will be saved
Example - “./SIY217593.sh -apriori <dataset_name> X <outputFilename>” should generate an output text file containing the frequent itemset at >=X% support threshold with the
Apriori algorithm.

-> datamining.py - This contains the source code for Apriori and FP Tree algorithm as well as for plot
-> compile.sh - This generated compiled output of source code

Contributions

Himali Bajaj Percentage Contribution - 33
Entry No - 2021SIY7593
Himali implemented Apriori algothm and the plot part for plotting running time vs support threshhold graph and answering question related to it.
She also worked on creating various files as required - install.sh, compile.sh, readme.txt , rollnumber.sh in order and executing them as per specified format on hpc.

Madhusudan Kumar Yadav Percentage Contribution - 33
Entry No - 2022AIB2673
Madhusudan along with Pallabi woked on implementing FpTree algorithm. He also worked on setting up hpc connection in visual studio code.

Pallabi Mondal Percentage Contribution - 33
Entry No - 2022AIB2688
Pallabi along with Madhusudan worked on implementing FP Tree algorithm


Compare the performance between your implemented Apriori and FP-Tree algorithms
As clearly shown in plot generated ,running time of FP-tree is lesser than Apriori algorithm. 
This is because FP tree requires scanning of database lesser number of times ( twice),unlike  Apriori , making Apriori slower as disk 
access is much slower than in memory access.  Apriori also spends lot of execution time on generation of candidates.
It takes Breadth first approach unlike FP Tree that  takes Depth First Approach.
As support threshold increases , the running time of both Apriori and FP-tree decrease.
The decrease looks sharper for Apriori than FP Tree.