#!/bin/bash
#$1: algorithm, $2:dataset, $3: minimumsupport, $4: <outputfilename>
if [ "$1" = "-apriori" ] ; then
	python3 datamining.py $1 $2 $3 $4 > $4
elif [ "$1" = "-fptree" ]; then
 	python3 datamining.py $1 $2 $3 $4 > $4
elif  [ "$1" = "-plot" ] ; then
	python3 datamining.py $1 $2 $3
else
	echo "Invalid argument"
fi
