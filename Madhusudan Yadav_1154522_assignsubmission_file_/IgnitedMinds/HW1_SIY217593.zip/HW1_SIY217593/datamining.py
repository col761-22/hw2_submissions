import sys
import itertools
from itertools import chain
from collections import Counter
from telnetlib import NOOPT
import time
from collections import defaultdict

from matplotlib import pyplot as plt
import subprocess

algo = sys.argv[1]

dataFile = sys.argv[2]

if algo == "-plot":
    #print("plot")
    outputFile = sys.argv[3]    
else:
    #print("non plot")
    supportThresh= sys.argv[3]
    outputFile = sys.argv[4]


class vertex:
    def __init__(self, item, item_cnt = 0, parent = None, link = None):
        self.item=item
        self.item_cnt=item_cnt
        self.parent=parent
        self.link=link
        self.children={}


    ''' CONSTRUCT FP TREE CLASS AND METHODS'''

class FPtree:
    def __init__(self, data, min_sup , flag = True):
        self.data=data              #raw data and minimal support
        self.min_sup=min_sup

        self.root = vertex(item="Null", item_cnt=1)     #null root
        self.headtable=[]             #contain link of all nodes
        self.sorteditemdic={}         #dictionary contain items more than minsupport
        self.itemdic={}               #dictionary which contain item and the support count
        self.ordereditemdic={}        #dictionary with item and it's position of support count rank

        #first scan of data to build all necessary dictionaries
        if flag == True:
            self._build(data)
        else:
            self._build2(data) 
    #second scan to build fp tree

    def _build(self, data ):
      numItemSet = getNumLines(dataFile)
      for i in range(1, numItemSet+1):
        trn = getLine(dataFile, i)  
        for item in trn:
            if item in self.itemdic.keys():
                self.itemdic[item] = self.itemdic[item]+1
            else:
                self.itemdic[item] = 1

      
      itemlist = list(self.itemdic.keys())

      #remove all items with < min support
      for item in itemlist:
          if(int(self.itemdic[item])<(self.min_sup)):
              del self.itemdic[item]
      
      #sort remaining items
      self.sorteditemdic = sorted(self.itemdic.items(), key=lambda x:(-x[1], x[0]))

      

      #creating a table which contains item, itemcount and all link node of that item
      temp=0
      for n in self.sorteditemdic:
          
          itemc=n[1]
          item=n[0]

          self.ordereditemdic[item]=temp
          temp = temp+1
          item_info = {
            'itemn':item,
           
            'linknode':None,

            'itemcc':itemc,
            }
          self.headtable.append(item_info)

      #construct fp tree line by line
      for i in range(1, numItemSet+1):
          trn = getLine(data, i)
          valid_item=[]
          for item in trn:
              if item in self.itemdic.keys():
                  valid_item.append(item)
          
          if len(valid_item) > 0:
              sorted_valid_data = sorted(valid_item, key = lambda k: self.ordereditemdic[k])
              #print(sorted_valid_data)

              fp = self.root

              for it in sorted_valid_data:
                  if it in fp.children.keys():
                      fp.children[it].item_cnt += 1
                      fp = fp.children[it]
                  else:
                    fp.children[it] = vertex(item=it, item_cnt= 1, parent=fp, link=None)
                    fp = fp.children[it]

                    for item_info in self.headtable:
                      if item_info["itemn"] == fp.item:
                        if item_info["linknode"] is None:
                          item_info["linknode"] = fp
                        else:
                          nxt_node = item_info["linknode"]
                          while nxt_node.link:
                            nxt_node = nxt_node.link
                          nxt_node.link = fp

    def _build2(self, data ):
      for line in data:
          for item in line:
              if item in self.itemdic.keys():
                  self.itemdic[item] +=1
              else:
                self.itemdic[item] = 1

      
      itemlist = list(self.itemdic.keys())

      #remove all items with < min support
      for item in itemlist:
          if(int(self.itemdic[item])<(self.min_sup)):
              del self.itemdic[item]
      
      #sort remaining items
      self.sorteditemdic = sorted(self.itemdic.items(), key=lambda x:(-x[1], x[0]))

      

      #creating a table which contains item, itemcount and all link node of that item
      temp=0
      for n in self.sorteditemdic:
          
          itemc=n[1]
          
          item=n[0]
          self.ordereditemdic[item]=temp
          temp = temp + 1
          item_info = {
            'itemn':item,
           
            'linknode':None,

            'itemcc':itemc,
            }
          self.headtable.append(item_info)

          

      #construct fp tree line by line
      for line in data:
          valid_item=[]
          for item in line:
              if item in self.itemdic.keys():
                  valid_item.append(item)
          
          if len(valid_item) > 0:
              sorted_valid_data = sorted(valid_item, key = lambda k: self.ordereditemdic[k])
              #print(sorted_valid_data)

              fp = self.root

              for it in sorted_valid_data:
                  if it in fp.children.keys():
                      fp.children[it].item_cnt += 1
                      fp = fp.children[it]
                  else:
                    fp.children[it] = vertex(item=it, item_cnt= 1, parent=fp, link=None)
                    fp = fp.children[it]

                    for item_info in self.headtable:
                      if item_info["itemn"] == fp.item:
                        if item_info["linknode"] is None:
                          item_info["linknode"] = fp
                        else:
                          nxt_node = item_info["linknode"]
                          while nxt_node.link:
                            nxt_node = nxt_node.link
                          nxt_node.link = fp

    

  #creating conditional FP tree and generate frequent item sets

    def findfqtitem(self, PN ):
      treelen = len(list(self.root.children.keys()))
      if treelen == 0:
        return None
      
      fqtline = []
      support = self.min_sup
      #starting from end of headtable

      reversedtable = reversed(self.headtable)

      for k in reversedtable:
        
        fqtset = [set(),0]

        if(PN == None):
          fqtset[0]={k['itemn'],}
        else:
          #print(fqset)
          
          fqtset[0] = {k['itemn']}.union(PN[0])
          fqtset[1]=k['itemcc']
        
        fqtline.append(fqtset)

        
        Nxt = k['linknode']
        if Nxt.parent:
        
            condTreeLine = []
            #from leaf to root adding items
            while Nxt:
                newLine=[]
                ParentNode = Nxt.parent
                while ParentNode.parent:
                    newLine.append(ParentNode.item)
                    ParentNode=ParentNode.parent 
                newLine= list(reversed(newLine))

                for i in range(Nxt.item_cnt):
                    condTreeLine.append(newLine)
            
                Nxt =  Nxt.link
        #print(condLine)
        #recursively building conditional FP tree
        condTree = FPtree(condTreeLine, support , False)
        condItems = condTree.findfqtitem(fqtset)

        if condItems:
          for items in condItems:
            fqtline.append(items)
      
      return fqtline

    

def getLine(dataFile, lineNumber):
    i=0
    with open(dataFile, 'r') as f:
        for line in f.readlines():
            line=line.strip()
            i=i+1
            line=line.rstrip('\n')
            if i==lineNumber:
              break
    #if isinstance(i, int):
    #    return [int(i) for i in line.split(' ')]        
    return [i for i in line.split(' ')]
    #print(getLine("test1",1))  

def getNumLines( dataFile):
    i=0
    with open(dataFile, 'r') as f:
        for line in f.readlines():
            i=i+1
    return i

def getSupportThreshhold(supportThresh, numItemSet):
    return int(supportThresh)* numItemSet/100   

def findsubsets(s, n):
    return list( itertools.combinations(s, n))

def sb(a):

    if a == []:
        return [[]]
    x = sb(a[1:])
    
    return x + [[a[0]] + y for y in x]
 

def sizesubsets(a, num):
    return [k for k in sb(a) if len(k)==num]

def getStr(itemSet):
    str_val= ''.join(sorted(list(map(str, itemSet))))
    return str_val

def findcand(res , num):
    c=[]
    for i in range(0, len(res)):
        for j in range(i+1, len(res)):
            m=True
            for k in range(0, num-2):
                if res[i][0:k+1] !=  res[j][0:k+1]:
                    m=False
                    break

            if(m == False):
                break
            a=""

            a=res[i][0:num]  
            a.append(res[j][num-2])
            a=sorted(a)


            for h in sizesubsets(a, num-1):
                if h in res:
                    if a not in c:
                        c.append(a)
    return c         

def Apriori(dataFile , supportThresh , outputFile):
    uniquelist = []
    #numItemSet = getNumLines(dataFile)
    numItemSet=0
    res={}
    with open(dataFile, 'r') as f:
        for a in f.readlines():
            #a=line
            a=a.strip()
            a=a.rstrip('\n')
            a=[i for i in a.split(' ')]
            #line=line.rstrip('\n')
            numItemSet = numItemSet +1
            #print(a)
            #trn = a
            for item in a:
                if item in res.keys():
                    res[item] = res[item]+1
                else:
                    res[item] = 1    
                if item not in uniquelist:
                    uniquelist.append(item)
 
    freq=[]
    #print(res)
    for i in res.keys():
        #if(res['207']):
            #print(res['207'],getSupportThreshhold(supportThresh , numItemSet) , int(res['207']) >= (getSupportThreshhold(supportThresh , numItemSet)) , "abc")
        if (int(res[i]) >=(getSupportThreshhold(supportThresh , numItemSet))):
            l =[]
            l.append(i)
            freq.append(l)
    
    freq = sorted(freq)
    i=0

    for num in range(2,len(uniquelist)+1):
        for subset in findcand(freq , num):
            k=subset
            
            res[str(k)] = 0
            
            found = True
            i=0
            with open(dataFile, 'r') as f:
                for a in f.readlines():
                    #a=line
                    a=a.strip()
                    a=a.rstrip('\n')
                    a=[i for i in a.split(' ')]         
                    found = True
                    for item in k:
                        if item in a:
                            found=True
                        else:
                            found= False
                            break
                    if found == True :
                        res[str(k)]= int(res[str(k)]) +1
                
                sth = getSupportThreshhold(supportThresh, numItemSet)
            
                if (int(res[str(k)]) >= (sth)):
                    freq.append(k)
    
    if freq is not None:
        freq.sort()
    newres=freq    
    #print(newres)
    with open(outputFile, "w") as external_file:
        for i in newres:
            print(' '.join([str(j) for j in i]),file= external_file)
    external_file.close()       

def FPTree(dataFile , supportThresh , outputFile):

    numItemSet = getNumLines(dataFile)
  
    #print(testdata)
    ##
    fp_tree = FPtree(dataFile, getSupportThreshhold(supportThresh, numItemSet))
    frequentitemset = fp_tree.findfqtitem(None) #mining frequent patt
    #print(frequentitemset)
    if frequentitemset:    
        frequentitemset=sorted(frequentitemset,key = lambda k: -k[1] )

    #print(frequentitemset)
    listres = []
    if frequentitemset:
        for itemset in frequentitemset:
            listres.append(list(itemset[0]))
    # print ("\t%s" % itemset[0])

    
    for item in listres:
        item.sort()
    #print(listres)

    listres.sort()
    with open(outputFile, "w") as external_file:
        for i in listres:
            print(' '.join([str(j) for j in i]),file= external_file)
    external_file.close()


def Plot():
    cc = "python3 -m py_compile datamining.py"
    subprocess.run(cc, shell=True)

    apriori = []
    fptree = []
    supportthreshold = [ 5, 10, 25, 50, 90]
    for s in supportthreshold:
	    start = time.time()
	    subprocess.run("python3 datamining.py -apriori "+ dataFile + " " + str(s) +" "+outputFile,shell=True)
	    end = time.time()
	    apriori.append(end-start)
	    stfptree = time.time()
	    subprocess.run("python3 datamining.py -fptree "+ dataFile + " " + str(s)+ " "+outputFile,shell=True)
	    endfptree = time.time()
	    fptree.append(endfptree-stfptree)

    plt.figure()
    #print(apriori)
    #print(fptree)
    #print(s, apriori , fptree)
    plt.plot(supportthreshold, apriori, label='Apriori')
    plt.plot(supportthreshold, fptree, label='FPTree')
    plt.xlabel('Support threshold')
    plt.ylabel('Running Time(in sec)')
    plt.legend()
    plt.title('Running Times vs Support Threshold')
    plt.savefig(outputFile+".png")

if algo == "-apriori":
    Apriori( dataFile , supportThresh , outputFile)

if algo == "-fptree":
    FPTree(dataFile , supportThresh , outputFile)

if algo == "-plot":
    Plot()    



  




