

https://github.com/cs5190435/col761_assignments


Team Members and there contributions:

1)Chaitanya Naga Sai Kadali - 2019CS50435 - 33.33%
2)Karingala Roshan Raj - 2019CS50437 - 33.33%
3)Subhankar Sarkar - 2022AIZ8171 - 33.33%

All of us contributed equally to this assignment.

FP-Tree algorithm is much better when compared to Apriori Algorithm because, the number of disk access in case of Apriori are much larger when compared to FP-Tree algorithm.  