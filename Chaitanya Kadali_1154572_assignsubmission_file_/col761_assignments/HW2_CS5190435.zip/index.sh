#!/bin/bash
./index $1
echo "Completed building index structures"

