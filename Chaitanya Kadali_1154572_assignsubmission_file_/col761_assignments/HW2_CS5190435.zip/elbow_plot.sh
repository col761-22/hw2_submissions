#python3 kmeans.py.txt AIZ228171_generated_dataset_4D.dat 4
python3 kmeans.py.txt $1 $2
