#!/bin/bash
./help
