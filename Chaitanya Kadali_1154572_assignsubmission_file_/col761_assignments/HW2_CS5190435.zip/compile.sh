#!/bin/bash

g++ -O3 index.cpp -o index
echo "index.cpp successfully compiled"

g++ -O3 help.cpp -o help
echo "help.cpp successfully compiled"

